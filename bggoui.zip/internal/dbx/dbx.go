// Package dbx connects to the source Postgres database and runs the read-only
// preflight queries the workflow relies on (version, databases, schemas,
// extensions, row counts, and Blue/Green logical-replication prerequisites).
package dbx

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ConnInfo is everything needed to dial Postgres.
type ConnInfo struct {
	Host     string
	Port     int
	User     string
	Password string
	DBName   string
	SSLMode  string
}

// DSN renders a libpq-style connection string.
func (c ConnInfo) DSN() string {
	db := c.DBName
	if db == "" {
		db = "postgres"
	}
	ssl := c.SSLMode
	if ssl == "" {
		ssl = "require"
	}
	return fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s connect_timeout=10",
		c.Host, c.Port, c.User, c.Password, db, ssl)
}

// DB is a connected client.
type DB struct {
	pool *pgxpool.Pool
	info ConnInfo
}

// Connect dials and verifies the connection.
func Connect(ctx context.Context, info ConnInfo) (*DB, error) {
	cfg, err := pgxpool.ParseConfig(info.DSN())
	if err != nil {
		return nil, fmt.Errorf("parsing DSN: %w", err)
	}
	cfg.MaxConns = 4
	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("connecting: %w", err)
	}
	pingCtx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	if err := pool.Ping(pingCtx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("ping failed: %w", err)
	}
	return &DB{pool: pool, info: info}, nil
}

// Close releases the pool.
func (d *DB) Close() {
	if d.pool != nil {
		d.pool.Close()
	}
}

// Identity describes who/where we connected as.
type Identity struct {
	CurrentUser string `json:"current_user"`
	Database    string `json:"database"`
	Version     string `json:"version"`
	ServerAddr  string `json:"server_addr"`
}

// Whoami confirms a successful login by reading session identity.
func (d *DB) Whoami(ctx context.Context) (*Identity, error) {
	var id Identity
	err := d.pool.QueryRow(ctx,
		`select current_user, current_database(), version(), coalesce(inet_server_addr()::text,'')`).
		Scan(&id.CurrentUser, &id.Database, &id.Version, &id.ServerAddr)
	if err != nil {
		return nil, fmt.Errorf("identity query: %w", err)
	}
	return &id, nil
}

// ServerVersion returns the numeric major.minor server version string.
func (d *DB) ServerVersion(ctx context.Context) (string, error) {
	var v string
	err := d.pool.QueryRow(ctx, `show server_version`).Scan(&v)
	return v, err
}

// Setting returns a single pg setting via SHOW.
func (d *DB) Setting(ctx context.Context, name string) (string, error) {
	var v string
	err := d.pool.QueryRow(ctx, fmt.Sprintf("show %s", pgx.Identifier{name}.Sanitize())).Scan(&v)
	return v, err
}

// Database lists a user database and its size.
type Database struct {
	Name  string `json:"name"`
	Owner string `json:"owner"`
	Size  string `json:"size"`
}

// Databases returns non-template databases.
func (d *DB) Databases(ctx context.Context) ([]Database, error) {
	rows, err := d.pool.Query(ctx, `
		select d.datname,
		       pg_catalog.pg_get_userbyid(d.datdba) as owner,
		       pg_size_pretty(pg_database_size(d.datname))
		from pg_database d
		where not d.datistemplate
		order by d.datname`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Database
	for rows.Next() {
		var db Database
		if err := rows.Scan(&db.Name, &db.Owner, &db.Size); err != nil {
			return nil, err
		}
		out = append(out, db)
	}
	return out, rows.Err()
}

// Schemas returns the non-system schemas in the connected database.
func (d *DB) Schemas(ctx context.Context) ([]string, error) {
	rows, err := d.pool.Query(ctx, `
		select nspname from pg_namespace
		where nspname not in ('pg_catalog','information_schema')
		  and nspname not like 'pg_toast%'
		  and nspname not like 'pg_temp%'
		order by nspname`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var s string
		if err := rows.Scan(&s); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

// Extension is an installed extension and its version.
type Extension struct {
	Name    string `json:"name"`
	Version string `json:"version"`
	Schema  string `json:"schema"`
}

// Extensions lists installed extensions.
func (d *DB) Extensions(ctx context.Context) ([]Extension, error) {
	rows, err := d.pool.Query(ctx, `
		select e.extname, e.extversion, n.nspname
		from pg_extension e
		join pg_namespace n on n.oid = e.extnamespace
		order by e.extname`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Extension
	for rows.Next() {
		var e Extension
		if err := rows.Scan(&e.Name, &e.Version, &e.Schema); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// TableCount is an estimated row count for one table.
type TableCount struct {
	Schema   string `json:"schema"`
	Table    string `json:"table"`
	EstRows  int64  `json:"est_rows"`
	TotalSize string `json:"total_size"`
}

// TableCounts returns estimated row counts (from the planner statistics, so it is
// cheap on large databases) for the top tables by size.
func (d *DB) TableCounts(ctx context.Context, limit int) ([]TableCount, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := d.pool.Query(ctx, `
		select n.nspname, c.relname,
		       c.reltuples::bigint,
		       pg_size_pretty(pg_total_relation_size(c.oid))
		from pg_class c
		join pg_namespace n on n.oid = c.relnamespace
		where c.relkind = 'r'
		  and n.nspname not in ('pg_catalog','information_schema')
		order by pg_total_relation_size(c.oid) desc
		limit $1`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TableCount
	for rows.Next() {
		var t TableCount
		if err := rows.Scan(&t.Schema, &t.Table, &t.EstRows, &t.TotalSize); err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// PreflightCheck is one named pass/warn/fail result.
type PreflightCheck struct {
	Name   string `json:"name"`
	Status string `json:"status"` // pass|warn|fail
	Detail string `json:"detail"`
}

// Preflight runs the Blue/Green readiness checks documented by AWS: logical
// replication settings, tables without primary keys (which break logical
// replication), unsupported reg* types, and long-running transactions.
func (d *DB) Preflight(ctx context.Context) ([]PreflightCheck, error) {
	var checks []PreflightCheck

	add := func(name, status, detail string) {
		checks = append(checks, PreflightCheck{Name: name, Status: status, Detail: detail})
	}

	// rds.logical_replication / wal_level
	if wal, err := d.Setting(ctx, "wal_level"); err == nil {
		if wal == "logical" {
			add("wal_level", "pass", "wal_level=logical")
		} else {
			add("wal_level", "warn", "wal_level="+wal+" (Blue/Green needs logical; Step 3 enables it)")
		}
	}

	// Tables without a primary key or non-default replica identity.
	var noPK int64
	err := d.pool.QueryRow(ctx, `
		select count(*)
		from pg_class c
		join pg_namespace n on n.oid = c.relnamespace
		where c.relkind = 'r'
		  and n.nspname not in ('pg_catalog','information_schema')
		  and not exists (
		      select 1 from pg_index i
		      where i.indrelid = c.oid and i.indisprimary)`).Scan(&noPK)
	if err == nil {
		if noPK == 0 {
			add("primary_keys", "pass", "all user tables have a primary key")
		} else {
			add("primary_keys", "warn",
				fmt.Sprintf("%d user table(s) lack a primary key; logical replication of UPDATE/DELETE needs REPLICA IDENTITY FULL", noPK))
		}
	}

	// Unsupported data types for logical replication / upgrade (reg* types).
	var regCols int64
	err = d.pool.QueryRow(ctx, `
		select count(*)
		from pg_attribute a
		join pg_class c on c.oid = a.attrelid
		join pg_namespace n on n.oid = c.relnamespace
		join pg_type t on t.oid = a.atttypid
		where c.relkind = 'r' and a.attnum > 0 and not a.attisdropped
		  and n.nspname not in ('pg_catalog','information_schema')
		  and t.typname in ('regclass','regproc','regprocedure','regoper','regoperator','regconfig','regdictionary','regnamespace','regrole')`).Scan(&regCols)
	if err == nil {
		if regCols == 0 {
			add("reg_types", "pass", "no columns use reg* types")
		} else {
			add("reg_types", "fail",
				fmt.Sprintf("%d column(s) use reg* types, which the major-version upgrade cannot preserve", regCols))
		}
	}

	// Long-running / idle-in-transaction sessions that would block switchover.
	var longTxns int64
	err = d.pool.QueryRow(ctx, `
		select count(*) from pg_stat_activity
		where state in ('idle in transaction','active')
		  and xact_start is not null
		  and now() - xact_start > interval '5 minutes'
		  and pid <> pg_backend_pid()`).Scan(&longTxns)
	if err == nil {
		if longTxns == 0 {
			add("long_transactions", "pass", "no transactions older than 5 minutes")
		} else {
			add("long_transactions", "warn",
				fmt.Sprintf("%d transaction(s) older than 5 minutes; these can delay switchover", longTxns))
		}
	}

	// Replication slots already present.
	var slots int64
	if err := d.pool.QueryRow(ctx, `select count(*) from pg_replication_slots`).Scan(&slots); err == nil {
		add("replication_slots", "pass", fmt.Sprintf("%d existing replication slot(s)", slots))
	}

	return checks, nil
}

// Ping is a lightweight connectivity check used by the switchover step.
func (d *DB) Ping(ctx context.Context) error {
	return d.pool.Ping(ctx)
}

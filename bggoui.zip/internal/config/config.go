// Package config loads the tool's TOML configuration. The TOML file lives in
// the same directory as the executable (credentials.toml by default) and holds
// everything the workflow needs: the AWS SSO profile to authenticate with, the
// target RDS instance, the database login, the desired target engine version,
// and the paths to the parameter-group definition files.
package config

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/BurntSushi/toml"
)

// Config is the fully-parsed tool configuration.
type Config struct {
	AWS      AWSConfig      `toml:"aws"`
	Database DatabaseConfig `toml:"database"`
	Upgrade  UpgradeConfig  `toml:"upgrade"`
	Server   ServerConfig   `toml:"server"`

	// path is the absolute path the config was loaded from; used to resolve
	// relative parameter-group file paths against the config's directory.
	path string
}

// AWSConfig identifies how to authenticate and which RDS instance to operate on.
type AWSConfig struct {
	// SSOProfile is the named profile in ~/.aws/config. It must contain (directly
	// or via an sso-session) sso_start_url, sso_region, sso_account_id and
	// sso_role_name.
	SSOProfile string `toml:"sso_profile"`
	// Region overrides the operating region; if empty the profile's region is used.
	Region string `toml:"region"`
	// DBInstanceIdentifier is the source ("blue") RDS instance identifier.
	DBInstanceIdentifier string `toml:"db_instance_identifier"`
}

// DatabaseConfig holds the Postgres login used to connect and run preflight SQL.
type DatabaseConfig struct {
	Host     string `toml:"host"` // optional; defaults to the instance endpoint
	Port     int    `toml:"port"`
	User     string `toml:"user"`
	Password string `toml:"password"`
	DBName   string `toml:"dbname"`
	SSLMode  string `toml:"sslmode"` // disable|require|verify-full; default require
}

// UpgradeConfig describes the desired upgrade target and parameter groups.
type UpgradeConfig struct {
	TargetEngineVersion string `toml:"target_engine_version"`
	// ClusterParameterGroupFile / InstanceParameterGroupFile point at files
	// containing the desired parameter settings to apply to the green env.
	ClusterParameterGroupFile  string `toml:"cluster_parameter_group_file"`
	InstanceParameterGroupFile string `toml:"instance_parameter_group_file"`
	// SavedParameterGroupFile is where Step 1 writes the *current* (blue)
	// parameter group for backup/diffing. Defaults to <instance>-params.json.
	SavedParameterGroupFile string `toml:"saved_parameter_group_file"`
}

// ServerConfig controls the local HTTP UI.
type ServerConfig struct {
	Addr string `toml:"addr"` // default 127.0.0.1:8765
}

// Load reads and validates the TOML config at path.
func Load(path string) (*Config, error) {
	abs, err := filepath.Abs(path)
	if err != nil {
		return nil, err
	}
	if _, err := os.Stat(abs); err != nil {
		return nil, fmt.Errorf("config file %q: %w", abs, err)
	}
	var c Config
	if _, err := toml.DecodeFile(abs, &c); err != nil {
		return nil, fmt.Errorf("parsing %q: %w", abs, err)
	}
	c.path = abs
	c.applyDefaults()
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

func (c *Config) applyDefaults() {
	if c.Database.Port == 0 {
		c.Database.Port = 5432
	}
	if c.Database.SSLMode == "" {
		c.Database.SSLMode = "require"
	}
	if c.Server.Addr == "" {
		c.Server.Addr = "127.0.0.1:8765"
	}
	if c.Upgrade.SavedParameterGroupFile == "" && c.AWS.DBInstanceIdentifier != "" {
		c.Upgrade.SavedParameterGroupFile = c.AWS.DBInstanceIdentifier + "-parameters.json"
	}
}

func (c *Config) validate() error {
	var missing []string
	if c.AWS.SSOProfile == "" {
		missing = append(missing, "aws.sso_profile")
	}
	if c.AWS.DBInstanceIdentifier == "" {
		missing = append(missing, "aws.db_instance_identifier")
	}
	if c.Upgrade.TargetEngineVersion == "" {
		missing = append(missing, "upgrade.target_engine_version")
	}
	if len(missing) > 0 {
		return fmt.Errorf("missing required config keys: %v", missing)
	}
	return nil
}

// Dir returns the directory containing the config file. Relative parameter-group
// paths are resolved against it.
func (c *Config) Dir() string { return filepath.Dir(c.path) }

// Resolve turns a possibly-relative path into one anchored at the config dir.
func (c *Config) Resolve(p string) string {
	if p == "" {
		return ""
	}
	if filepath.IsAbs(p) {
		return p
	}
	return filepath.Join(c.Dir(), p)
}

// DefaultPath returns the default config path next to the executable.
func DefaultPath() string {
	exe, err := os.Executable()
	if err != nil {
		return "credentials.toml"
	}
	return filepath.Join(filepath.Dir(exe), "credentials.toml")
}

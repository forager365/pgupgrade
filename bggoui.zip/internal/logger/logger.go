// Package logger provides a structured, append-only log that writes every event
// to a file named "<db-instance-identifier>-<timestamp>.log" and simultaneously
// fans the events out to any live subscribers (the web UI's event stream and the
// CLI's stdout). Events carry a step association and a level so the UI can colour
// state transitions and errors distinctly.
package logger

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// Level classifies an event.
type Level string

const (
	LevelInfo    Level = "info"
	LevelStep    Level = "step"    // a step boundary (start/finish)
	LevelState   Level = "state"   // an AWS/DB state transition
	LevelWarn    Level = "warn"
	LevelError   Level = "error"
	LevelSuccess Level = "success"
)

// Event is a single log record.
type Event struct {
	Time    time.Time `json:"time"`
	Level   Level     `json:"level"`
	Step    string    `json:"step,omitempty"` // step id, if any
	Message string    `json:"message"`
}

// Logger writes events to a file and broadcasts them to subscribers.
type Logger struct {
	mu          sync.Mutex
	file        *os.File
	path        string
	subscribers map[int]chan Event
	nextSub     int
	history     []Event // replayed to new subscribers so late UI loads see context
}

// New opens (creating if necessary) a log file for the given instance identifier
// in dir. The filename embeds the current timestamp.
func New(dir, instanceID string) (*Logger, error) {
	ts := time.Now().Format("20060102-150405")
	name := fmt.Sprintf("%s-%s.log", instanceID, ts)
	path := filepath.Join(dir, name)
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return nil, fmt.Errorf("opening log file %q: %w", path, err)
	}
	l := &Logger{
		file:        f,
		path:        path,
		subscribers: make(map[int]chan Event),
	}
	l.Emit(Event{Level: LevelInfo, Message: "log started: " + path})
	return l, nil
}

// Path returns the on-disk log file path.
func (l *Logger) Path() string { return l.path }

// Emit records an event: writes a line to the file and notifies subscribers.
func (l *Logger) Emit(e Event) {
	if e.Time.IsZero() {
		e.Time = time.Now()
	}
	l.mu.Lock()
	defer l.mu.Unlock()

	line := fmt.Sprintf("%s [%-7s]%s %s\n",
		e.Time.Format("2006-01-02 15:04:05.000"),
		e.Level,
		stepTag(e.Step),
		e.Message,
	)
	if l.file != nil {
		_, _ = l.file.WriteString(line)
		_ = l.file.Sync()
	}

	l.history = append(l.history, e)
	for _, ch := range l.subscribers {
		select {
		case ch <- e:
		default: // never block the workflow on a slow UI client
		}
	}
}

func stepTag(step string) string {
	if step == "" {
		return ""
	}
	return " [" + step + "]"
}

// Helpers for common cases. They accept a step id (may be "").

func (l *Logger) Info(step, format string, a ...any) {
	l.Emit(Event{Level: LevelInfo, Step: step, Message: fmt.Sprintf(format, a...)})
}
func (l *Logger) Warn(step, format string, a ...any) {
	l.Emit(Event{Level: LevelWarn, Step: step, Message: fmt.Sprintf(format, a...)})
}
func (l *Logger) Error(step, format string, a ...any) {
	l.Emit(Event{Level: LevelError, Step: step, Message: fmt.Sprintf(format, a...)})
}
func (l *Logger) Success(step, format string, a ...any) {
	l.Emit(Event{Level: LevelSuccess, Step: step, Message: fmt.Sprintf(format, a...)})
}

// State records a state transition (the workflow waits on these, not on time).
func (l *Logger) State(step, format string, a ...any) {
	l.Emit(Event{Level: LevelState, Step: step, Message: fmt.Sprintf(format, a...)})
}

// Subscribe returns a channel of future events plus a snapshot of history, and an
// unsubscribe function. Used by the SSE endpoint.
func (l *Logger) Subscribe() (id int, history []Event, ch chan Event, cancel func()) {
	l.mu.Lock()
	defer l.mu.Unlock()
	id = l.nextSub
	l.nextSub++
	ch = make(chan Event, 256)
	l.subscribers[id] = ch
	hist := make([]Event, len(l.history))
	copy(hist, l.history)
	return id, hist, ch, func() {
		l.mu.Lock()
		defer l.mu.Unlock()
		if c, ok := l.subscribers[id]; ok {
			delete(l.subscribers, id)
			close(c)
		}
	}
}

// MarshalEvent is a small helper for the SSE handler.
func MarshalEvent(e Event) ([]byte, error) { return json.Marshal(e) }

// Close flushes and closes the underlying file.
func (l *Logger) Close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file != nil {
		err := l.file.Close()
		l.file = nil
		return err
	}
	return nil
}

// Package awsx wraps the AWS SDK calls the workflow needs. This file implements
// AWS IAM Identity Center (SSO) authentication driven entirely by a named profile
// in ~/.aws/config: it reuses a cached, unexpired SSO token when one exists and
// otherwise performs the OAuth device-authorization flow against the profile's
// start URL, then exchanges the token for role credentials.
package awsx

import (
	"context"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/sso"
	"github.com/aws/aws-sdk-go-v2/service/ssooidc"
	ssooidctypes "github.com/aws/aws-sdk-go-v2/service/ssooidc/types"
	"gopkg.in/ini.v1"
)

// ssoProfile holds the SSO fields resolved from ~/.aws/config for a profile.
type ssoProfile struct {
	Name      string
	StartURL  string
	SSORegion string
	AccountID string
	RoleName  string
	Region    string // operating region for service calls
}

// logf is a minimal logging callback so this package stays decoupled from the
// logger package.
type logf func(format string, a ...any)

// resolveProfile reads ~/.aws/config and extracts the SSO settings for profile.
// It supports both the modern sso-session form and the legacy inline form.
func resolveProfile(profile string) (*ssoProfile, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return nil, err
	}
	cfgPath := filepath.Join(home, ".aws", "config")
	f, err := ini.Load(cfgPath)
	if err != nil {
		return nil, fmt.Errorf("loading %s: %w", cfgPath, err)
	}

	// Profile sections are named "[profile NAME]" except for "[default]".
	secName := "profile " + profile
	if profile == "default" {
		secName = "default"
	}
	sec, err := f.GetSection(secName)
	if err != nil {
		return nil, fmt.Errorf("profile %q not found in %s", profile, cfgPath)
	}

	p := &ssoProfile{
		Name:      profile,
		AccountID: sec.Key("sso_account_id").String(),
		RoleName:  sec.Key("sso_role_name").String(),
		Region:    sec.Key("region").String(),
		StartURL:  sec.Key("sso_start_url").String(),
		SSORegion: sec.Key("sso_region").String(),
	}

	// Modern form: the profile references an [sso-session NAME] block.
	if sess := sec.Key("sso_session").String(); sess != "" {
		s, err := f.GetSection("sso-session " + sess)
		if err != nil {
			return nil, fmt.Errorf("sso-session %q referenced by profile %q not found", sess, profile)
		}
		p.StartURL = s.Key("sso_start_url").String()
		p.SSORegion = s.Key("sso_region").String()
		p.Name = sess // cache is keyed on the session name in the modern form
	}

	if p.StartURL == "" || p.SSORegion == "" {
		return nil, fmt.Errorf("profile %q is missing sso_start_url/sso_region", profile)
	}
	if p.AccountID == "" || p.RoleName == "" {
		return nil, fmt.Errorf("profile %q is missing sso_account_id/sso_role_name", profile)
	}
	if p.Region == "" {
		p.Region = p.SSORegion
	}
	return p, nil
}

// cachedToken structure mirrors the JSON the AWS CLI writes to ~/.aws/sso/cache.
type cachedToken struct {
	StartURL              string `json:"startUrl"`
	Region                string `json:"region"`
	AccessToken           string `json:"accessToken"`
	ExpiresAt             string `json:"expiresAt"`
	ClientID              string `json:"clientId,omitempty"`
	ClientSecret          string `json:"clientSecret,omitempty"`
	RegistrationExpiresAt string `json:"registrationExpiresAt,omitempty"`
}

func ssoCacheDir() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(home, ".aws", "sso", "cache"), nil
}

// findCachedToken scans the SSO cache for a non-expired token whose startUrl
// matches the profile. Returns ("", nil) when none is usable.
func findCachedToken(p *ssoProfile, log logf) (string, error) {
	dir, err := ssoCacheDir()
	if err != nil {
		return "", err
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return "", nil // no cache dir -> no token
	}
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		b, err := os.ReadFile(filepath.Join(dir, e.Name()))
		if err != nil {
			continue
		}
		var t cachedToken
		if json.Unmarshal(b, &t) != nil {
			continue
		}
		if t.AccessToken == "" || t.StartURL != p.StartURL {
			continue
		}
		exp, err := time.Parse(time.RFC3339, t.ExpiresAt)
		if err != nil {
			continue
		}
		if time.Now().After(exp.Add(-1 * time.Minute)) {
			continue // expired (or about to)
		}
		log("reusing active SSO session (expires %s)", exp.Local().Format(time.RFC1123))
		return t.AccessToken, nil
	}
	return "", nil
}

// cacheKey reproduces the CLI's cache filename: sha1 hex of the session name (or
// start URL for the legacy form).
func cacheKey(p *ssoProfile) string {
	key := p.Name
	if key == "" {
		key = p.StartURL
	}
	sum := sha1.Sum([]byte(key))
	return hex.EncodeToString(sum[:])
}

func writeCachedToken(p *ssoProfile, t cachedToken) error {
	dir, err := ssoCacheDir()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	b, err := json.MarshalIndent(t, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(dir, cacheKey(p)+".json"), b, 0o600)
}

// deviceLogin performs the OAuth device-authorization flow and returns an access
// token, caching it for reuse.
func deviceLogin(ctx context.Context, p *ssoProfile, log logf) (string, error) {
	oidc := ssooidc.New(ssooidc.Options{Region: p.SSORegion})

	reg, err := oidc.RegisterClient(ctx, &ssooidc.RegisterClientInput{
		ClientName: aws.String("rds-bluegreen-upgrade-tool"),
		ClientType: aws.String("public"),
	})
	if err != nil {
		return "", fmt.Errorf("RegisterClient: %w", err)
	}

	auth, err := oidc.StartDeviceAuthorization(ctx, &ssooidc.StartDeviceAuthorizationInput{
		ClientId:     reg.ClientId,
		ClientSecret: reg.ClientSecret,
		StartUrl:     aws.String(p.StartURL),
	})
	if err != nil {
		return "", fmt.Errorf("StartDeviceAuthorization: %w", err)
	}

	verifyURL := aws.ToString(auth.VerificationUriComplete)
	log("opening browser to authorise SSO login...")
	log("  verification URL: %s", verifyURL)
	log("  user code:        %s", aws.ToString(auth.UserCode))
	openBrowser(verifyURL, log)

	interval := time.Duration(auth.Interval) * time.Second
	if interval <= 0 {
		interval = 5 * time.Second
	}
	deadline := time.Now().Add(time.Duration(auth.ExpiresIn) * time.Second)

	for {
		if time.Now().After(deadline) {
			return "", fmt.Errorf("device authorization timed out")
		}
		tok, err := oidc.CreateToken(ctx, &ssooidc.CreateTokenInput{
			ClientId:     reg.ClientId,
			ClientSecret: reg.ClientSecret,
			DeviceCode:   auth.DeviceCode,
			GrantType:    aws.String("urn:ietf:params:oauth:grant-type:device_code"),
		})
		if err != nil {
			var pending *ssooidctypes.AuthorizationPendingException
			var slow *ssooidctypes.SlowDownException
			switch {
			case asErr(err, &pending):
				time.Sleep(interval)
				continue
			case asErr(err, &slow):
				interval += 5 * time.Second
				time.Sleep(interval)
				continue
			default:
				return "", fmt.Errorf("CreateToken: %w", err)
			}
		}

		expiresAt := time.Now().Add(time.Duration(tok.ExpiresIn) * time.Second)
		_ = writeCachedToken(p, cachedToken{
			StartURL:     p.StartURL,
			Region:       p.SSORegion,
			AccessToken:  aws.ToString(tok.AccessToken),
			ExpiresAt:    expiresAt.UTC().Format(time.RFC3339),
			ClientID:     aws.ToString(reg.ClientId),
			ClientSecret: aws.ToString(reg.ClientSecret),
		})
		log("SSO login successful (token valid until %s)", expiresAt.Local().Format(time.RFC1123))
		return aws.ToString(tok.AccessToken), nil
	}
}

// credentialsFromSSO exchanges an SSO access token for AWS role credentials.
func credentialsFromSSO(ctx context.Context, p *ssoProfile, accessToken string) (aws.CredentialsProvider, error) {
	svc := sso.New(sso.Options{Region: p.SSORegion})
	out, err := svc.GetRoleCredentials(ctx, &sso.GetRoleCredentialsInput{
		AccessToken: aws.String(accessToken),
		AccountId:   aws.String(p.AccountID),
		RoleName:    aws.String(p.RoleName),
	})
	if err != nil {
		return nil, fmt.Errorf("GetRoleCredentials: %w", err)
	}
	c := out.RoleCredentials
	return credentials.NewStaticCredentialsProvider(
		aws.ToString(c.AccessKeyId),
		aws.ToString(c.SecretAccessKey),
		aws.ToString(c.SessionToken),
	), nil
}

func openBrowser(url string, log logf) {
	var cmd string
	var args []string
	switch runtime.GOOS {
	case "darwin":
		cmd = "open"
	case "windows":
		cmd, args = "rundll32", []string{"url.dll,FileProtocolHandler"}
	default:
		cmd = "xdg-open"
	}
	args = append(args, url)
	if err := exec.Command(cmd, args...).Start(); err != nil {
		log("could not auto-open browser (%v); please open the URL manually", err)
	}
}

package awsx

import (
	"context"
	"errors"
	"fmt"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
	"github.com/aws/smithy-go"
)

// ParameterGroupSpec is the desired target parameter group, typically loaded from
// the file referenced in the TOML config. Family is required when the group must
// be created (e.g. "postgres16" or "aurora-postgresql16"). Parameters are applied
// after the group exists; non-modifiable parameters are skipped with a warning.
type ParameterGroupSpec struct {
	Name        string            `json:"name"`
	Family      string            `json:"family"`
	Description string            `json:"description"`
	Parameters  map[string]string `json:"parameters"`
}

func isNotFound(err error) bool {
	var ae smithy.APIError
	if errors.As(err, &ae) {
		code := ae.ErrorCode()
		return code == "DBParameterGroupNotFound" || code == "DBClusterParameterGroupNotFound"
	}
	return false
}

// EnsureInstanceParameterGroup creates the instance parameter group if it does not
// exist and applies the spec's parameters. It returns the group name to pass to
// CreateBlueGreenDeployment.
func (c *Client) EnsureInstanceParameterGroup(ctx context.Context, spec ParameterGroupSpec) (string, error) {
	if spec.Name == "" {
		return "", fmt.Errorf("instance parameter group spec has no name")
	}
	_, err := c.RDS.DescribeDBParameterGroups(ctx, &rds.DescribeDBParameterGroupsInput{
		DBParameterGroupName: aws.String(spec.Name),
	})
	switch {
	case err == nil:
		c.log("instance parameter group %q already exists; applying parameters", spec.Name)
	case isNotFound(err):
		if spec.Family == "" {
			return "", fmt.Errorf("parameter group %q does not exist and no family given to create it", spec.Name)
		}
		c.log("creating instance parameter group %q (family %s)", spec.Name, spec.Family)
		if _, err := c.RDS.CreateDBParameterGroup(ctx, &rds.CreateDBParameterGroupInput{
			DBParameterGroupName:   aws.String(spec.Name),
			DBParameterGroupFamily: aws.String(spec.Family),
			Description:            aws.String(orDefault(spec.Description, "target group for Blue/Green upgrade")),
		}); err != nil {
			return "", fmt.Errorf("CreateDBParameterGroup: %w", err)
		}
	default:
		return "", fmt.Errorf("DescribeDBParameterGroups: %w", err)
	}

	for name, val := range spec.Parameters {
		if err := c.SetDBParameter(ctx, spec.Name, name, val, "pending-reboot"); err != nil {
			c.log("  WARN could not set %s=%s: %v", name, val, err)
		} else {
			c.log("  set %s = %s", name, val)
		}
	}
	return spec.Name, nil
}

// EnsureClusterParameterGroup is the cluster-level analogue.
func (c *Client) EnsureClusterParameterGroup(ctx context.Context, spec ParameterGroupSpec) (string, error) {
	if spec.Name == "" {
		return "", fmt.Errorf("cluster parameter group spec has no name")
	}
	_, err := c.RDS.DescribeDBClusterParameterGroups(ctx, &rds.DescribeDBClusterParameterGroupsInput{
		DBClusterParameterGroupName: aws.String(spec.Name),
	})
	switch {
	case err == nil:
		c.log("cluster parameter group %q already exists; applying parameters", spec.Name)
	case isNotFound(err):
		if spec.Family == "" {
			return "", fmt.Errorf("cluster parameter group %q does not exist and no family given to create it", spec.Name)
		}
		c.log("creating cluster parameter group %q (family %s)", spec.Name, spec.Family)
		if _, err := c.RDS.CreateDBClusterParameterGroup(ctx, &rds.CreateDBClusterParameterGroupInput{
			DBClusterParameterGroupName: aws.String(spec.Name),
			DBParameterGroupFamily:      aws.String(spec.Family),
			Description:                 aws.String(orDefault(spec.Description, "target cluster group for Blue/Green upgrade")),
		}); err != nil {
			return "", fmt.Errorf("CreateDBClusterParameterGroup: %w", err)
		}
	default:
		return "", fmt.Errorf("DescribeDBClusterParameterGroups: %w", err)
	}

	for name, val := range spec.Parameters {
		if err := c.SetClusterParameter(ctx, spec.Name, name, val, "pending-reboot"); err != nil {
			c.log("  WARN could not set %s=%s: %v", name, val, err)
		} else {
			c.log("  set %s = %s", name, val)
		}
	}
	return spec.Name, nil
}

// ClusterLogicalReplicationEnabled reports whether rds.logical_replication=1 in the
// given cluster parameter group.
func (c *Client) ClusterParameterValue(ctx context.Context, pg, name string) (string, error) {
	params, err := c.describeClusterParams(ctx, pg)
	if err != nil {
		return "", err
	}
	for _, p := range params {
		if p.Name == name {
			return p.Value, nil
		}
	}
	return "", nil
}

// InstanceParameterValue reads one value from an instance parameter group.
func (c *Client) InstanceParameterValue(ctx context.Context, pg, name string) (string, error) {
	params, err := c.describeInstanceParams(ctx, pg)
	if err != nil {
		return "", err
	}
	for _, p := range params {
		if p.Name == name {
			return p.Value, nil
		}
	}
	return "", nil
}

func orDefault(s, d string) string {
	if s == "" {
		return d
	}
	return s
}

// InstanceARN builds the ARN of the source instance for CreateBlueGreenDeployment.
func InstanceARN(inst *rdstypes.DBInstance) string {
	return aws.ToString(inst.DBInstanceArn)
}

// ClusterARN builds the ARN of the source cluster.
func ClusterARN(cl *rdstypes.DBCluster) string {
	return aws.ToString(cl.DBClusterArn)
}

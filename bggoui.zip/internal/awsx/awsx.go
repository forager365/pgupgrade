package awsx

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

// Client bundles the AWS service clients the workflow uses, already authenticated
// via SSO.
type Client struct {
	Region  string
	Profile string
	RDS     *rds.Client
	STS     *sts.Client
	log     logf
}

// Connect authenticates using the named SSO profile (reusing a cached session if
// possible) and returns a ready Client. regionOverride, when non-empty, wins over
// the profile's region.
func Connect(ctx context.Context, profile, regionOverride string, log logf) (*Client, error) {
	p, err := resolveProfile(profile)
	if err != nil {
		return nil, err
	}
	if regionOverride != "" {
		p.Region = regionOverride
	}

	token, err := findCachedToken(p, log)
	if err != nil {
		return nil, err
	}
	if token == "" {
		log("no active SSO session; starting browser login via %s", p.StartURL)
		token, err = deviceLogin(ctx, p, log)
		if err != nil {
			return nil, err
		}
	}

	creds, err := credentialsFromSSO(ctx, p, token)
	if err != nil {
		return nil, err
	}

	awsCfg := aws.Config{Region: p.Region, Credentials: creds}
	return &Client{
		Region:  p.Region,
		Profile: profile,
		RDS:     rds.NewFromConfig(awsCfg),
		STS:     sts.NewFromConfig(awsCfg),
		log:     log,
	}, nil
}

// CallerIdentity wraps sts:GetCallerIdentity.
type CallerIdentity struct {
	Account string `json:"account"`
	ARN     string `json:"arn"`
	UserID  string `json:"user_id"`
}

// WhoAmI returns the authenticated caller identity.
func (c *Client) WhoAmI(ctx context.Context) (*CallerIdentity, error) {
	out, err := c.STS.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
	if err != nil {
		return nil, fmt.Errorf("GetCallerIdentity: %w", err)
	}
	return &CallerIdentity{
		Account: aws.ToString(out.Account),
		ARN:     aws.ToString(out.Arn),
		UserID:  aws.ToString(out.UserId),
	}, nil
}

// DescribeInstance returns the raw RDS DBInstance for the configured identifier.
func (c *Client) DescribeInstance(ctx context.Context, id string) (*rdstypes.DBInstance, error) {
	out, err := c.RDS.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(id),
	})
	if err != nil {
		return nil, fmt.Errorf("DescribeDBInstances(%s): %w", id, err)
	}
	if len(out.DBInstances) == 0 {
		return nil, fmt.Errorf("instance %q not found", id)
	}
	return &out.DBInstances[0], nil
}

// DescribeCluster returns the RDS/Aurora cluster, if the instance belongs to one.
func (c *Client) DescribeCluster(ctx context.Context, clusterID string) (*rdstypes.DBCluster, error) {
	out, err := c.RDS.DescribeDBClusters(ctx, &rds.DescribeDBClustersInput{
		DBClusterIdentifier: aws.String(clusterID),
	})
	if err != nil {
		return nil, fmt.Errorf("DescribeDBClusters(%s): %w", clusterID, err)
	}
	if len(out.DBClusters) == 0 {
		return nil, fmt.Errorf("cluster %q not found", clusterID)
	}
	return &out.DBClusters[0], nil
}

// Topology classifies the source deployment so the workflow can explain the
// Blue/Green upgrade path that applies.
type Topology struct {
	Kind            string   `json:"kind"` // see constants below
	Engine          string   `json:"engine"`
	EngineVersion   string   `json:"engine_version"`
	MultiAZ         bool     `json:"multi_az"`
	ClusterID       string   `json:"cluster_id,omitempty"`
	ReadReplicas    []string `json:"read_replicas,omitempty"`
	IsReadReplica   bool     `json:"is_read_replica"`
	InstanceClass   string   `json:"instance_class"`
	ParameterGroups []string `json:"parameter_groups,omitempty"`
	ClusterPG       string   `json:"cluster_parameter_group,omitempty"`
}

const (
	KindSingleAZ        = "rds-postgres-single-az"
	KindMultiAZInstance = "rds-postgres-multi-az"            // Multi-AZ with standby (one instance)
	KindMultiAZCluster  = "rds-postgres-multi-az-cluster"    // Multi-AZ DB cluster (2 readable standbys)
	KindAurora          = "aurora-postgresql"
	KindAuroraServerless = "aurora-postgresql-serverless"
	KindReadReplica     = "rds-postgres-read-replica"
)

// ClassifyTopology inspects the instance (and its cluster, if any) and returns a
// Topology describing the deployment shape.
func (c *Client) ClassifyTopology(ctx context.Context, inst *rdstypes.DBInstance) (*Topology, error) {
	t := &Topology{
		Engine:        aws.ToString(inst.Engine),
		EngineVersion: aws.ToString(inst.EngineVersion),
		MultiAZ:       aws.ToBool(inst.MultiAZ),
		InstanceClass: aws.ToString(inst.DBInstanceClass),
		ClusterID:     aws.ToString(inst.DBClusterIdentifier),
		IsReadReplica: aws.ToString(inst.ReadReplicaSourceDBInstanceIdentifier) != "",
	}
	for _, pg := range inst.DBParameterGroups {
		t.ParameterGroups = append(t.ParameterGroups, aws.ToString(pg.DBParameterGroupName))
	}
	t.ReadReplicas = append(t.ReadReplicas, inst.ReadReplicaDBInstanceIdentifiers...)

	switch {
	case t.IsReadReplica:
		t.Kind = KindReadReplica
	case t.ClusterID != "":
		cl, err := c.DescribeCluster(ctx, t.ClusterID)
		if err != nil {
			return nil, err
		}
		t.ClusterPG = aws.ToString(cl.DBClusterParameterGroup)
		t.EngineVersion = aws.ToString(cl.EngineVersion)
		eng := aws.ToString(cl.Engine)
		t.Engine = eng
		if cl.ServerlessV2ScalingConfiguration != nil || aws.ToString(cl.EngineMode) == "serverless" {
			t.Kind = KindAuroraServerless
		} else if eng == "aurora-postgresql" {
			t.Kind = KindAurora
		} else {
			// Multi-AZ DB cluster (engine "postgres" with a cluster id).
			t.Kind = KindMultiAZCluster
		}
	case t.MultiAZ:
		t.Kind = KindMultiAZInstance
	default:
		t.Kind = KindSingleAZ
	}
	return t, nil
}

// SaveParameterGroups exports the instance (and cluster, if any) parameter groups
// to a JSON file for backup and diffing.
func (c *Client) SaveParameterGroups(ctx context.Context, t *Topology, path string) error {
	dump := map[string]any{"region": c.Region}

	if len(t.ParameterGroups) > 0 {
		params, err := c.describeInstanceParams(ctx, t.ParameterGroups[0])
		if err != nil {
			return err
		}
		dump["instance_parameter_group"] = t.ParameterGroups[0]
		dump["instance_parameters"] = params
	}
	if t.ClusterPG != "" {
		cparams, err := c.describeClusterParams(ctx, t.ClusterPG)
		if err != nil {
			return err
		}
		dump["cluster_parameter_group"] = t.ClusterPG
		dump["cluster_parameters"] = cparams
	}

	b, err := json.MarshalIndent(dump, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

// Param is a flattened parameter representation.
type Param struct {
	Name         string `json:"name"`
	Value        string `json:"value,omitempty"`
	Source       string `json:"source,omitempty"`
	ApplyType    string `json:"apply_type,omitempty"`
	IsModifiable bool   `json:"is_modifiable"`
}

func (c *Client) describeInstanceParams(ctx context.Context, pg string) ([]Param, error) {
	var out []Param
	p := rds.NewDescribeDBParametersPaginator(c.RDS, &rds.DescribeDBParametersInput{
		DBParameterGroupName: aws.String(pg),
	})
	for p.HasMorePages() {
		page, err := p.NextPage(ctx)
		if err != nil {
			return nil, fmt.Errorf("DescribeDBParameters(%s): %w", pg, err)
		}
		for _, pr := range page.Parameters {
			out = append(out, Param{
				Name:         aws.ToString(pr.ParameterName),
				Value:        aws.ToString(pr.ParameterValue),
				Source:       aws.ToString(pr.Source),
				ApplyType:    aws.ToString(pr.ApplyType),
				IsModifiable: aws.ToBool(pr.IsModifiable),
			})
		}
	}
	return out, nil
}

func (c *Client) describeClusterParams(ctx context.Context, pg string) ([]Param, error) {
	var out []Param
	var marker *string
	for {
		page, err := c.RDS.DescribeDBClusterParameters(ctx, &rds.DescribeDBClusterParametersInput{
			DBClusterParameterGroupName: aws.String(pg),
			Marker:                      marker,
		})
		if err != nil {
			return nil, fmt.Errorf("DescribeDBClusterParameters(%s): %w", pg, err)
		}
		for _, pr := range page.Parameters {
			out = append(out, Param{
				Name:         aws.ToString(pr.ParameterName),
				Value:        aws.ToString(pr.ParameterValue),
				Source:       aws.ToString(pr.Source),
				ApplyType:    aws.ToString(pr.ApplyType),
				IsModifiable: aws.ToBool(pr.IsModifiable),
			})
		}
		if page.Marker == nil {
			break
		}
		marker = page.Marker
	}
	return out, nil
}

// asErr is a thin wrapper around errors.As used by the SSO polling loop.
func asErr(err error, target any) bool { return errors.As(err, target) }

// InstanceSummary is a UI-friendly subset of a DBInstance.
type InstanceSummary struct {
	Identifier    string `json:"identifier"`
	Status        string `json:"status"`
	Engine        string `json:"engine"`
	EngineVersion string `json:"engine_version"`
	Endpoint      string `json:"endpoint"`
	Port          int32  `json:"port"`
	InstanceClass string `json:"instance_class"`
	MultiAZ       bool   `json:"multi_az"`
	AvailZone     string `json:"availability_zone"`
}

// SummariseInstance flattens a DBInstance for display and for endpoint resolution.
func SummariseInstance(inst *rdstypes.DBInstance) InstanceSummary {
	s := InstanceSummary{
		Identifier:    aws.ToString(inst.DBInstanceIdentifier),
		Status:        aws.ToString(inst.DBInstanceStatus),
		Engine:        aws.ToString(inst.Engine),
		EngineVersion: aws.ToString(inst.EngineVersion),
		InstanceClass: aws.ToString(inst.DBInstanceClass),
		MultiAZ:       aws.ToBool(inst.MultiAZ),
		AvailZone:     aws.ToString(inst.AvailabilityZone),
	}
	if inst.Endpoint != nil {
		s.Endpoint = aws.ToString(inst.Endpoint.Address)
		s.Port = aws.ToInt32(inst.Endpoint.Port)
	}
	return s
}

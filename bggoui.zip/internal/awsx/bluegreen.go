package awsx

import (
	"context"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
)

// BlueGreenStatus is a simplified view of a Blue/Green deployment.
type BlueGreenStatus struct {
	Identifier string `json:"identifier"`
	Name       string `json:"name"`
	Status     string `json:"status"` // PROVISIONING|AVAILABLE|SWITCHOVER_*|DELETING ...
	Source     string `json:"source"`
	Target     string `json:"target"`
	TasksTotal int    `json:"tasks_total"`
	TasksDone  int    `json:"tasks_done"`
	Members    []BGMember `json:"members,omitempty"`
}

// BGMember is one source/target pairing inside the deployment.
type BGMember struct {
	Source string `json:"source"`
	Target string `json:"target"`
	Status string `json:"status"`
}

func toBGStatus(d rdstypes.BlueGreenDeployment) BlueGreenStatus {
	s := BlueGreenStatus{
		Identifier: aws.ToString(d.BlueGreenDeploymentIdentifier),
		Name:       aws.ToString(d.BlueGreenDeploymentName),
		Status:     aws.ToString(d.Status),
		Source:     aws.ToString(d.Source),
		Target:     aws.ToString(d.Target),
	}
	for _, t := range d.Tasks {
		s.TasksTotal++
		if aws.ToString(t.Status) == "COMPLETED" {
			s.TasksDone++
		}
	}
	for _, m := range d.SwitchoverDetails {
		s.Members = append(s.Members, BGMember{
			Source: aws.ToString(m.SourceMember),
			Target: aws.ToString(m.TargetMember),
			Status: aws.ToString(m.Status),
		})
	}
	return s
}

// CreateBlueGreenInput parameterises green provisioning.
type CreateBlueGreenInput struct {
	Name                 string
	SourceARN            string
	TargetEngineVersion  string
	TargetClusterPG      string // for Aurora / Multi-AZ clusters
	TargetInstancePG     string // for instance deployments
}

// CreateBlueGreen provisions the green environment at the target version.
func (c *Client) CreateBlueGreen(ctx context.Context, in CreateBlueGreenInput) (*BlueGreenStatus, error) {
	input := &rds.CreateBlueGreenDeploymentInput{
		BlueGreenDeploymentName: aws.String(in.Name),
		Source:                  aws.String(in.SourceARN),
		TargetEngineVersion:     aws.String(in.TargetEngineVersion),
	}
	if in.TargetClusterPG != "" {
		input.TargetDBClusterParameterGroupName = aws.String(in.TargetClusterPG)
	}
	if in.TargetInstancePG != "" {
		input.TargetDBParameterGroupName = aws.String(in.TargetInstancePG)
	}
	out, err := c.RDS.CreateBlueGreenDeployment(ctx, input)
	if err != nil {
		return nil, fmt.Errorf("CreateBlueGreenDeployment: %w", err)
	}
	s := toBGStatus(*out.BlueGreenDeployment)
	return &s, nil
}

// DescribeBlueGreen fetches the current status of a deployment by identifier.
func (c *Client) DescribeBlueGreen(ctx context.Context, id string) (*BlueGreenStatus, error) {
	out, err := c.RDS.DescribeBlueGreenDeployments(ctx, &rds.DescribeBlueGreenDeploymentsInput{
		BlueGreenDeploymentIdentifier: aws.String(id),
	})
	if err != nil {
		return nil, fmt.Errorf("DescribeBlueGreenDeployments: %w", err)
	}
	if len(out.BlueGreenDeployments) == 0 {
		return nil, fmt.Errorf("blue/green deployment %q not found", id)
	}
	s := toBGStatus(out.BlueGreenDeployments[0])
	return &s, nil
}

// FindBlueGreenBySource returns an existing deployment whose source matches the
// given ARN, if any (so re-running provision is idempotent).
func (c *Client) FindBlueGreenBySource(ctx context.Context, sourceARN string) (*BlueGreenStatus, error) {
	out, err := c.RDS.DescribeBlueGreenDeployments(ctx, &rds.DescribeBlueGreenDeploymentsInput{})
	if err != nil {
		return nil, fmt.Errorf("DescribeBlueGreenDeployments: %w", err)
	}
	for _, d := range out.BlueGreenDeployments {
		if aws.ToString(d.Source) == sourceARN {
			s := toBGStatus(d)
			return &s, nil
		}
	}
	return nil, nil
}

// WaitForBlueGreen polls until the deployment reaches one of wantStatuses or an
// error/terminal state. It is state-driven: onChange fires whenever the status or
// task-progress changes, never on a fixed timer. poll is the inter-poll delay.
func (c *Client) WaitForBlueGreen(ctx context.Context, id string, wantStatuses []string, poll time.Duration, onChange func(BlueGreenStatus)) (*BlueGreenStatus, error) {
	want := make(map[string]bool, len(wantStatuses))
	for _, w := range wantStatuses {
		want[w] = true
	}
	var last string
	for {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}
		s, err := c.DescribeBlueGreen(ctx, id)
		if err != nil {
			return nil, err
		}
		sig := fmt.Sprintf("%s %d/%d", s.Status, s.TasksDone, s.TasksTotal)
		if sig != last {
			last = sig
			if onChange != nil {
				onChange(*s)
			}
		}
		if want[s.Status] {
			return s, nil
		}
		if s.Status == "INVALID_CONFIGURATION" || s.Status == "DELETING" {
			return s, fmt.Errorf("deployment entered terminal state %q", s.Status)
		}
		time.Sleep(poll)
	}
}

// Switchover triggers the cutover from blue to green.
func (c *Client) Switchover(ctx context.Context, id string, timeoutSeconds int32) (*BlueGreenStatus, error) {
	in := &rds.SwitchoverBlueGreenDeploymentInput{
		BlueGreenDeploymentIdentifier: aws.String(id),
	}
	if timeoutSeconds > 0 {
		in.SwitchoverTimeout = aws.Int32(timeoutSeconds)
	}
	out, err := c.RDS.SwitchoverBlueGreenDeployment(ctx, in)
	if err != nil {
		return nil, fmt.Errorf("SwitchoverBlueGreenDeployment: %w", err)
	}
	s := toBGStatus(*out.BlueGreenDeployment)
	return &s, nil
}

// SetInstanceParameter changes a single parameter (e.g. rds.logical_replication is
// a cluster-level param; for instance deployments use SetDBParameter) and reports
// whether a reboot is required for it to take effect.
func (c *Client) SetDBParameter(ctx context.Context, pgName, name, value, applyMethod string) error {
	_, err := c.RDS.ModifyDBParameterGroup(ctx, &rds.ModifyDBParameterGroupInput{
		DBParameterGroupName: aws.String(pgName),
		Parameters: []rdstypes.Parameter{{
			ParameterName:  aws.String(name),
			ParameterValue: aws.String(value),
			ApplyMethod:    rdstypes.ApplyMethod(applyMethod),
		}},
	})
	if err != nil {
		return fmt.Errorf("ModifyDBParameterGroup(%s): %w", pgName, err)
	}
	return nil
}

// SetClusterParameter changes a single cluster parameter group value.
func (c *Client) SetClusterParameter(ctx context.Context, pgName, name, value, applyMethod string) error {
	_, err := c.RDS.ModifyDBClusterParameterGroup(ctx, &rds.ModifyDBClusterParameterGroupInput{
		DBClusterParameterGroupName: aws.String(pgName),
		Parameters: []rdstypes.Parameter{{
			ParameterName:  aws.String(name),
			ParameterValue: aws.String(value),
			ApplyMethod:    rdstypes.ApplyMethod(applyMethod),
		}},
	})
	if err != nil {
		return fmt.Errorf("ModifyDBClusterParameterGroup(%s): %w", pgName, err)
	}
	return nil
}

// RebootInstance reboots a DB instance (used to apply a static parameter change).
func (c *Client) RebootInstance(ctx context.Context, id string) error {
	_, err := c.RDS.RebootDBInstance(ctx, &rds.RebootDBInstanceInput{
		DBInstanceIdentifier: aws.String(id),
	})
	if err != nil {
		return fmt.Errorf("RebootDBInstance(%s): %w", id, err)
	}
	return nil
}

// WaitForInstanceAvailable polls DescribeDBInstances until status is "available",
// reporting each status change via onChange.
func (c *Client) WaitForInstanceAvailable(ctx context.Context, id string, poll time.Duration, onChange func(status string)) error {
	var last string
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		inst, err := c.DescribeInstance(ctx, id)
		if err != nil {
			return err
		}
		st := aws.ToString(inst.DBInstanceStatus)
		if st != last {
			last = st
			if onChange != nil {
				onChange(st)
			}
		}
		if st == "available" {
			return nil
		}
		time.Sleep(poll)
	}
}

// Package state holds the workflow's step registry and the live status of each
// step, plus the shared "facts" gathered as the workflow runs (instance topology,
// versions, blue/green deployment identifiers, etc.). It is safe for concurrent
// use by the HTTP handlers and the step runners.
package state

import (
	"sync"
	"time"
)

// Status is a step's lifecycle status; the UI maps each to a button colour.
type Status string

const (
	StatusPending Status = "pending" // grey  – not run yet
	StatusRunning Status = "running" // blue  – in progress
	StatusDone    Status = "done"    // green – completed OK
	StatusError   Status = "error"   // red   – failed
	StatusBlocked Status = "blocked" // amber – needs an out-of-band action (e.g. reboot)
)

// StepStatus is the live status of one step.
type StepStatus struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	Mutating  bool      `json:"mutating"`  // requires a confirmation prompt
	Status    Status    `json:"status"`
	Detail    string    `json:"detail"`    // short status line shown under the button
	StartedAt time.Time `json:"started_at,omitempty"`
	EndedAt   time.Time `json:"ended_at,omitempty"`
}

// Facts is the accumulated knowledge gathered across steps. Fields are populated
// as steps run and are surfaced in the UI.
type Facts struct {
	mu sync.RWMutex
	m  map[string]any
}

func newFacts() *Facts { return &Facts{m: make(map[string]any)} }

// Set stores a fact.
func (f *Facts) Set(key string, val any) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.m[key] = val
}

// Get returns a fact.
func (f *Facts) Get(key string) (any, bool) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	v, ok := f.m[key]
	return v, ok
}

// GetString returns a string fact or "".
func (f *Facts) GetString(key string) string {
	if v, ok := f.Get(key); ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return ""
}

// Snapshot returns a shallow copy of all facts for serialisation.
func (f *Facts) Snapshot() map[string]any {
	f.mu.RLock()
	defer f.mu.RUnlock()
	out := make(map[string]any, len(f.m))
	for k, v := range f.m {
		out[k] = v
	}
	return out
}

// State is the whole workflow's mutable state.
type State struct {
	mu    sync.RWMutex
	order []string
	steps map[string]*StepStatus
	Facts *Facts
}

// New builds a State from an ordered list of step definitions.
func New(defs []StepDef) *State {
	s := &State{
		steps: make(map[string]*StepStatus),
		Facts: newFacts(),
	}
	for _, d := range defs {
		s.order = append(s.order, d.ID)
		s.steps[d.ID] = &StepStatus{
			ID:       d.ID,
			Name:     d.Name,
			Mutating: d.Mutating,
			Status:   StatusPending,
		}
	}
	return s
}

// StepDef is the static definition of a step (id, label, whether it mutates).
type StepDef struct {
	ID       string
	Name     string
	Mutating bool
}

// Steps returns the live status of every step in order.
func (s *State) Steps() []StepStatus {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]StepStatus, 0, len(s.order))
	for _, id := range s.order {
		out = append(out, *s.steps[id])
	}
	return out
}

// Get returns one step's status (copy).
func (s *State) Get(id string) (StepStatus, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	st, ok := s.steps[id]
	if !ok {
		return StepStatus{}, false
	}
	return *st, true
}

// SetStatus updates a step's status and detail line.
func (s *State) SetStatus(id string, status Status, detail string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st, ok := s.steps[id]
	if !ok {
		return
	}
	st.Status = status
	st.Detail = detail
	switch status {
	case StatusRunning:
		st.StartedAt = time.Now()
		st.EndedAt = time.Time{}
	case StatusDone, StatusError, StatusBlocked:
		st.EndedAt = time.Now()
	}
}

// IsDone reports whether the given step completed successfully.
func (s *State) IsDone(id string) bool {
	st, ok := s.Get(id)
	return ok && st.Status == StatusDone
}

package workflow

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"bgg/internal/awsx"
	"bgg/internal/dbx"
	"bgg/internal/state"

	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
)

// Step IDs (stable identifiers used by the UI and CLI).
const (
	StepLogin      = "login"
	StepPreflight  = "preflight"
	StepLogical    = "logical-replication"
	StepProvision  = "provision-green"
	StepSwitchover = "switchover"
)

const pollInterval = 15 * time.Second

func (w *Workflow) defineSteps() []Step {
	return []Step{
		{
			ID:   StepLogin,
			Name: "1. AWS & Database Login",
			Run:  stepLogin,
		},
		{
			ID:       StepPreflight,
			Name:     "2. Preflight Checks",
			Requires: []string{StepLogin},
			Run:      stepPreflight,
		},
		{
			ID:       StepLogical,
			Name:     "3. Enable Logical Replication",
			Mutating: true,
			Requires: []string{StepPreflight},
			Run:      stepLogical,
		},
		{
			ID:       StepProvision,
			Name:     "4. Provision Green Environment",
			Mutating: true,
			Requires: []string{StepLogical},
			Run:      stepProvision,
		},
		{
			ID:       StepSwitchover,
			Name:     "5. Switchover & Connectivity Tests",
			Mutating: true,
			Requires: []string{StepProvision},
			Run:      stepSwitchover,
		},
	}
}

// ---------------------------------------------------------------------------
// Step 1: AWS & Database login
// ---------------------------------------------------------------------------

func stepLogin(ctx context.Context, w *Workflow) error {
	log := func(f string, a ...any) { w.Log.Info(StepLogin, f, a...) }

	// --- AWS SSO login ---
	log("authenticating to AWS via SSO profile %q", w.Cfg.AWS.SSOProfile)
	client, err := awsx.Connect(ctx, w.Cfg.AWS.SSOProfile, w.Cfg.AWS.Region,
		func(f string, a ...any) { w.Log.Info(StepLogin, f, a...) })
	if err != nil {
		return fmt.Errorf("AWS login: %w", err)
	}
	w.setAWS(client)

	id, err := client.WhoAmI(ctx)
	if err != nil {
		return err
	}
	log("authenticated as %s (account %s)", id.ARN, id.Account)
	w.State.Facts.Set("caller_identity", id)
	w.State.Facts.Set("region", client.Region)

	// --- Describe the source RDS instance ---
	instID := w.Cfg.AWS.DBInstanceIdentifier
	log("describing RDS instance %q in %s", instID, client.Region)
	inst, err := client.DescribeInstance(ctx, instID)
	if err != nil {
		return err
	}
	topo, err := client.ClassifyTopology(ctx, inst)
	if err != nil {
		return err
	}
	w.State.Facts.Set("instance", awsx.SummariseInstance(inst))
	w.State.Facts.Set("topology", topo)
	w.State.Facts.Set("instance_arn", awsx.InstanceARN(inst))
	if topo.ClusterID != "" {
		cl, err := client.DescribeCluster(ctx, topo.ClusterID)
		if err != nil {
			return err
		}
		w.State.Facts.Set("cluster_arn", awsx.ClusterARN(cl))
		w.State.Facts.Set("cluster_endpoint", awsEndpoint(cl))
	}
	log("engine=%s version=%s topology=%s status=%s",
		topo.Engine, topo.EngineVersion, topo.Kind, awsx.SummariseInstance(inst).Status)

	// --- Save current parameter group(s) to file ---
	pgPath := w.Cfg.Resolve(w.Cfg.Upgrade.SavedParameterGroupFile)
	log("saving current parameter group(s) to %s", pgPath)
	if err := client.SaveParameterGroups(ctx, topo, pgPath); err != nil {
		return fmt.Errorf("saving parameter groups: %w", err)
	}
	w.State.Facts.Set("saved_parameter_group_file", pgPath)
	w.Log.Success(StepLogin, "parameter group(s) saved to %s", pgPath)

	// --- Database login ---
	host := w.Cfg.Database.Host
	if host == "" {
		host = awsx.SummariseInstance(inst).Endpoint
	}
	if host == "" {
		return fmt.Errorf("no database host: set database.host or wait for the instance endpoint")
	}
	log("connecting to Postgres at %s:%d as %s", host, w.Cfg.Database.Port, w.Cfg.Database.User)
	db, err := dbx.Connect(ctx, dbx.ConnInfo{
		Host:     host,
		Port:     w.Cfg.Database.Port,
		User:     w.Cfg.Database.User,
		Password: w.Cfg.Database.Password,
		DBName:   w.Cfg.Database.DBName,
		SSLMode:  w.Cfg.Database.SSLMode,
	})
	if err != nil {
		return fmt.Errorf("database login: %w", err)
	}
	w.setDB(db)
	who, err := db.Whoami(ctx)
	if err != nil {
		return err
	}
	w.State.Facts.Set("db_identity", who)
	w.Log.Success(StepLogin, "database login OK — user=%s db=%s server=%s",
		who.CurrentUser, who.Database, firstLine(who.Version))
	return nil
}

// ---------------------------------------------------------------------------
// Step 2: Preflight checks
// ---------------------------------------------------------------------------

func stepPreflight(ctx context.Context, w *Workflow) error {
	log := func(f string, a ...any) { w.Log.Info(StepPreflight, f, a...) }
	db, err := w.database()
	if err != nil {
		return err
	}
	topoAny, _ := w.State.Facts.Get("topology")
	topo, _ := topoAny.(*awsx.Topology)

	// Current version
	ver, err := db.ServerVersion(ctx)
	if err != nil {
		return err
	}
	log("current Postgres server_version = %s", ver)
	log("target engine version (from config) = %s", w.Cfg.Upgrade.TargetEngineVersion)
	w.State.Facts.Set("current_version", ver)

	// Topology + upgrade path narrative
	if topo != nil {
		path := upgradePathNarrative(topo, w.Cfg.Upgrade.TargetEngineVersion)
		w.State.Facts.Set("upgrade_path", path)
		log("topology: %s", topo.Kind)
		for _, line := range strings.Split(path, "\n") {
			log("  %s", line)
		}
	}

	// Databases & schemas
	dbs, err := db.Databases(ctx)
	if err != nil {
		return err
	}
	w.State.Facts.Set("databases", dbs)
	log("databases (%d):", len(dbs))
	for _, d := range dbs {
		log("  - %s (owner=%s, size=%s)", d.Name, d.Owner, d.Size)
	}

	schemas, err := db.Schemas(ctx)
	if err != nil {
		return err
	}
	w.State.Facts.Set("schemas", schemas)
	log("schemas in %s (%d): %s", w.Cfg.Database.DBName, len(schemas), strings.Join(schemas, ", "))

	// Extensions
	exts, err := db.Extensions(ctx)
	if err != nil {
		return err
	}
	w.State.Facts.Set("extensions", exts)
	log("extensions (%d):", len(exts))
	for _, e := range exts {
		log("  - %s %s (schema=%s)", e.Name, e.Version, e.Schema)
	}

	// Table row counts (estimated)
	counts, err := db.TableCounts(ctx, 50)
	if err != nil {
		return err
	}
	w.State.Facts.Set("table_counts", counts)
	log("largest tables by size (estimated rows):")
	for _, t := range counts {
		log("  - %s.%s ~%d rows, %s", t.Schema, t.Table, t.EstRows, t.TotalSize)
	}

	// Preflight SQL checks
	checks, err := db.Preflight(ctx)
	if err != nil {
		return err
	}
	w.State.Facts.Set("preflight_checks", checks)
	var fails, warns int
	for _, c := range checks {
		switch c.Status {
		case "fail":
			fails++
			w.Log.Error(StepPreflight, "  [FAIL] %s: %s", c.Name, c.Detail)
		case "warn":
			warns++
			w.Log.Warn(StepPreflight, "  [WARN] %s: %s", c.Name, c.Detail)
		default:
			w.Log.Success(StepPreflight, "  [PASS] %s: %s", c.Name, c.Detail)
		}
	}
	log("preflight summary: %d pass-with-attention warnings, %d hard failures", warns, fails)
	if fails > 0 {
		return fmt.Errorf("%d preflight check(s) failed — resolve before upgrading", fails)
	}
	return nil
}

// ---------------------------------------------------------------------------
// Step 3: Enable logical replication
// ---------------------------------------------------------------------------

func stepLogical(ctx context.Context, w *Workflow) error {
	log := func(f string, a ...any) { w.Log.Info(StepLogical, f, a...) }
	client, err := w.awsClient()
	if err != nil {
		return err
	}
	db, err := w.database()
	if err != nil {
		return err
	}
	topoAny, _ := w.State.Facts.Get("topology")
	topo, _ := topoAny.(*awsx.Topology)
	if topo == nil {
		return fmt.Errorf("topology unknown; run preflight first")
	}

	// Live check first — if already logical, nothing to do.
	wal, err := db.Setting(ctx, "wal_level")
	if err != nil {
		return err
	}
	if wal == "logical" {
		w.Log.Success(StepLogical, "wal_level is already 'logical' — logical replication is enabled")
		return nil
	}
	log("wal_level=%s — enabling logical replication via parameter group", wal)

	// The parameter to set differs by deployment shape:
	//   - cluster (Aurora / Multi-AZ cluster): cluster PG, rds.logical_replication=1
	//   - single instance / Multi-AZ instance: instance PG, rds.logical_replication=1
	const paramName = "rds.logical_replication"
	if topo.ClusterPG != "" {
		log("setting %s=1 on cluster parameter group %q (static; requires reboot)", paramName, topo.ClusterPG)
		if err := client.SetClusterParameter(ctx, topo.ClusterPG, paramName, "1", "pending-reboot"); err != nil {
			return err
		}
	} else if len(topo.ParameterGroups) > 0 {
		pg := topo.ParameterGroups[0]
		if strings.HasPrefix(pg, "default.") {
			return fmt.Errorf("instance uses the default parameter group %q which cannot be modified; "+
				"create and attach a custom parameter group, then re-run", pg)
		}
		log("setting %s=1 on instance parameter group %q (static; requires reboot)", paramName, pg)
		if err := client.SetDBParameter(ctx, pg, paramName, "1", "pending-reboot"); err != nil {
			return err
		}
	} else {
		return fmt.Errorf("no modifiable parameter group found on the instance")
	}

	// This is a static parameter: a reboot is required. We park the step in the
	// Blocked state and ask the operator to reboot, then re-run this step.
	instID := w.Cfg.AWS.DBInstanceIdentifier
	w.State.SetStatus(StepLogical, state.StatusBlocked,
		"rds.logical_replication set — reboot required, then re-run this step")
	w.Log.Warn(StepLogical, "ACTION REQUIRED: reboot instance %q to apply rds.logical_replication, then run this step again to verify", instID)
	w.Log.State(StepLogical, "parameter set, awaiting reboot → re-run to confirm wal_level=logical")
	return nil
}

// ---------------------------------------------------------------------------
// Step 4: Provision green
// ---------------------------------------------------------------------------

func stepProvision(ctx context.Context, w *Workflow) error {
	log := func(f string, a ...any) { w.Log.Info(StepProvision, f, a...) }
	client, err := w.awsClient()
	if err != nil {
		return err
	}
	topoAny, _ := w.State.Facts.Get("topology")
	topo, _ := topoAny.(*awsx.Topology)

	// Source ARN: cluster ARN for cluster topologies, else instance ARN.
	sourceARN := w.State.Facts.GetString("cluster_arn")
	if sourceARN == "" {
		sourceARN = w.State.Facts.GetString("instance_arn")
	}
	if sourceARN == "" {
		return fmt.Errorf("source ARN unknown; run step 1")
	}

	// Idempotency: reuse an in-flight/existing deployment for this source.
	if existing, err := client.FindBlueGreenBySource(ctx, sourceARN); err == nil && existing != nil {
		log("found existing blue/green deployment %s (status=%s) — resuming", existing.Identifier, existing.Status)
		w.State.Facts.Set("bluegreen_id", existing.Identifier)
		return waitGreenAvailable(ctx, w, client, existing.Identifier)
	}

	// Resolve target parameter groups from the configured files (optional).
	targetInstancePG, targetClusterPG, err := w.resolveTargetParameterGroups(ctx, client, topo)
	if err != nil {
		return err
	}

	name := fmt.Sprintf("bg-%s-%s", w.Cfg.AWS.DBInstanceIdentifier,
		strings.ReplaceAll(w.Cfg.Upgrade.TargetEngineVersion, ".", "-"))
	log("creating blue/green deployment %q: %s → engine %s", name,
		shortARN(sourceARN), w.Cfg.Upgrade.TargetEngineVersion)

	bg, err := client.CreateBlueGreen(ctx, awsx.CreateBlueGreenInput{
		Name:                name,
		SourceARN:           sourceARN,
		TargetEngineVersion: w.Cfg.Upgrade.TargetEngineVersion,
		TargetClusterPG:     targetClusterPG,
		TargetInstancePG:    targetInstancePG,
	})
	if err != nil {
		return err
	}
	w.State.Facts.Set("bluegreen_id", bg.Identifier)
	w.Log.State(StepProvision, "blue/green deployment %s created → status %s", bg.Identifier, bg.Status)

	return waitGreenAvailable(ctx, w, client, bg.Identifier)
}

func waitGreenAvailable(ctx context.Context, w *Workflow, client *awsx.Client, id string) error {
	w.Log.Info(StepProvision, "waiting for green environment to become AVAILABLE (state-driven; polling every %s)…", pollInterval)
	final, err := client.WaitForBlueGreen(ctx, id, []string{"AVAILABLE"}, pollInterval, func(s awsx.BlueGreenStatus) {
		w.Log.State(StepProvision, "state: %s — tasks %d/%d complete", s.Status, s.TasksDone, s.TasksTotal)
		w.State.SetStatus(StepProvision, state.StatusRunning,
			fmt.Sprintf("%s (%d/%d)", s.Status, s.TasksDone, s.TasksTotal))
	})
	if err != nil {
		return err
	}
	w.State.Facts.Set("bluegreen_status", final)
	w.Log.Success(StepProvision, "green environment is AVAILABLE (target=%s)", final.Target)
	return nil
}

// ---------------------------------------------------------------------------
// Step 5: Switchover & connectivity tests
// ---------------------------------------------------------------------------

func stepSwitchover(ctx context.Context, w *Workflow) error {
	log := func(f string, a ...any) { w.Log.Info(StepSwitchover, f, a...) }
	client, err := w.awsClient()
	if err != nil {
		return err
	}
	bgID := w.State.Facts.GetString("bluegreen_id")
	if bgID == "" {
		return fmt.Errorf("no blue/green deployment id; run step 4 first")
	}

	log("initiating switchover of deployment %s", bgID)
	if _, err := client.Switchover(ctx, bgID, 300); err != nil {
		return err
	}
	w.Log.State(StepSwitchover, "switchover requested → waiting for SWITCHOVER_COMPLETED")

	final, err := client.WaitForBlueGreen(ctx, bgID,
		[]string{"SWITCHOVER_COMPLETED"}, pollInterval, func(s awsx.BlueGreenStatus) {
			w.Log.State(StepSwitchover, "state: %s", s.Status)
			w.State.SetStatus(StepSwitchover, state.StatusRunning, s.Status)
		})
	if err != nil {
		return err
	}
	w.Log.Success(StepSwitchover, "switchover complete — blue and green have swapped endpoints")

	// Connectivity tests against the (now-upgraded) endpoint.
	return runConnectivityTests(ctx, w, final)
}

func runConnectivityTests(ctx context.Context, w *Workflow, _ *awsx.BlueGreenStatus) error {
	log := func(f string, a ...any) { w.Log.Info(StepSwitchover, f, a...) }
	client, _ := w.awsClient()

	// Re-describe the instance to pick up the post-switchover endpoint/version.
	inst, err := client.DescribeInstance(ctx, w.Cfg.AWS.DBInstanceIdentifier)
	if err != nil {
		return err
	}
	summary := awsx.SummariseInstance(inst)
	host := w.Cfg.Database.Host
	if host == "" {
		host = summary.Endpoint
	}
	log("running connectivity tests against %s (engine version now %s)", host, summary.EngineVersion)

	db, err := dbx.Connect(ctx, dbx.ConnInfo{
		Host: host, Port: w.Cfg.Database.Port, User: w.Cfg.Database.User,
		Password: w.Cfg.Database.Password, DBName: w.Cfg.Database.DBName, SSLMode: w.Cfg.Database.SSLMode,
	})
	if err != nil {
		return fmt.Errorf("post-switchover connect failed: %w", err)
	}
	defer db.Close()
	w.setDB(db)

	if err := db.Ping(ctx); err != nil {
		return fmt.Errorf("ping failed: %w", err)
	}
	w.Log.Success(StepSwitchover, "  [PASS] connectivity ping")

	who, err := db.Whoami(ctx)
	if err != nil {
		return err
	}
	w.Log.Success(StepSwitchover, "  [PASS] identity: user=%s db=%s", who.CurrentUser, who.Database)

	newVer, err := db.ServerVersion(ctx)
	if err != nil {
		return err
	}
	w.State.Facts.Set("post_switchover_version", newVer)
	target := w.Cfg.Upgrade.TargetEngineVersion
	if strings.HasPrefix(newVer, majorOf(target)) {
		w.Log.Success(StepSwitchover, "  [PASS] server_version=%s matches target major %s", newVer, majorOf(target))
	} else {
		w.Log.Warn(StepSwitchover, "  [WARN] server_version=%s does not start with target major %s", newVer, majorOf(target))
	}
	return nil
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

func (w *Workflow) resolveTargetParameterGroups(ctx context.Context, client *awsx.Client, topo *awsx.Topology) (instancePG, clusterPG string, err error) {
	instFile := w.Cfg.Resolve(w.Cfg.Upgrade.InstanceParameterGroupFile)
	clusterFile := w.Cfg.Resolve(w.Cfg.Upgrade.ClusterParameterGroupFile)

	if instFile != "" {
		spec, err := loadParamSpec(instFile)
		if err != nil {
			return "", "", fmt.Errorf("instance parameter group file: %w", err)
		}
		w.Log.Info(StepProvision, "ensuring target instance parameter group %q from %s", spec.Name, instFile)
		instancePG, err = client.EnsureInstanceParameterGroup(ctx, spec)
		if err != nil {
			return "", "", err
		}
	}
	// Only cluster topologies use a cluster parameter group.
	if clusterFile != "" && topo != nil && topo.ClusterID != "" {
		spec, err := loadParamSpec(clusterFile)
		if err != nil {
			return "", "", fmt.Errorf("cluster parameter group file: %w", err)
		}
		w.Log.Info(StepProvision, "ensuring target cluster parameter group %q from %s", spec.Name, clusterFile)
		clusterPG, err = client.EnsureClusterParameterGroup(ctx, spec)
		if err != nil {
			return "", "", err
		}
	}
	return instancePG, clusterPG, nil
}

func loadParamSpec(path string) (awsx.ParameterGroupSpec, error) {
	var spec awsx.ParameterGroupSpec
	b, err := os.ReadFile(path)
	if err != nil {
		return spec, err
	}
	if err := json.Unmarshal(b, &spec); err != nil {
		return spec, fmt.Errorf("parsing %s as JSON: %w", path, err)
	}
	return spec, nil
}

// upgradePathNarrative explains, per topology, how Blue/Green will perform the
// major-version upgrade (summarising the AWS documentation).
func upgradePathNarrative(t *awsx.Topology, target string) string {
	common := fmt.Sprintf("Blue/Green creates a staging (green) copy at %s, kept in sync via logical replication, then switches over with minimal downtime.", target)
	switch t.Kind {
	case awsx.KindSingleAZ:
		return "Single-AZ RDS for PostgreSQL.\n" + common +
			"\nGreen is a new Single-AZ instance upgraded to the target major version."
	case awsx.KindMultiAZInstance:
		return "Multi-AZ RDS for PostgreSQL (one standby).\n" + common +
			"\nGreen is provisioned Multi-AZ; the standby is upgraded alongside the primary."
	case awsx.KindMultiAZCluster:
		return "Multi-AZ DB cluster (two readable standbys).\n" + common +
			"\nGreen mirrors the cluster topology with all reader instances upgraded."
	case awsx.KindAurora:
		return "Aurora PostgreSQL cluster.\n" + common +
			"\nGreen is a new Aurora cluster (writer + readers) at the target version; reader endpoints move on switchover."
	case awsx.KindAuroraServerless:
		return "Aurora PostgreSQL Serverless v2.\n" + common +
			"\nGreen preserves the Serverless v2 scaling configuration at the target version."
	case awsx.KindReadReplica:
		return "This instance is a READ REPLICA. Blue/Green should target the primary; " +
			"upgrade the source instance instead, or promote/detach as appropriate."
	default:
		return common
	}
}

func majorOf(version string) string {
	if i := strings.IndexByte(version, '.'); i > 0 {
		// PG 10+ uses a single-number major (e.g. 16.3 -> 16); keep the part before the first dot.
		return version[:i]
	}
	return version
}

func firstLine(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}

func shortARN(arn string) string {
	if i := strings.LastIndexByte(arn, ':'); i >= 0 {
		return arn[i+1:]
	}
	return arn
}

// awsEndpoint returns the writer endpoint address of a cluster, if present.
func awsEndpoint(cl *rdstypes.DBCluster) string {
	if cl == nil || cl.Endpoint == nil {
		return ""
	}
	return *cl.Endpoint
}

// Package workflow ties configuration, logging, state, AWS and the database into
// the ordered set of upgrade steps. Each step is a small function that records
// its findings into shared Facts and emits log/state events; the same step set is
// driven identically from the web UI and the CLI.
package workflow

import (
	"context"
	"fmt"
	"sync"
	"time"

	"bgg/internal/awsx"
	"bgg/internal/config"
	"bgg/internal/dbx"
	"bgg/internal/logger"
	"bgg/internal/state"
)

// Step is one unit of the workflow.
type Step struct {
	ID       string
	Name     string
	Mutating bool
	// Requires lists step IDs that must be Done before this step may run.
	Requires []string
	Run      func(ctx context.Context, w *Workflow) error
}

// Workflow holds all shared state and the connected clients.
type Workflow struct {
	Cfg   *config.Config
	Log   *logger.Logger
	State *state.State

	mu  sync.Mutex
	aws *awsx.Client
	db  *dbx.DB

	steps   []Step
	stepIdx map[string]Step

	// running guards against two concurrent step executions.
	running sync.Mutex
}

// New builds a Workflow with its step set registered.
func New(cfg *config.Config, log *logger.Logger) *Workflow {
	w := &Workflow{
		Cfg:     cfg,
		Log:     log,
		stepIdx: map[string]Step{},
	}
	w.steps = w.defineSteps()
	defs := make([]state.StepDef, 0, len(w.steps))
	for _, s := range w.steps {
		w.stepIdx[s.ID] = s
		defs = append(defs, state.StepDef{ID: s.ID, Name: s.Name, Mutating: s.Mutating})
	}
	w.State = state.New(defs)
	return w
}

// Steps returns the static step list (for the UI / CLI to enumerate).
func (w *Workflow) Steps() []Step { return w.steps }

// StepByID looks up a step.
func (w *Workflow) StepByID(id string) (Step, bool) {
	s, ok := w.stepIdx[id]
	return s, ok
}

// aws/db accessors with helpful errors when a prerequisite step hasn't run.
func (w *Workflow) awsClient() (*awsx.Client, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.aws == nil {
		return nil, fmt.Errorf("not logged in to AWS yet — run step 1 first")
	}
	return w.aws, nil
}

func (w *Workflow) database() (*dbx.DB, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.db == nil {
		return nil, fmt.Errorf("not connected to the database yet — run step 1 first")
	}
	return w.db, nil
}

func (w *Workflow) setAWS(c *awsx.Client) { w.mu.Lock(); w.aws = c; w.mu.Unlock() }
func (w *Workflow) setDB(d *dbx.DB)        { w.mu.Lock(); w.db = d; w.mu.Unlock() }

// RunStep executes a single step by id, managing status transitions and
// prerequisite checks. It is safe to call from HTTP handlers or the CLI. Only one
// step runs at a time.
func (w *Workflow) RunStep(ctx context.Context, id string) error {
	step, ok := w.stepIdx[id]
	if !ok {
		return fmt.Errorf("unknown step %q", id)
	}

	// Enforce prerequisites.
	for _, req := range step.Requires {
		if !w.State.IsDone(req) {
			r := w.stepIdx[req]
			return fmt.Errorf("step %q requires %q (%s) to complete first", id, req, r.Name)
		}
	}

	w.running.Lock()
	defer w.running.Unlock()

	w.State.SetStatus(id, state.StatusRunning, "running…")
	w.Log.Emit(logger.Event{Level: logger.LevelStep, Step: id,
		Message: fmt.Sprintf("▶ START %s", step.Name)})
	start := time.Now()

	err := step.Run(ctx, w)
	dur := time.Since(start).Round(time.Millisecond)

	if err != nil {
		w.State.SetStatus(id, state.StatusError, err.Error())
		w.Log.Error(id, "✖ %s failed after %s: %v", step.Name, dur, err)
		return err
	}

	// A step may have parked itself in Blocked (e.g. awaiting a reboot); respect it.
	if cur, _ := w.State.Get(id); cur.Status == state.StatusBlocked {
		w.Log.Warn(id, "■ %s needs an out-of-band action before continuing (%s)", step.Name, dur)
		return nil
	}

	w.State.SetStatus(id, state.StatusDone, "completed")
	w.Log.Success(id, "✔ DONE %s (%s)", step.Name, dur)
	return nil
}

// Close releases connections.
func (w *Workflow) Close() {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.db != nil {
		w.db.Close()
	}
}

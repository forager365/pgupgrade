"use strict";

const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, txt) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (txt !== undefined) e.textContent = txt;
  return e;
};

let stepsMeta = [];     // [{id,name,mutating,...}]
let pendingRun = null;  // step awaiting modal confirmation

// ---- Live event stream (SSE) -------------------------------------------------
function startStream() {
  const stream = $("#stream");
  const es = new EventSource("/api/events");
  es.onmessage = (ev) => {
    let e;
    try { e = JSON.parse(ev.data); } catch { return; }
    const line = el("div", "line " + (e.level || "info"));
    const ts = new Date(e.time).toLocaleTimeString();
    line.appendChild(el("span", "ts", ts));
    const msg = el("span", "msg", (e.step ? `[${e.step}] ` : "") + e.message);
    line.appendChild(msg);
    const atBottom = stream.scrollHeight - stream.scrollTop - stream.clientHeight < 40;
    stream.appendChild(line);
    if (atBottom) stream.scrollTop = stream.scrollHeight;
    // any event may reflect status changes; refresh step buttons lightly
    if (e.level === "step" || e.level === "success" || e.level === "error" || e.level === "state") {
      refreshState();
    }
  };
  es.onerror = () => { /* browser auto-reconnects */ };
}

// ---- State / steps -----------------------------------------------------------
async function refreshState() {
  const r = await fetch("/api/state");
  const s = await r.json();
  renderSteps(s.steps, s.busy);
  renderFacts(s.facts);
  if (s.logfile) $("#logfile").textContent = "log: " + s.logfile;
}

function renderSteps(steps, busy) {
  stepsMeta = steps;
  const box = $("#steps");
  box.innerHTML = "";
  steps.forEach((st, i) => {
    const btn = el("button", "step-btn " + st.status);
    const name = el("div", "name");
    name.appendChild(el("span", null, st.name));
    if (st.mutating) name.appendChild(el("span", "badge mut", "mutating"));
    btn.appendChild(name);
    const detailText = st.detail || statusLabel(st.status);
    btn.appendChild(el("div", "detail", detailText));

    // Disable while another step is running (single-flight) — except allow the
    // running one to show its progress; re-running a blocked step is allowed.
    btn.disabled = !!busy;
    btn.onclick = () => onStepClick(st);
    box.appendChild(btn);
  });
}

function statusLabel(s) {
  return { pending: "click to run", running: "running…", done: "completed",
           blocked: "action required — click to re-check", error: "failed — click to retry" }[s] || s;
}

function onStepClick(st) {
  if (st.mutating) {
    pendingRun = st;
    $("#modal-text").textContent =
      `Step “${st.name}” performs changes in AWS and/or your database.\n\nThis is a mutating operation. Proceed?`;
    $("#modal").classList.remove("hidden");
  } else {
    runStep(st.id, false);
  }
}

async function runStep(id, confirm) {
  const url = `/api/run?step=${encodeURIComponent(id)}` + (confirm ? "&confirm=true" : "");
  const r = await fetch(url, { method: "POST" });
  if (r.status === 409) {
    const b = await r.json();
    alert(b.error);
  }
  refreshState();
}

// ---- Findings (facts) --------------------------------------------------------
function renderFacts(facts) {
  const box = $("#facts");
  box.innerHTML = "";
  if (!facts || Object.keys(facts).length === 0) {
    box.appendChild(el("p", "subtitle", "No findings yet — run the workflow steps."));
    return;
  }

  if (facts.caller_identity) {
    section(box, "AWS Identity");
    kv(box, { ARN: facts.caller_identity.arn, Account: facts.caller_identity.account, Region: facts.region });
  }
  if (facts.instance) {
    section(box, "Source Instance");
    const inst = facts.instance;
    kv(box, {
      Identifier: inst.identifier, Status: inst.status,
      Engine: `${inst.engine} ${inst.engine_version}`, Class: inst.instance_class,
      Endpoint: `${inst.endpoint || "-"}:${inst.port || ""}`, "Multi-AZ": String(inst.multi_az),
    });
  }
  if (facts.topology) {
    section(box, "Topology & Upgrade Path");
    kv(box, { Kind: facts.topology.kind, "Current version": facts.current_version || facts.topology.engine_version });
    if (facts.upgrade_path) {
      const p = el("div", "subtitle");
      p.style.whiteSpace = "pre-wrap";
      p.textContent = facts.upgrade_path;
      box.appendChild(p);
    }
  }
  if (facts.databases) {
    section(box, "Databases");
    table(box, ["Name", "Owner", "Size"], facts.databases.map(d => [d.name, d.owner, d.size]));
  }
  if (facts.schemas) {
    section(box, "Schemas");
    box.appendChild(el("div", "subtitle", facts.schemas.join(", ")));
  }
  if (facts.extensions) {
    section(box, "Extensions");
    table(box, ["Name", "Version", "Schema"], facts.extensions.map(e => [e.name, e.version, e.schema]));
  }
  if (facts.preflight_checks) {
    section(box, "Preflight Checks");
    const rows = facts.preflight_checks.map(c => {
      const pill = el("span", "pill " + c.status, c.status.toUpperCase());
      return [c.name, pill, c.detail];
    });
    table(box, ["Check", "Result", "Detail"], rows);
  }
  if (facts.table_counts) {
    section(box, "Largest Tables (estimated rows)");
    table(box, ["Schema", "Table", "Est. Rows", "Size"],
      facts.table_counts.map(t => [t.schema, t.table, String(t.est_rows), t.total_size]));
  }
  if (facts.bluegreen_status) {
    section(box, "Blue/Green Deployment");
    const b = facts.bluegreen_status;
    kv(box, { Identifier: b.identifier, Status: b.status, Source: b.source, Target: b.target });
  }
  if (facts.post_switchover_version) {
    section(box, "Post-Switchover");
    kv(box, { "Server version": facts.post_switchover_version });
  }
}

function section(box, title) { box.appendChild(el("h3", null, title)); }
function kv(box, obj) {
  const grid = el("div", "kv");
  for (const [k, v] of Object.entries(obj)) {
    grid.appendChild(el("div", "k", k));
    grid.appendChild(el("div", "v", v == null ? "-" : String(v)));
  }
  box.appendChild(grid);
}
function table(box, headers, rows) {
  const t = el("table");
  const thead = el("tr");
  headers.forEach(h => thead.appendChild(el("th", null, h)));
  t.appendChild(thead);
  rows.forEach(r => {
    const tr = el("tr");
    r.forEach(c => {
      const td = el("td");
      if (c instanceof Node) td.appendChild(c); else td.textContent = c;
      tr.appendChild(td);
    });
    t.appendChild(tr);
  });
  box.appendChild(t);
}

// ---- Tabs & modal ------------------------------------------------------------
document.querySelectorAll(".tab").forEach(tab => {
  tab.onclick = () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tabpane").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    $("#tab-" + tab.dataset.tab).classList.add("active");
  };
});
$("#modal-cancel").onclick = () => { $("#modal").classList.add("hidden"); pendingRun = null; };
$("#modal-confirm").onclick = () => {
  $("#modal").classList.add("hidden");
  if (pendingRun) { runStep(pendingRun.id, true); pendingRun = null; }
};

// ---- Boot --------------------------------------------------------------------
async function boot() {
  try {
    const cfg = await (await fetch("/api/config")).json();
    $("#subtitle").textContent =
      `${cfg.db_instance_identifier} · ${cfg.region || "default region"} · target ${cfg.target_engine_version} · profile ${cfg.sso_profile}`;
  } catch {}
  startStream();
  refreshState();
  setInterval(refreshState, 5000);
}
boot();

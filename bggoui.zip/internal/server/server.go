// Package server exposes the workflow over a small local HTTP API and serves the
// single-page UI. Steps run asynchronously; progress and state transitions are
// pushed to the browser via Server-Sent Events sourced from the logger.
package server

import (
	"context"
	"embed"
	"encoding/json"
	"fmt"
	"io/fs"
	"net/http"
	"sync"
	"time"

	"bgg/internal/logger"
	"bgg/internal/workflow"
)

//go:embed web/*
var webFS embed.FS

// Server wires the workflow to HTTP.
type Server struct {
	wf     *workflow.Workflow
	log    *logger.Logger
	mux    *http.ServeMux
	busyMu sync.Mutex
	busy   string // id of the currently-running step, "" if idle
}

// New builds a Server.
func New(wf *workflow.Workflow, log *logger.Logger) *Server {
	s := &Server{wf: wf, log: log, mux: http.NewServeMux()}
	s.routes()
	return s
}

// Handler returns the root http.Handler.
func (s *Server) Handler() http.Handler { return s.mux }

func (s *Server) routes() {
	sub, _ := fs.Sub(webFS, "web")
	s.mux.Handle("/", http.FileServer(http.FS(sub)))
	s.mux.HandleFunc("/api/state", s.handleState)
	s.mux.HandleFunc("/api/run", s.handleRun)
	s.mux.HandleFunc("/api/events", s.handleEvents)
	s.mux.HandleFunc("/api/config", s.handleConfig)
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// handleState returns step statuses + accumulated facts.
func (s *Server) handleState(w http.ResponseWriter, r *http.Request) {
	s.busyMu.Lock()
	busy := s.busy
	s.busyMu.Unlock()
	writeJSON(w, http.StatusOK, map[string]any{
		"steps":   s.wf.State.Steps(),
		"facts":   s.wf.State.Facts.Snapshot(),
		"busy":    busy,
		"logfile": s.log.Path(),
	})
}

// handleConfig returns a redacted view of the active configuration.
func (s *Server) handleConfig(w http.ResponseWriter, r *http.Request) {
	c := s.wf.Cfg
	writeJSON(w, http.StatusOK, map[string]any{
		"sso_profile":            c.AWS.SSOProfile,
		"region":                 c.AWS.Region,
		"db_instance_identifier": c.AWS.DBInstanceIdentifier,
		"target_engine_version":  c.Upgrade.TargetEngineVersion,
		"db_user":                c.Database.User,
		"db_name":                c.Database.DBName,
	})
}

// handleRun starts a step asynchronously. Mutating steps require confirm=true.
func (s *Server) handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST only"})
		return
	}
	id := r.URL.Query().Get("step")
	step, ok := s.wf.StepByID(id)
	if !ok {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown step " + id})
		return
	}
	if step.Mutating && r.URL.Query().Get("confirm") != "true" {
		writeJSON(w, http.StatusPreconditionRequired, map[string]any{
			"error":          "confirmation required",
			"confirm_prompt": fmt.Sprintf("Step %q performs changes in AWS/your database. Proceed?", step.Name),
			"mutating":       true,
		})
		return
	}

	s.busyMu.Lock()
	if s.busy != "" {
		s.busyMu.Unlock()
		writeJSON(w, http.StatusConflict, map[string]string{"error": "another step is running: " + s.busy})
		return
	}
	s.busy = id
	s.busyMu.Unlock()

	go func() {
		// A generous independent context so a long provision/switchover isn't tied
		// to the HTTP request lifetime.
		ctx, cancel := context.WithTimeout(context.Background(), 6*time.Hour)
		defer cancel()
		defer func() {
			s.busyMu.Lock()
			s.busy = ""
			s.busyMu.Unlock()
		}()
		_ = s.wf.RunStep(ctx, id)
	}()

	writeJSON(w, http.StatusAccepted, map[string]string{"status": "started", "step": id})
}

// handleEvents streams log events as SSE, replaying history first.
func (s *Server) handleEvents(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")

	_, history, ch, cancel := s.log.Subscribe()
	defer cancel()

	send := func(e logger.Event) bool {
		b, err := logger.MarshalEvent(e)
		if err != nil {
			return true
		}
		if _, err := fmt.Fprintf(w, "data: %s\n\n", b); err != nil {
			return false
		}
		flusher.Flush()
		return true
	}

	for _, e := range history {
		if !send(e) {
			return
		}
	}

	keepalive := time.NewTicker(20 * time.Second)
	defer keepalive.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case e, ok := <-ch:
			if !ok {
				return
			}
			if !send(e) {
				return
			}
		case <-keepalive.C:
			if _, err := fmt.Fprintf(w, ": keepalive\n\n"); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

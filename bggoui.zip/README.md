# bgg — RDS PostgreSQL Blue/Green Major-Version Upgrade Tool

An interactive, enterprise-grade tool to perform AWS RDS for PostgreSQL **major
version upgrades** using [Blue/Green deployments](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/blue-green-deployments-overview.html).

It runs as a local web UI **and** a CLI — both drive the exact same workflow
steps. Every action is appended to a log file named
`<db_instance_identifier>-<timestamp>.log`.

## How it works

- **Web UI**: workflow steps are vertically-stacked buttons on the left; the
  right display area streams live activity and state transitions, plus a
  *Findings* tab with structured results. Each button's colour reflects its
  status (grey = pending, blue = running, green = done, amber = action needed,
  red = error). Mutating steps pop a confirmation dialog before running.
- **State-driven waits**: provisioning and switchover wait on *AWS state changes*
  (polling `DescribeBlueGreenDeployments`), never on fixed timers. Every status
  or task-progress change is logged.
- **Auth**: AWS IAM Identity Center (SSO) using a profile from `~/.aws/config`.
  An active cached session is reused; otherwise a browser device-login is
  started against the profile's start URL.

## Configuration

Copy `credentials.toml.example` to `credentials.toml` (kept beside the
executable) and fill it in. Key fields:

| Key | Meaning |
|-----|---------|
| `aws.sso_profile` | Profile in `~/.aws/config` (with `sso_*` settings) |
| `aws.db_instance_identifier` | Source ("blue") RDS instance |
| `database.*` | Postgres login (host defaults to the instance endpoint) |
| `upgrade.target_engine_version` | Target major version, e.g. `16.4` |
| `upgrade.*_parameter_group_file` | JSON specs for the green env's parameter groups |

## Build & run

```bash
go build -o bgg .

# Web UI (default) — opens the browser at http://127.0.0.1:8765
./bgg                       # uses ./credentials.toml next to the binary
./bgg -config /path/to/credentials.toml

# CLI
./bgg steps                 # list steps
./bgg step login            # run a single step
./bgg run-all -yes          # run everything (auto-confirm mutating steps)
```

## Workflow steps

1. **AWS & Database Login** — SSO login → `sts:GetCallerIdentity` →
   `DescribeDBInstance`, classify topology, save the current parameter group(s)
   to file, then connect to Postgres and confirm the login.
2. **Preflight Checks** — current vs target version, topology + the Blue/Green
   upgrade path for that topology, databases & schemas, extensions, estimated
   table row counts, and SQL preconditions (logical-replication readiness,
   primary keys, unsupported `reg*` types, long transactions).
3. **Enable Logical Replication** *(mutating)* — sets `rds.logical_replication`
   on the cluster/instance parameter group if needed and parks the step in the
   *action-needed* state pending a reboot; re-run to verify `wal_level=logical`.
4. **Provision Green** *(mutating)* — creates the Blue/Green deployment at the
   target version (ensuring target parameter groups exist), then waits for the
   green environment to become `AVAILABLE`, streaming each state change.
5. **Switchover & Connectivity Tests** *(mutating)* — triggers the cutover,
   waits for `SWITCHOVER_COMPLETED`, then reconnects and runs basic connectivity
   checks (ping, identity, version matches the target major).

## Topologies supported

Single-AZ, Multi-AZ instance (standby), Multi-AZ DB cluster, Aurora PostgreSQL,
and Aurora Serverless v2 are detected and explained. Read replicas are flagged
(upgrade the source instead).

## Project layout

```
main.go                     CLI + server entry point
internal/config             TOML loading & validation
internal/logger             file log + live event fan-out (SSE/stdout)
internal/state              step status + accumulated facts
internal/awsx               SSO login, STS, RDS describe, Blue/Green, params
internal/dbx                Postgres connection + preflight SQL
internal/workflow           step definitions & orchestration
internal/server             HTTP API + embedded web UI
```

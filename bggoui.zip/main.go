// Command bgg is an interactive, enterprise-grade tool for performing AWS RDS for
// PostgreSQL major-version upgrades using Blue/Green deployments. It can run as a
// local web UI (the default) or drive any individual workflow step from the CLI.
//
// Configuration (SSO profile, target instance, DB credentials, target version and
// parameter-group files) is read from a TOML file that lives beside the
// executable (credentials.toml by default; override with -config).
package main

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"strings"
	"syscall"
	"time"

	"bgg/internal/config"
	"bgg/internal/logger"
	"bgg/internal/server"
	"bgg/internal/workflow"
)

func main() {
	cfgPath := flag.String("config", config.DefaultPath(), "path to the TOML config file")
	autoYes := flag.Bool("yes", false, "auto-confirm mutating steps when running from the CLI")
	noBrowser := flag.Bool("no-browser", false, "do not auto-open the browser in serve mode")
	flag.Usage = usage
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		fatalf("config: %v", err)
	}

	// Log file: "<instance>-<timestamp>.log" in the config's directory.
	log, err := logger.New(cfg.Dir(), cfg.AWS.DBInstanceIdentifier)
	if err != nil {
		fatalf("logger: %v", err)
	}
	defer log.Close()

	// Mirror events to stdout for CLI usage.
	mirrorToStdout(log)

	wf := workflow.New(cfg, log)
	defer wf.Close()

	args := flag.Args()
	cmd := "serve"
	if len(args) > 0 {
		cmd = args[0]
	}

	switch cmd {
	case "serve":
		runServe(cfg, wf, log, !*noBrowser)
	case "steps", "list":
		listSteps(wf)
	case "step", "run":
		if len(args) < 2 {
			fatalf("usage: %s step <step-id>", os.Args[0])
		}
		runOneStep(wf, args[1], *autoYes)
	case "run-all":
		runAll(wf, *autoYes)
	default:
		// Allow "bgg <step-id>" as a shortcut.
		if _, ok := wf.StepByID(cmd); ok {
			runOneStep(wf, cmd, *autoYes)
			return
		}
		usage()
		os.Exit(2)
	}
}

func runServe(cfg *config.Config, wf *workflow.Workflow, log *logger.Logger, openBrowser bool) {
	srv := server.New(wf, log)
	httpSrv := &http.Server{Addr: cfg.Server.Addr, Handler: srv.Handler()}

	go func() {
		log.Info("", "HTTP UI listening on http://%s", cfg.Server.Addr)
		if err := httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			fatalf("server: %v", err)
		}
	}()

	if openBrowser {
		go openURL("http://" + cfg.Server.Addr)
	}

	// Graceful shutdown on Ctrl-C.
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop
	log.Info("", "shutting down…")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = httpSrv.Shutdown(ctx)
}

func listSteps(wf *workflow.Workflow) {
	fmt.Println("Workflow steps:")
	for _, s := range wf.Steps() {
		mut := ""
		if s.Mutating {
			mut = "  [mutating]"
		}
		fmt.Printf("  %-20s %s%s\n", s.ID, s.Name, mut)
	}
}

func runOneStep(wf *workflow.Workflow, id string, autoYes bool) {
	step, ok := wf.StepByID(id)
	if !ok {
		fatalf("unknown step %q (use 'steps' to list)", id)
	}
	if step.Mutating && !autoYes {
		if !confirmTTY(fmt.Sprintf("Step %q is MUTATING and will change AWS/your database. Proceed? [y/N] ", step.Name)) {
			fmt.Println("aborted.")
			return
		}
	}
	ctx, cancel := signalContext()
	defer cancel()
	if err := wf.RunStep(ctx, id); err != nil {
		fatalf("step %s failed: %v", id, err)
	}
}

func runAll(wf *workflow.Workflow, autoYes bool) {
	ctx, cancel := signalContext()
	defer cancel()
	for _, s := range wf.Steps() {
		if s.Mutating && !autoYes {
			if !confirmTTY(fmt.Sprintf("Next step %q is MUTATING. Proceed? [y/N] ", s.Name)) {
				fmt.Println("stopped before mutating step.")
				return
			}
		}
		if err := wf.RunStep(ctx, s.ID); err != nil {
			fatalf("step %s failed: %v", s.ID, err)
		}
		// A blocked step (e.g. awaiting reboot) halts the run-all chain.
		if st, _ := wf.State.Get(s.ID); st.Status == "blocked" {
			fmt.Printf("\nStep %q needs an out-of-band action (%s). Resolve it, then re-run.\n", s.Name, st.Detail)
			return
		}
	}
	fmt.Println("\nAll steps completed.")
}

// signalContext returns a context cancelled on Ctrl-C.
func signalContext() (context.Context, context.CancelFunc) {
	ctx, cancel := context.WithCancel(context.Background())
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, os.Interrupt, syscall.SIGTERM)
	go func() { <-ch; cancel() }()
	return ctx, cancel
}

func confirmTTY(prompt string) bool {
	fmt.Print(prompt)
	var resp string
	_, _ = fmt.Scanln(&resp)
	resp = strings.ToLower(strings.TrimSpace(resp))
	return resp == "y" || resp == "yes"
}

// mirrorToStdout subscribes to the logger and prints events to stdout so CLI runs
// show the same activity the UI streams.
func mirrorToStdout(log *logger.Logger) {
	_, _, ch, _ := log.Subscribe()
	go func() {
		for e := range ch {
			step := ""
			if e.Step != "" {
				step = "[" + e.Step + "] "
			}
			fmt.Printf("%s %-7s %s%s\n", e.Time.Format("15:04:05"), e.Level, step, e.Message)
		}
	}()
}

func openURL(url string) {
	var cmd string
	var args []string
	switch runtime.GOOS {
	case "darwin":
		cmd = "open"
	case "windows":
		cmd, args = "rundll32", []string{"url.dll,FileProtocolHandler"}
	default:
		cmd = "xdg-open"
	}
	_ = exec.Command(cmd, append(args, url)...).Start()
}

func usage() {
	fmt.Fprintf(os.Stderr, `bgg — RDS PostgreSQL Blue/Green major-version upgrade tool

Usage:
  bgg [flags] [command]

Commands:
  serve            Start the interactive web UI (default)
  steps            List the workflow steps
  step <id>        Run a single step from the CLI
  run-all          Run every step in order (stops at mutating steps unless -yes)
  <step-id>        Shortcut for: step <step-id>

Flags:
`)
	flag.PrintDefaults()
}

func fatalf(format string, a ...any) {
	fmt.Fprintf(os.Stderr, "error: "+format+"\n", a...)
	os.Exit(1)
}

# RDS PostgreSQL Major Version Upgrade using AWS CDK TypeScript

## Overview

This guide covers upgrading a standalone RDS PostgreSQL instance from one major version to another using AWS CDK TypeScript constructs.

## Key Considerations Before Upgrading

1. **Backup retention must be > 0** - RDS takes snapshots during the upgrade process
2. **Read replicas** - In-region read replicas are automatically upgraded with the primary
3. **No rollback** - After upgrade completes, you cannot revert to the previous version
4. **Downtime** - Expect several minutes of unavailability during the upgrade
5. **Parameter groups** - Must use a parameter group compatible with the target version

## Pre-Upgrade Checklist

```bash
# Check valid upgrade targets for your current version
aws rds describe-db-engine-versions \
  --engine postgres \
  --engine-version YOUR_CURRENT_VERSION \
  --query 'DBEngineVersions[].ValidUpgradeTarget[].EngineVersion'

# Example: Check upgrade paths from version 14.10
aws rds describe-db-engine-versions \
  --engine postgres \
  --engine-version 14.10 \
  --query 'DBEngineVersions[].ValidUpgradeTarget[].EngineVersion'
```

## CDK Implementation

### Before Upgrade (Original Stack)

```typescript
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import { Construct } from 'constructs';

export class RdsPostgresStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const vpc = new ec2.Vpc(this, 'Vpc', {
      maxAzs: 2,
    });

    // Original PostgreSQL 14 instance
    const dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: rds.PostgresEngineVersion.VER_14_10,
      }),
      instanceType: ec2.InstanceType.of(
        ec2.InstanceClass.T3,
        ec2.InstanceSize.MEDIUM
      ),
      vpc,
      vpcSubnets: {
        subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
      },
      allocatedStorage: 100,
      maxAllocatedStorage: 200,
      databaseName: 'myapp',
      credentials: rds.Credentials.fromGeneratedSecret('postgres'),
      backupRetention: cdk.Duration.days(7), // Required for upgrades
      deletionProtection: true,
    });
  }
}
```

### After Upgrade (Modified Stack)

To perform the major version upgrade, modify your CDK stack with these key changes:

```typescript
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import { Construct } from 'constructs';

export class RdsPostgresStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const vpc = new ec2.Vpc(this, 'Vpc', {
      maxAzs: 2,
    });

    // Create a new parameter group for the target version
    const parameterGroup = new rds.ParameterGroup(this, 'PostgresParamGroup', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: rds.PostgresEngineVersion.VER_16_6,
      }),
      description: 'Parameter group for PostgreSQL 16',
      parameters: {
        // Add any custom parameters here
        'log_statement': 'all',
        'log_min_duration_statement': '1000',
      },
    });

    // Upgraded PostgreSQL 16 instance
    const dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: rds.PostgresEngineVersion.VER_16_6, // Target version
      }),
      instanceType: ec2.InstanceType.of(
        ec2.InstanceClass.T3,
        ec2.InstanceSize.MEDIUM
      ),
      vpc,
      vpcSubnets: {
        subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
      },
      allocatedStorage: 100,
      maxAllocatedStorage: 200,
      databaseName: 'myapp',
      credentials: rds.Credentials.fromGeneratedSecret('postgres'),
      backupRetention: cdk.Duration.days(7),
      deletionProtection: true,
      
      // CRITICAL: Enable major version upgrade
      allowMajorVersionUpgrade: true,
      
      // Use the new parameter group
      parameterGroup,
    });
  }
}
```

## Critical Property: `allowMajorVersionUpgrade`

The most important setting for major version upgrades is:

```typescript
allowMajorVersionUpgrade: true
```

Without this property set to `true`, CloudFormation will reject the stack update when attempting to change to a new major version.

## Using Custom/Latest Versions

If the CDK doesn't have a constant for your target version, use `PostgresEngineVersion.of()`:

```typescript
// For versions not yet in CDK constants
const customVersion = rds.PostgresEngineVersion.of(
  '16.6',  // Full version string
  '16'     // Major version string
);

const dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
  engine: rds.DatabaseInstanceEngine.postgres({
    version: customVersion,
  }),
  allowMajorVersionUpgrade: true,
  // ... other properties
});
```

## Parameter Group Handling

When upgrading major versions, the parameter group family changes (e.g., `postgres14` to `postgres16`). You have two options:

### Option 1: Let CDK Create Default Parameter Group

```typescript
// CDK will use the default parameter group for the new version
const dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
  engine: rds.DatabaseInstanceEngine.postgres({
    version: rds.PostgresEngineVersion.VER_16_6,
  }),
  allowMajorVersionUpgrade: true,
  // No parameterGroup specified - uses default
});
```

### Option 2: Create New Parameter Group (Recommended)

```typescript
// Create parameter group matching target version
const parameterGroup = new rds.ParameterGroup(this, 'PG16ParamGroup', {
  engine: rds.DatabaseInstanceEngine.postgres({
    version: rds.PostgresEngineVersion.VER_16_6,
  }),
  parameters: {
    // Your custom parameters
  },
});

const dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
  engine: rds.DatabaseInstanceEngine.postgres({
    version: rds.PostgresEngineVersion.VER_16_6,
  }),
  parameterGroup,
  allowMajorVersionUpgrade: true,
});
```

## Complete Upgrade Example

Here's a complete, production-ready example:

```typescript
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as kms from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';

interface RdsPostgresStackProps extends cdk.StackProps {
  postgresVersion: rds.PostgresEngineVersion;
  allowMajorVersionUpgrade?: boolean;
}

export class RdsPostgresStack extends cdk.Stack {
  public readonly dbInstance: rds.DatabaseInstance;

  constructor(scope: Construct, id: string, props: RdsPostgresStackProps) {
    super(scope, id, props);

    // Import existing VPC or create new one
    const vpc = ec2.Vpc.fromLookup(this, 'Vpc', {
      vpcId: 'vpc-xxxxxxxxx', // Your VPC ID
    });

    // Or create new VPC
    // const vpc = new ec2.Vpc(this, 'Vpc', { maxAzs: 2 });

    // Security group for RDS
    const dbSecurityGroup = new ec2.SecurityGroup(this, 'DbSecurityGroup', {
      vpc,
      description: 'Security group for PostgreSQL RDS',
      allowAllOutbound: false,
    });

    // KMS key for encryption
    const kmsKey = new kms.Key(this, 'DbEncryptionKey', {
      enableKeyRotation: true,
      description: 'KMS key for RDS encryption',
    });

    // Parameter group for target version
    const parameterGroup = new rds.ParameterGroup(this, 'PostgresParamGroup', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: props.postgresVersion,
      }),
      description: `Parameter group for PostgreSQL ${props.postgresVersion.postgresMajorVersion}`,
      parameters: {
        'shared_preload_libraries': 'pg_stat_statements',
        'log_statement': 'ddl',
        'log_min_duration_statement': '5000',
      },
    });

    // Create the database instance
    this.dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: props.postgresVersion,
      }),
      instanceType: ec2.InstanceType.of(
        ec2.InstanceClass.R6G,
        ec2.InstanceSize.LARGE
      ),
      vpc,
      vpcSubnets: {
        subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
      },
      securityGroups: [dbSecurityGroup],
      
      // Storage configuration
      allocatedStorage: 100,
      maxAllocatedStorage: 500,
      storageType: rds.StorageType.GP3,
      storageEncrypted: true,
      storageEncryptionKey: kmsKey,
      
      // Database configuration
      databaseName: 'myapp',
      credentials: rds.Credentials.fromGeneratedSecret('postgres', {
        secretName: '/rds/postgres/credentials',
      }),
      parameterGroup,
      
      // Backup and maintenance
      backupRetention: cdk.Duration.days(14),
      preferredBackupWindow: '03:00-04:00',
      preferredMaintenanceWindow: 'sun:04:00-sun:05:00',
      
      // High availability (optional for standalone)
      multiAz: false,
      
      // Monitoring
      enablePerformanceInsights: true,
      performanceInsightRetention: rds.PerformanceInsightRetention.DEFAULT,
      cloudwatchLogsExports: ['postgresql', 'upgrade'],
      
      // Protection
      deletionProtection: true,
      
      // CRITICAL FOR MAJOR VERSION UPGRADE
      allowMajorVersionUpgrade: props.allowMajorVersionUpgrade ?? false,
      
      // Auto minor version upgrade
      autoMinorVersionUpgrade: true,
    });

    // Outputs
    new cdk.CfnOutput(this, 'DbEndpoint', {
      value: this.dbInstance.dbInstanceEndpointAddress,
      description: 'Database endpoint',
    });

    new cdk.CfnOutput(this, 'DbSecretArn', {
      value: this.dbInstance.secret?.secretArn ?? 'N/A',
      description: 'Secret ARN for database credentials',
    });
  }
}
```

### Usage in bin/app.ts

```typescript
#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import { RdsPostgresStack } from '../lib/rds-postgres-stack';

const app = new cdk.App();

// For initial deployment (PostgreSQL 14)
// new RdsPostgresStack(app, 'RdsPostgresStack', {
//   postgresVersion: rds.PostgresEngineVersion.VER_14_10,
//   allowMajorVersionUpgrade: false,
// });

// For major version upgrade (PostgreSQL 14 -> 16)
new RdsPostgresStack(app, 'RdsPostgresStack', {
  postgresVersion: rds.PostgresEngineVersion.VER_16_6,
  allowMajorVersionUpgrade: true, // REQUIRED for upgrade
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION,
  },
});
```

## Deployment Commands

```bash
# Preview changes
cdk diff

# Deploy the upgrade
cdk deploy

# Or deploy without approval prompts (use with caution)
cdk deploy --require-approval never
```

## Available PostgreSQL Versions in CDK

Current major versions available (as of CDK v2.232.1):

| Major Version | Example CDK Constants |
|---------------|----------------------|
| 13 | `VER_13_18`, `VER_13_20`, `VER_13_21`, `VER_13_22`, `VER_13_23` |
| 14 | `VER_14_15`, `VER_14_17`, `VER_14_18`, `VER_14_19`, `VER_14_20` |
| 15 | `VER_15_10`, `VER_15_12`, `VER_15_13`, `VER_15_14`, `VER_15_15` |
| 16 | `VER_16_6`, `VER_16_7`, `VER_16_8`, `VER_16_10`, `VER_16_11` |

## Common Upgrade Paths

- PostgreSQL 13.x → 14.x, 15.x, or 16.x
- PostgreSQL 14.x → 15.x or 16.x
- PostgreSQL 15.x → 16.x

RDS supports skipping major versions (e.g., 13 → 16 directly).

## Troubleshooting

### Error: "Cannot upgrade from X to Y"

Verify the upgrade path is valid:
```bash
aws rds describe-db-engine-versions --engine postgres --engine-version YOUR_VERSION
```

### Parameter Group Issues

If you see parameter group errors, ensure you've created a new parameter group for the target version family.

### Extension Compatibility

Check that all installed extensions are compatible with the target version:
```sql
SELECT * FROM pg_available_extensions WHERE installed_version IS NOT NULL;
```

## Blue/Green Deployment Alternative

For minimal downtime, consider using RDS Blue/Green deployments:

```typescript
// Blue/Green is managed outside of CDK through AWS Console or CLI
// After successful switchover, update your CDK stack to match the new configuration
```

## Post-Upgrade Steps

1. Run `ANALYZE` on all tables to update statistics
2. Test application connectivity
3. Verify extension functionality
4. Monitor performance metrics
5. Update any client driver versions if needed

```sql
-- After upgrade, analyze all tables
ANALYZE VERBOSE;
```

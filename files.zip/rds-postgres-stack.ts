import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as kms from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';

/**
 * Configuration interface for RDS PostgreSQL stack
 */
export interface RdsPostgresStackProps extends cdk.StackProps {
  /**
   * The PostgreSQL engine version to use
   */
  postgresVersion: rds.PostgresEngineVersion;
  
  /**
   * Whether to allow major version upgrades
   * Set to true when upgrading from one major version to another
   * @default false
   */
  allowMajorVersionUpgrade?: boolean;
  
  /**
   * VPC ID to deploy the database into (if using existing VPC)
   * If not provided, a new VPC will be created
   */
  vpcId?: string;
  
  /**
   * Database name
   * @default 'myapp'
   */
  databaseName?: string;
  
  /**
   * Instance type for the database
   * @default r6g.large
   */
  instanceType?: ec2.InstanceType;
}

/**
 * CDK Stack for RDS PostgreSQL with support for major version upgrades
 * 
 * Usage for initial deployment:
 *   new RdsPostgresStack(app, 'RdsStack', {
 *     postgresVersion: rds.PostgresEngineVersion.VER_14_10,
 *   });
 * 
 * Usage for major version upgrade (14 -> 16):
 *   new RdsPostgresStack(app, 'RdsStack', {
 *     postgresVersion: rds.PostgresEngineVersion.VER_16_6,
 *     allowMajorVersionUpgrade: true,  // CRITICAL for upgrades
 *   });
 */
export class RdsPostgresStack extends cdk.Stack {
  public readonly dbInstance: rds.DatabaseInstance;
  public readonly dbSecurityGroup: ec2.SecurityGroup;
  public readonly dbSecret: cdk.aws_secretsmanager.ISecret;

  constructor(scope: Construct, id: string, props: RdsPostgresStackProps) {
    super(scope, id, props);

    // Get or create VPC
    const vpc = props.vpcId
      ? ec2.Vpc.fromLookup(this, 'Vpc', { vpcId: props.vpcId })
      : new ec2.Vpc(this, 'Vpc', {
          maxAzs: 2,
          natGateways: 1,
          subnetConfiguration: [
            {
              name: 'Public',
              subnetType: ec2.SubnetType.PUBLIC,
              cidrMask: 24,
            },
            {
              name: 'Private',
              subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
              cidrMask: 24,
            },
            {
              name: 'Isolated',
              subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
              cidrMask: 24,
            },
          ],
        });

    // Security group for RDS
    this.dbSecurityGroup = new ec2.SecurityGroup(this, 'DbSecurityGroup', {
      vpc,
      description: 'Security group for PostgreSQL RDS instance',
      allowAllOutbound: false,
    });

    // KMS key for encryption at rest
    const encryptionKey = new kms.Key(this, 'DbEncryptionKey', {
      enableKeyRotation: true,
      description: 'KMS key for RDS PostgreSQL encryption',
      alias: `alias/${id}-db-key`,
    });

    // Create parameter group for the target PostgreSQL version
    // This is important: parameter group family must match the engine version
    const parameterGroup = new rds.ParameterGroup(this, 'PostgresParamGroup', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: props.postgresVersion,
      }),
      description: `Parameter group for PostgreSQL ${props.postgresVersion.postgresMajorVersion}`,
      parameters: {
        // Performance tuning parameters
        'shared_preload_libraries': 'pg_stat_statements',
        
        // Logging parameters
        'log_statement': 'ddl',
        'log_min_duration_statement': '5000',
        'log_connections': '1',
        'log_disconnections': '1',
        
        // Memory parameters (adjust based on instance size)
        // 'shared_buffers': '{DBInstanceClassMemory/4}',
        // 'effective_cache_size': '{DBInstanceClassMemory*3/4}',
      },
    });

    // Default instance type
    const instanceType = props.instanceType ?? ec2.InstanceType.of(
      ec2.InstanceClass.R6G,
      ec2.InstanceSize.LARGE
    );

    // Create the database instance
    this.dbInstance = new rds.DatabaseInstance(this, 'PostgresInstance', {
      // Engine configuration
      engine: rds.DatabaseInstanceEngine.postgres({
        version: props.postgresVersion,
      }),
      
      // Instance configuration
      instanceType,
      
      // Network configuration
      vpc,
      vpcSubnets: {
        subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
      },
      securityGroups: [this.dbSecurityGroup],
      
      // Storage configuration
      allocatedStorage: 100,
      maxAllocatedStorage: 500,
      storageType: rds.StorageType.GP3,
      storageEncrypted: true,
      storageEncryptionKey: encryptionKey,
      
      // Database configuration
      databaseName: props.databaseName ?? 'myapp',
      credentials: rds.Credentials.fromGeneratedSecret('postgres', {
        secretName: `/${id}/postgres/credentials`,
        excludeCharacters: '"@/\\\'',
      }),
      parameterGroup,
      
      // Backup configuration
      // IMPORTANT: Must be > 0 for major version upgrades
      backupRetention: cdk.Duration.days(14),
      preferredBackupWindow: '03:00-04:00',      // UTC
      preferredMaintenanceWindow: 'sun:04:00-sun:05:00', // UTC
      
      // High availability (set to true for Multi-AZ)
      multiAz: false,
      
      // Monitoring
      enablePerformanceInsights: true,
      performanceInsightRetention: rds.PerformanceInsightRetention.DEFAULT,
      cloudwatchLogsExports: ['postgresql', 'upgrade'],
      
      // Protection
      deletionProtection: true,
      
      // ============================================
      // CRITICAL FOR MAJOR VERSION UPGRADE
      // ============================================
      // This MUST be set to true when changing major versions
      // e.g., from PostgreSQL 14.x to 16.x
      allowMajorVersionUpgrade: props.allowMajorVersionUpgrade ?? false,
      
      // Auto minor version upgrade (recommended)
      autoMinorVersionUpgrade: true,
      
      // Instance identifier (optional - CDK generates one if not specified)
      // instanceIdentifier: 'my-postgres-instance',
    });

    // Store the secret reference
    this.dbSecret = this.dbInstance.secret!;

    // ============================================
    // Stack Outputs
    // ============================================
    
    new cdk.CfnOutput(this, 'DbEndpoint', {
      value: this.dbInstance.dbInstanceEndpointAddress,
      description: 'Database endpoint address',
      exportName: `${id}-DbEndpoint`,
    });

    new cdk.CfnOutput(this, 'DbPort', {
      value: this.dbInstance.dbInstanceEndpointPort,
      description: 'Database port',
      exportName: `${id}-DbPort`,
    });

    new cdk.CfnOutput(this, 'DbSecretArn', {
      value: this.dbSecret.secretArn,
      description: 'ARN of the secret containing database credentials',
      exportName: `${id}-DbSecretArn`,
    });

    new cdk.CfnOutput(this, 'DbSecurityGroupId', {
      value: this.dbSecurityGroup.securityGroupId,
      description: 'Security group ID for the database',
      exportName: `${id}-DbSecurityGroupId`,
    });

    new cdk.CfnOutput(this, 'PostgresVersion', {
      value: props.postgresVersion.postgresFullVersion,
      description: 'PostgreSQL version',
    });
  }

  /**
   * Allow inbound PostgreSQL connections from a security group
   */
  public allowConnectionsFrom(
    peer: ec2.ISecurityGroup,
    description?: string
  ): void {
    this.dbSecurityGroup.addIngressRule(
      peer,
      ec2.Port.tcp(5432),
      description ?? 'Allow PostgreSQL connections'
    );
  }

  /**
   * Allow inbound PostgreSQL connections from a CIDR range
   */
  public allowConnectionsFromCidr(
    cidr: string,
    description?: string
  ): void {
    this.dbSecurityGroup.addIngressRule(
      ec2.Peer.ipv4(cidr),
      ec2.Port.tcp(5432),
      description ?? `Allow PostgreSQL connections from ${cidr}`
    );
  }
}

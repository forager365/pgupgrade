#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import { RdsPostgresStack } from '../lib/rds-postgres-stack';

const app = new cdk.App();

/**
 * Environment configuration
 * Set these via environment variables or CDK context
 */
const env = {
  account: process.env.CDK_DEFAULT_ACCOUNT || process.env.AWS_ACCOUNT_ID,
  region: process.env.CDK_DEFAULT_REGION || process.env.AWS_REGION || 'us-east-1',
};

/**
 * DEPLOYMENT SCENARIOS
 * 
 * Uncomment the appropriate section based on your deployment scenario
 */

// ============================================
// SCENARIO 1: Initial Deployment (PostgreSQL 14)
// ============================================
// Use this for the first deployment of your database
/*
new RdsPostgresStack(app, 'RdsPostgresStack', {
  env,
  postgresVersion: rds.PostgresEngineVersion.VER_14_10,
  allowMajorVersionUpgrade: false, // Not needed for initial deploy
  databaseName: 'myapp',
});
*/

// ============================================
// SCENARIO 2: Major Version Upgrade (14 -> 16)
// ============================================
// Use this to upgrade from PostgreSQL 14 to 16
// IMPORTANT: allowMajorVersionUpgrade MUST be true

new RdsPostgresStack(app, 'RdsPostgresStack', {
  env,
  postgresVersion: rds.PostgresEngineVersion.VER_16_6,
  allowMajorVersionUpgrade: true,  // CRITICAL: Required for major upgrade
  databaseName: 'myapp',
});


// ============================================
// SCENARIO 3: Using Custom/Latest Version
// ============================================
// Use this when CDK doesn't have a constant for your version
/*
const customVersion = rds.PostgresEngineVersion.of(
  '16.8',  // Full version string
  '16'     // Major version string
);

new RdsPostgresStack(app, 'RdsPostgresStack', {
  env,
  postgresVersion: customVersion,
  allowMajorVersionUpgrade: true,
  databaseName: 'myapp',
});
*/

// ============================================
// SCENARIO 4: Using Existing VPC
// ============================================
// Use this when deploying into an existing VPC
/*
new RdsPostgresStack(app, 'RdsPostgresStack', {
  env,
  postgresVersion: rds.PostgresEngineVersion.VER_16_6,
  allowMajorVersionUpgrade: true,
  vpcId: 'vpc-0123456789abcdef0',  // Your existing VPC ID
  databaseName: 'myapp',
});
*/

app.synth();

# pgupgrade

Config-driven CLI for performing major-version upgrades on AWS RDS PostgreSQL — single instances, Multi-AZ, Multi-AZ DB clusters, instances with read replicas, Aurora provisioned, and Aurora Serverless (v1 and v2).

The tool detects topology, validates the upgrade path, snapshots the database, creates target-family parameter groups (carrying over user-modified parameters), triggers the upgrade, waits for `available`, and runs post-upgrade validation including `ALTER EXTENSION ... UPDATE` for an operator-approved allowlist.

## Requirements

- Python 3.11+ (uses `tomllib`)
- AWS credentials with RDS modify permissions (`rds:DescribeDBInstances`, `rds:DescribeDBClusters`, `rds:CreateDB[Cluster]Snapshot`, `rds:CreateDB[Cluster]ParameterGroup`, `rds:ModifyDB[Cluster]ParameterGroup`, `rds:ModifyDBInstance`, `rds:ModifyDBCluster`, `rds:DescribeDBEngineVersions`)
- Postgres superuser (or rds_superuser) credentials to enumerate `pg_database`, `pg_extension`, and run `ALTER EXTENSION ... UPDATE`
- Network reachability to the RDS endpoint from where the tool runs

## Install

```bash
pip install -r requirements.txt
```

## Configure

Copy the example and fill in your environment:

```bash
cp config.toml.example config.toml
```

Key sections:

```toml
[aws]
region  = "us-east-1"
profile = "default"

[database]
host           = "mydb.abc123.us-east-1.rds.amazonaws.com"
port           = 5432
dbname         = "postgres"
user           = "postgres_admin"
password       = "REPLACE_ME"
sslmode        = "require"
sslcertpath    = "/etc/ssl/certs/rds-global-bundle.pem"
target_version = "16.4"
# identifier   = "mydb"   # optional; otherwise derived by matching host

[snapshot]
identifier_prefix = "preupgrade"

[paramgroup]
instance_suffix = "inst"
cluster_suffix  = "clstr"

[extensions]
auto_update_after_upgrade = ["pg_stat_statements", "hstore", "citext"]

[logging]
level    = "INFO"
log_file = "pgupgrade.log"
```

## Subcommands

| Command    | Mutates? | What it does                                                                |
|------------|----------|-----------------------------------------------------------------------------|
| `dry-run`  | No       | Inspects state, validates the plan, reports findings, exits non-zero if blocked |
| `upgrade`  | Yes      | Snapshots, copies parameter groups, triggers upgrade, polls, then validates |
| `validate` | No       | Runs post-upgrade validation only (useful when upgrade was driven manually) |

## Usage examples

### 1. Inspect before upgrading

```bash
python -m pgupgrade -c config.toml dry-run
```

Prints the RDS describe payload (passwords redacted), the detected topology, current parameter groups, planned snapshot ID, planned new parameter group names, upgrade-path validity, every database, and every extension classified as `alter_update`, `drop_recreate`, `review`, or `unknown`.

Exit codes:
- `0` — plan is clean, safe to proceed
- `3` — Postgres connection failed
- `4` — `target_version` is not a valid major upgrade from the current version
- `5` — `drop_recreate` extensions present; resolve manually before running `upgrade`

### 2. Run the upgrade end-to-end

```bash
python -m pgupgrade -c config.toml upgrade
```

The flow:
1. Re-validates upgrade path
2. Refuses to proceed if any `drop_recreate` extension is installed
3. Takes a manual snapshot (`<prefix>-<identifier>-<current-version>-<UTC timestamp>`) and waits for `available`
4. Creates a parameter group in the target version's family (e.g. `postgres16`) named `<identifier>-v-<target-version>-{inst|clstr}` and copies user-modified parameters that exist in the target family (chunks of 20, AWS limit)
5. Issues `modify_db_instance` or `modify_db_cluster` with `AllowMajorVersionUpgrade=True` and the new parameter group, `ApplyImmediately=True`
6. Polls until the primary (and any read replicas / cluster members) returns to `available`
7. Runs the post-upgrade validation step

Run inside a long-running session (e.g. `tmux`, `screen`) — major-version upgrades typically take 15–60 minutes depending on database size.

### 3. Post-upgrade validation only

If the upgrade was kicked off via the AWS console and you want to run only the validation step:

```bash
python -m pgupgrade -c config.toml validate
```

This re-describes the target, asserts the new major version matches `target_version`, runs `SHOW server_version`, lists databases, and runs `ALTER EXTENSION ... UPDATE` for extensions in `extensions.auto_update_after_upgrade`. Exit code `7` if any extension update failed.

### 4. Targeting by explicit identifier

If the host-to-identifier match is ambiguous (shared endpoints, custom DNS), set `database.identifier`:

```toml
[database]
host       = "writer.example.internal"
identifier = "prod-orders-cluster"
```

The endpoint is still used for the Postgres connection; the identifier short-circuits AWS-side discovery.

## What "drop/recreate" means

Some extensions cannot be carried across a major-version upgrade by `pg_upgrade` and must be dropped before and recreated after. The tool **refuses to run `upgrade`** if any of these are installed:

- `pg_repack` — dropping during an active reorg is destructive; do this only when idle
- `pglogical` — dropping discards replication slot state; coordinate with downstream subscribers

Operator playbook when these are present:
1. Quiesce dependent processes
2. `DROP EXTENSION <name>` in every affected database
3. Re-run `python -m pgupgrade -c config.toml upgrade`
4. After the tool completes, `CREATE EXTENSION <name>` in those databases

## What "alter_update" means

Carried across by `pg_upgrade`, but the shared library on the new major needs to be relinked via `ALTER EXTENSION ... UPDATE` (e.g. `postgis`, `pg_stat_statements`, `hstore`, `citext`, `pgcrypto`). The tool only runs this for names listed in `extensions.auto_update_after_upgrade`. Everything else is reported and left alone — opt in deliberately.

## Topologies detected

| Value                       | Trigger                                                        |
|-----------------------------|----------------------------------------------------------------|
| `rds-single`                | Standalone instance, no Multi-AZ standby, no replicas          |
| `rds-multi-az`              | `MultiAZ=true`, no cluster                                     |
| `rds-multi-az-cluster`      | RDS Multi-AZ DB cluster (1 writer + 2 readers)                 |
| `rds-with-read-replicas`    | Instance with `ReadReplicaDBInstanceIdentifiers` set           |
| `aurora-provisioned`        | Aurora cluster, provisioned instance class                     |
| `aurora-serverless-v1`      | Aurora cluster with `EngineMode=serverless`                    |
| `aurora-serverless-v2`      | Aurora cluster with at least one `db.serverless` instance      |

Cluster upgrades modify `DBClusterParameterGroup` at the cluster level and attach the new instance-level parameter group to each member; instance read replicas roll automatically with the primary and are then waited on.

## Logging

Logs to stderr by default; if `logging.log_file` is set, logs are also written there. Set `logging.level = "DEBUG"` for boto3-level visibility into AWS calls. All RDS state transitions are logged when the status changes (every 30s poll).

## Exit codes

| Code | Meaning                                                                  |
|------|--------------------------------------------------------------------------|
| 0    | Success                                                                  |
| 2    | Target not found by host/identifier                                      |
| 3    | Postgres connection failed during dry-run                                |
| 4    | Invalid major-version upgrade path                                       |
| 5    | `drop_recreate` extensions present; manual remediation required          |
| 6    | After upgrade, engine version doesn't match configured `target_version`  |
| 7    | One or more post-upgrade `ALTER EXTENSION ... UPDATE` calls failed       |

## Safety notes

- The tool always takes a manual pre-upgrade snapshot and waits for it. RDS also takes its own automatic snapshot during the modify; the manual one is named and persists per your retention policy.
- `ApplyImmediately=True` is used unconditionally; the upgrade window is *now*, not the next maintenance window. Schedule accordingly.
- The tool never `DROP`s extensions, never alters non-allowlisted extensions, never touches users/roles/databases content.
- Cross-family parameter copy preserves only `Source=user` parameters; defaults inherited from the new family stay at the new family's defaults — review with `aws rds describe-db-parameters` if you depend on a specific value.

from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator

import psycopg2
import psycopg2.extras

from pgupgrade.config import DatabaseConfig
from pgupgrade.extensions import ExtensionFinding, classify

log = logging.getLogger(__name__)


@contextmanager
def connect(cfg: DatabaseConfig, dbname: str | None = None) -> Iterator[psycopg2.extensions.connection]:
    kwargs = {
        "host": cfg.host,
        "port": cfg.port,
        "dbname": dbname or cfg.dbname,
        "user": cfg.user,
        "password": cfg.password,
        "sslmode": cfg.sslmode,
        "connect_timeout": 15,
    }
    if cfg.sslcertpath:
        kwargs["sslrootcert"] = cfg.sslcertpath
    conn = psycopg2.connect(**kwargs)
    conn.autocommit = True
    try:
        yield conn
    finally:
        conn.close()


def server_version(cfg: DatabaseConfig) -> str:
    with connect(cfg) as conn, conn.cursor() as cur:
        cur.execute("SHOW server_version")
        return cur.fetchone()[0]


def list_databases(cfg: DatabaseConfig) -> list[str]:
    with connect(cfg) as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT datname FROM pg_database "
            "WHERE datistemplate = false AND datallowconn = true "
            "ORDER BY datname"
        )
        return [r[0] for r in cur.fetchall()]


@dataclass
class DatabaseExtensions:
    dbname: str
    extensions: list[ExtensionFinding]


def list_extensions(cfg: DatabaseConfig, dbnames: list[str]) -> list[DatabaseExtensions]:
    out: list[DatabaseExtensions] = []
    for db in dbnames:
        try:
            with connect(cfg, dbname=db) as conn, conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT e.extname,
                           e.extversion,
                           n.nspname
                      FROM pg_extension e
                      JOIN pg_namespace n ON n.oid = e.extnamespace
                     ORDER BY e.extname
                    """
                )
                findings = [
                    ExtensionFinding(
                        name=row[0],
                        version=row[1],
                        schema=row[2],
                        category=classify(row[0]),
                    )
                    for row in cur.fetchall()
                ]
        except psycopg2.Error as e:
            log.warning("Cannot list extensions on %s: %s", db, e)
            findings = []
        out.append(DatabaseExtensions(dbname=db, extensions=findings))
    return out


def alter_extension_update(cfg: DatabaseConfig, dbname: str, ext: str) -> tuple[str, str]:
    """Run ALTER EXTENSION <ext> UPDATE and return (old_version, new_version)."""
    with connect(cfg, dbname=dbname) as conn, conn.cursor() as cur:
        cur.execute("SELECT extversion FROM pg_extension WHERE extname = %s", (ext,))
        row = cur.fetchone()
        old_version = row[0] if row else ""
        # Quoting: psycopg2 doesn't parameterize identifiers; ext names come from
        # pg_extension which restricts charset, so safe to interpolate after a
        # whitelist check.
        if not _safe_identifier(ext):
            raise ValueError(f"Refusing to ALTER EXTENSION on unsafe name: {ext!r}")
        cur.execute(f'ALTER EXTENSION "{ext}" UPDATE')
        cur.execute("SELECT extversion FROM pg_extension WHERE extname = %s", (ext,))
        new_version = cur.fetchone()[0]
    return old_version, new_version


def _safe_identifier(name: str) -> bool:
    return all(c.isalnum() or c in ("_", "-") for c in name) and len(name) <= 63

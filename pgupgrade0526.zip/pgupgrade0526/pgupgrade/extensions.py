from __future__ import annotations

from dataclasses import dataclass

# Extensions that historically require operator attention on a Postgres major
# version upgrade. The exact treatment varies by RDS family and source/target
# version; this table captures the operational classification used to decide
# what to surface in dry-run and what to ALTER EXTENSION ... UPDATE post-upgrade.
#
# Categories:
#   "drop_recreate" : pg_upgrade refuses to carry these across; must DROP before
#                     and CREATE after (or reinstall from backup). Highest risk.
#   "alter_update"  : carried across by pg_upgrade but require
#                     ALTER EXTENSION ... UPDATE after the upgrade to relink to
#                     the new shared library.
#   "review"        : may need manual review; behavior depends on version.
_EXTENSION_CLASS: dict[str, str] = {
    # Spatial / GIS
    "postgis": "alter_update",
    "postgis_topology": "alter_update",
    "postgis_raster": "alter_update",
    "postgis_tiger_geocoder": "alter_update",
    "address_standardizer": "alter_update",
    "address_standardizer_data_us": "alter_update",
    "pgrouting": "alter_update",
    # Reorg / maintenance
    "pg_repack": "drop_recreate",
    "pg_partman": "alter_update",
    # Stats / instrumentation
    "pg_stat_statements": "alter_update",
    "pg_hint_plan": "alter_update",
    "auto_explain": "alter_update",
    # Common contribs
    "hstore": "alter_update",
    "citext": "alter_update",
    "pgcrypto": "alter_update",
    "uuid-ossp": "alter_update",
    "ltree": "alter_update",
    "tablefunc": "alter_update",
    "btree_gin": "alter_update",
    "btree_gist": "alter_update",
    "intarray": "alter_update",
    "unaccent": "alter_update",
    # FDW / external
    "postgres_fdw": "alter_update",
    "dblink": "alter_update",
    "tds_fdw": "review",
    # AWS-specific
    "aws_s3": "review",
    "aws_commons": "review",
    "aws_lambda": "review",
    # Logical decoding / replication helpers
    "pglogical": "drop_recreate",
    "wal2json": "review",
}


@dataclass(frozen=True)
class ExtensionFinding:
    name: str
    version: str
    schema: str
    category: str  # "alter_update" | "drop_recreate" | "review" | "unknown"


def classify(name: str) -> str:
    return _EXTENSION_CLASS.get(name, "unknown")


def known_drop_recreate() -> set[str]:
    return {n for n, c in _EXTENSION_CLASS.items() if c == "drop_recreate"}


def known_alter_update() -> set[str]:
    return {n for n, c in _EXTENSION_CLASS.items() if c == "alter_update"}

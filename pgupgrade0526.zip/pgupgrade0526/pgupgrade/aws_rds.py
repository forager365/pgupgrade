from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any

import boto3
from botocore.config import Config as BotoConfig

log = logging.getLogger(__name__)


class Topology(str, Enum):
    RDS_SINGLE = "rds-single"
    RDS_MULTI_AZ = "rds-multi-az"
    RDS_MULTI_AZ_CLUSTER = "rds-multi-az-cluster"
    RDS_WITH_READ_REPLICAS = "rds-with-read-replicas"
    AURORA_PROVISIONED = "aurora-provisioned"
    AURORA_SERVERLESS_V1 = "aurora-serverless-v1"
    AURORA_SERVERLESS_V2 = "aurora-serverless-v2"


@dataclass
class TargetRef:
    """Resolved RDS target. Exactly one of instance/cluster identifier set,
    plus topology and the original describe payload for diagnostics."""

    topology: Topology
    instance_id: str | None
    cluster_id: str | None
    engine: str
    engine_version: str
    describe: dict[str, Any]
    # For instances: parameter group names per instance. For clusters: cluster PG + per-instance PGs.
    instance_param_groups: dict[str, str]
    cluster_param_group: str | None
    member_instance_ids: list[str]


def make_session(region: str, profile: str | None) -> boto3.Session:
    kwargs: dict[str, Any] = {"region_name": region}
    if profile:
        kwargs["profile_name"] = profile
    return boto3.Session(**kwargs)


def rds_client(session: boto3.Session) -> Any:
    return session.client("rds", config=BotoConfig(retries={"mode": "standard", "max_attempts": 5}))


# ---------- Topology discovery ----------

def discover_target(rds: Any, host: str, identifier: str | None) -> TargetRef:
    """Resolve the connection host (or explicit identifier) to an RDS instance
    or Aurora cluster, and classify the topology."""
    # Try cluster match first if identifier suggests cluster; otherwise try both.
    cluster = _find_cluster(rds, host, identifier)
    if cluster is not None:
        return _classify_cluster(rds, cluster)

    instance = _find_instance(rds, host, identifier)
    if instance is not None:
        return _classify_instance(rds, instance)

    raise LookupError(
        f"No RDS instance or Aurora cluster found matching host={host!r} identifier={identifier!r}"
    )


def _find_cluster(rds: Any, host: str, identifier: str | None) -> dict[str, Any] | None:
    paginator = rds.get_paginator("describe_db_clusters")
    for page in paginator.paginate():
        for c in page.get("DBClusters", []):
            if identifier and c.get("DBClusterIdentifier") == identifier:
                return c
            if not identifier and (c.get("Endpoint") == host or c.get("ReaderEndpoint") == host):
                return c
    return None


def _find_instance(rds: Any, host: str, identifier: str | None) -> dict[str, Any] | None:
    paginator = rds.get_paginator("describe_db_instances")
    for page in paginator.paginate():
        for inst in page.get("DBInstances", []):
            if identifier and inst.get("DBInstanceIdentifier") == identifier:
                return inst
            ep = inst.get("Endpoint", {}) or {}
            if not identifier and ep.get("Address") == host:
                return inst
    return None


def _classify_cluster(rds: Any, cluster: dict[str, Any]) -> TargetRef:
    engine = cluster["Engine"]
    engine_mode = cluster.get("EngineMode", "provisioned")
    member_ids = [m["DBInstanceIdentifier"] for m in cluster.get("DBClusterMembers", [])]

    if engine_mode == "serverless":
        topo = Topology.AURORA_SERVERLESS_V1
    else:
        # Serverless v2: provisioned mode but instance class is db.serverless
        v2 = False
        if member_ids:
            inst_descs = rds.describe_db_instances(
                Filters=[{"Name": "db-instance-id", "Values": member_ids}]
            ).get("DBInstances", [])
            v2 = any(i.get("DBInstanceClass") == "db.serverless" for i in inst_descs)
        topo = Topology.AURORA_SERVERLESS_V2 if v2 else Topology.AURORA_PROVISIONED

    # Per-instance parameter groups (cluster members each have an instance PG too).
    inst_pgs: dict[str, str] = {}
    if member_ids:
        inst_descs = rds.describe_db_instances(
            Filters=[{"Name": "db-instance-id", "Values": member_ids}]
        ).get("DBInstances", [])
        for i in inst_descs:
            pgs = i.get("DBParameterGroups", [])
            if pgs:
                inst_pgs[i["DBInstanceIdentifier"]] = pgs[0]["DBParameterGroupName"]

    return TargetRef(
        topology=topo,
        instance_id=None,
        cluster_id=cluster["DBClusterIdentifier"],
        engine=engine,
        engine_version=cluster["EngineVersion"],
        describe=cluster,
        instance_param_groups=inst_pgs,
        cluster_param_group=cluster.get("DBClusterParameterGroup"),
        member_instance_ids=member_ids,
    )


def _classify_instance(rds: Any, inst: dict[str, Any]) -> TargetRef:
    if inst.get("DBClusterIdentifier"):
        # It's an Aurora member; classify via the cluster instead.
        cluster_id = inst["DBClusterIdentifier"]
        clusters = rds.describe_db_clusters(DBClusterIdentifier=cluster_id).get("DBClusters", [])
        if clusters:
            return _classify_cluster(rds, clusters[0])

    is_multi_az_cluster = "ReplicationSourceIdentifier" not in inst and inst.get("DBClusterIdentifier") is None and len(inst.get("StatusInfos", [])) > 0 and any(s.get("StatusType") == "read replication" for s in inst.get("StatusInfos", []))
    # AWS Multi-AZ DB Cluster (3-node) shows up as a cluster, not a standalone instance,
    # so the typical case here is: single or Multi-AZ standby or has read replicas.
    has_read_replicas = bool(inst.get("ReadReplicaDBInstanceIdentifiers"))
    multi_az = bool(inst.get("MultiAZ"))

    if has_read_replicas:
        topo = Topology.RDS_WITH_READ_REPLICAS
    elif multi_az:
        topo = Topology.RDS_MULTI_AZ
    elif is_multi_az_cluster:
        topo = Topology.RDS_MULTI_AZ_CLUSTER
    else:
        topo = Topology.RDS_SINGLE

    inst_pgs: dict[str, str] = {}
    pgs = inst.get("DBParameterGroups", [])
    if pgs:
        inst_pgs[inst["DBInstanceIdentifier"]] = pgs[0]["DBParameterGroupName"]

    return TargetRef(
        topology=topo,
        instance_id=inst["DBInstanceIdentifier"],
        cluster_id=None,
        engine=inst["Engine"],
        engine_version=inst["EngineVersion"],
        describe=inst,
        instance_param_groups=inst_pgs,
        cluster_param_group=None,
        member_instance_ids=inst.get("ReadReplicaDBInstanceIdentifiers", []),
    )


# ---------- Upgrade path validation ----------

def valid_upgrade_target(rds: Any, engine: str, current_version: str, target_version: str) -> bool:
    resp = rds.describe_db_engine_versions(Engine=engine, EngineVersion=current_version)
    for ver in resp.get("DBEngineVersions", []):
        for tgt in ver.get("ValidUpgradeTarget", []):
            if tgt.get("EngineVersion") == target_version and tgt.get("IsMajorVersionUpgrade"):
                return True
    return False


def engine_family(rds: Any, engine: str, version: str) -> str:
    resp = rds.describe_db_engine_versions(Engine=engine, EngineVersion=version)
    versions = resp.get("DBEngineVersions", [])
    if not versions:
        raise LookupError(f"Unknown engine version {engine} {version}")
    return versions[0]["DBParameterGroupFamily"]


# ---------- Snapshot ----------

def snapshot_id(prefix: str, identifier: str, version: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%SZ")
    ver_safe = version.replace(".", "-")
    # RDS snapshot IDs: <=255 chars, letters/digits/hyphens, must start with a letter.
    return f"{prefix}-{identifier}-{ver_safe}-{ts}"


def create_snapshot(rds: Any, target: TargetRef, snap_id: str) -> dict[str, Any]:
    if target.cluster_id:
        log.info("Creating cluster snapshot %s for %s", snap_id, target.cluster_id)
        return rds.create_db_cluster_snapshot(
            DBClusterSnapshotIdentifier=snap_id,
            DBClusterIdentifier=target.cluster_id,
        )
    assert target.instance_id
    log.info("Creating instance snapshot %s for %s", snap_id, target.instance_id)
    return rds.create_db_snapshot(
        DBSnapshotIdentifier=snap_id,
        DBInstanceIdentifier=target.instance_id,
    )


def wait_snapshot_available(rds: Any, target: TargetRef, snap_id: str, timeout_s: int = 3600) -> None:
    if target.cluster_id:
        waiter = rds.get_waiter("db_cluster_snapshot_available")
        log.info("Waiting for cluster snapshot %s to be available", snap_id)
        waiter.wait(
            DBClusterSnapshotIdentifier=snap_id,
            WaiterConfig={"Delay": 30, "MaxAttempts": timeout_s // 30},
        )
    else:
        waiter = rds.get_waiter("db_snapshot_available")
        log.info("Waiting for instance snapshot %s to be available", snap_id)
        waiter.wait(
            DBSnapshotIdentifier=snap_id,
            WaiterConfig={"Delay": 30, "MaxAttempts": timeout_s // 30},
        )


# ---------- Parameter group copy across families ----------

def param_group_name(identifier: str, version: str, suffix: str) -> str:
    # RDS PG names: letters/digits/hyphens, must start with a letter.
    ver_safe = version.replace(".", "-")
    return f"{identifier}-v-{ver_safe}-{suffix}"


def copy_user_modified_params(
    rds: Any,
    source_name: str,
    target_name: str,
    target_family: str,
    is_cluster: bool,
) -> dict[str, Any]:
    """Create a new parameter group in `target_family` and apply the user-modified
    parameters from `source_name` that remain valid in the target family."""
    if is_cluster:
        describe = rds.describe_db_cluster_parameter_groups
        create = rds.create_db_cluster_parameter_group
        list_params = rds.describe_db_cluster_parameters
        modify = rds.modify_db_cluster_parameter_group
        kw_name = "DBClusterParameterGroupName"
    else:
        describe = rds.describe_db_parameter_groups
        create = rds.create_db_parameter_group
        list_params = rds.describe_db_parameters
        modify = rds.modify_db_parameter_group
        kw_name = "DBParameterGroupName"

    # Idempotency: skip create if already present.
    existing = []
    try:
        existing = describe(**{kw_name: target_name}).get(
            "DBClusterParameterGroups" if is_cluster else "DBParameterGroups", []
        )
    except rds.exceptions.ClientError:
        existing = []

    if not existing:
        log.info("Creating %s parameter group %s (family %s)",
                 "cluster" if is_cluster else "instance", target_name, target_family)
        create(**{
            kw_name: target_name,
            "DBParameterGroupFamily": target_family,
            "Description": f"Auto-created by pgupgrade from {source_name}",
        })
    else:
        log.info("Parameter group %s already exists; reusing", target_name)

    # Collect user-modified params from source.
    user_params: list[dict[str, Any]] = []
    paginator = rds.get_paginator(
        "describe_db_cluster_parameters" if is_cluster else "describe_db_parameters"
    )
    for page in paginator.paginate(**{kw_name: source_name, "Source": "user"}):
        items = page.get("Parameters", [])
        for p in items:
            if "ParameterName" in p and "ParameterValue" in p and p.get("IsModifiable", False):
                user_params.append({
                    "ParameterName": p["ParameterName"],
                    "ParameterValue": p["ParameterValue"],
                    "ApplyMethod": p.get("ApplyMethod", "pending-reboot"),
                })

    if not user_params:
        log.info("No user-modified parameters to copy from %s", source_name)
        return {"copied": 0, "target": target_name}

    # Validate each param is known in target family by listing once.
    target_known: set[str] = set()
    target_pager = rds.get_paginator(
        "describe_db_cluster_parameters" if is_cluster else "describe_db_parameters"
    )
    for page in target_pager.paginate(**{kw_name: target_name}):
        for p in page.get("Parameters", []):
            target_known.add(p["ParameterName"])

    applicable = [p for p in user_params if p["ParameterName"] in target_known]
    skipped = [p["ParameterName"] for p in user_params if p["ParameterName"] not in target_known]
    if skipped:
        log.warning("Skipping parameters absent in target family %s: %s", target_family, skipped)

    # Modify in chunks of 20 (AWS limit).
    for i in range(0, len(applicable), 20):
        modify(**{kw_name: target_name, "Parameters": applicable[i : i + 20]})

    log.info("Applied %d parameters to %s (skipped %d)", len(applicable), target_name, len(skipped))
    return {"copied": len(applicable), "skipped": len(skipped), "target": target_name}


# ---------- Initiate upgrade ----------

def initiate_instance_upgrade(
    rds: Any,
    instance_id: str,
    target_version: str,
    new_param_group: str,
    apply_immediately: bool = True,
) -> dict[str, Any]:
    log.info("Modifying instance %s: EngineVersion=%s, PG=%s, AllowMajorVersionUpgrade=True",
             instance_id, target_version, new_param_group)
    return rds.modify_db_instance(
        DBInstanceIdentifier=instance_id,
        EngineVersion=target_version,
        AllowMajorVersionUpgrade=True,
        DBParameterGroupName=new_param_group,
        ApplyImmediately=apply_immediately,
    )


def initiate_cluster_upgrade(
    rds: Any,
    cluster_id: str,
    target_version: str,
    new_cluster_param_group: str,
    apply_immediately: bool = True,
) -> dict[str, Any]:
    log.info("Modifying cluster %s: EngineVersion=%s, ClusterPG=%s, AllowMajorVersionUpgrade=True",
             cluster_id, target_version, new_cluster_param_group)
    return rds.modify_db_cluster(
        DBClusterIdentifier=cluster_id,
        EngineVersion=target_version,
        AllowMajorVersionUpgrade=True,
        DBClusterParameterGroup=new_cluster_param_group,
        ApplyImmediately=apply_immediately,
    )


def attach_instance_param_group(
    rds: Any,
    instance_id: str,
    new_param_group: str,
    apply_immediately: bool = True,
) -> dict[str, Any]:
    log.info("Attaching instance PG %s to %s", new_param_group, instance_id)
    return rds.modify_db_instance(
        DBInstanceIdentifier=instance_id,
        DBParameterGroupName=new_param_group,
        ApplyImmediately=apply_immediately,
    )


# ---------- Polling ----------

def wait_instance_available(rds: Any, instance_id: str, timeout_s: int = 7200) -> None:
    deadline = time.time() + timeout_s
    last_status = None
    while time.time() < deadline:
        descs = rds.describe_db_instances(DBInstanceIdentifier=instance_id).get("DBInstances", [])
        if not descs:
            raise LookupError(f"Instance disappeared during wait: {instance_id}")
        status = descs[0].get("DBInstanceStatus")
        if status != last_status:
            log.info("Instance %s status: %s", instance_id, status)
            last_status = status
        if status == "available":
            return
        time.sleep(30)
    raise TimeoutError(f"Timed out waiting for {instance_id} to become available")


def wait_cluster_available(rds: Any, cluster_id: str, timeout_s: int = 7200) -> None:
    deadline = time.time() + timeout_s
    last_status = None
    while time.time() < deadline:
        descs = rds.describe_db_clusters(DBClusterIdentifier=cluster_id).get("DBClusters", [])
        if not descs:
            raise LookupError(f"Cluster disappeared during wait: {cluster_id}")
        status = descs[0].get("Status")
        if status != last_status:
            log.info("Cluster %s status: %s", cluster_id, status)
            last_status = status
        if status == "available":
            return
        time.sleep(30)
    raise TimeoutError(f"Timed out waiting for {cluster_id} to become available")

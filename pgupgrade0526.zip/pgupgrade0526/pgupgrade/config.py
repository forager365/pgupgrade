from __future__ import annotations

import logging
import sys
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class AWSConfig:
    region: str
    profile: str | None


@dataclass
class DatabaseConfig:
    host: str
    port: int
    dbname: str
    user: str
    password: str
    sslmode: str
    sslcertpath: str | None
    target_version: str
    identifier: str | None


@dataclass
class SnapshotConfig:
    identifier_prefix: str


@dataclass
class ParamGroupConfig:
    instance_suffix: str
    cluster_suffix: str


@dataclass
class ExtensionsConfig:
    auto_update_after_upgrade: list[str] = field(default_factory=list)


@dataclass
class LoggingConfig:
    level: str
    log_file: str | None


@dataclass
class Config:
    aws: AWSConfig
    database: DatabaseConfig
    snapshot: SnapshotConfig
    paramgroup: ParamGroupConfig
    extensions: ExtensionsConfig
    logging: LoggingConfig


def load_config(path: str | Path) -> Config:
    path = Path(path)
    with path.open("rb") as f:
        raw: dict[str, Any] = tomllib.load(f)

    aws_raw = raw.get("aws", {})
    db_raw = raw.get("database", {})
    snap_raw = raw.get("snapshot", {})
    pg_raw = raw.get("paramgroup", {})
    ext_raw = raw.get("extensions", {})
    log_raw = raw.get("logging", {})

    return Config(
        aws=AWSConfig(
            region=_required(aws_raw, "aws.region"),
            profile=aws_raw.get("profile") or None,
        ),
        database=DatabaseConfig(
            host=_required(db_raw, "database.host"),
            port=int(db_raw.get("port", 5432)),
            dbname=_required(db_raw, "database.dbname"),
            user=_required(db_raw, "database.user"),
            password=_required(db_raw, "database.password"),
            sslmode=db_raw.get("sslmode", "require"),
            sslcertpath=db_raw.get("sslcertpath") or None,
            target_version=_required(db_raw, "database.target_version"),
            identifier=db_raw.get("identifier") or None,
        ),
        snapshot=SnapshotConfig(
            identifier_prefix=snap_raw.get("identifier_prefix", "preupgrade"),
        ),
        paramgroup=ParamGroupConfig(
            instance_suffix=pg_raw.get("instance_suffix", "inst"),
            cluster_suffix=pg_raw.get("cluster_suffix", "clstr"),
        ),
        extensions=ExtensionsConfig(
            auto_update_after_upgrade=list(ext_raw.get("auto_update_after_upgrade", [])),
        ),
        logging=LoggingConfig(
            level=log_raw.get("level", "INFO"),
            log_file=log_raw.get("log_file") or None,
        ),
    )


def _required(d: dict[str, Any], dotted_key: str) -> Any:
    section, key = dotted_key.split(".", 1)
    val = d.get(key)
    if val is None or val == "":
        raise ValueError(f"Missing required config key: {dotted_key}")
    return val


def configure_logging(cfg: LoggingConfig) -> None:
    level = getattr(logging, cfg.level.upper(), logging.INFO)
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if cfg.log_file:
        handlers.append(logging.FileHandler(cfg.log_file))
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )

from __future__ import annotations

import argparse
import json
import logging
import sys
from typing import Any

from pgupgrade import aws_rds, pg
from pgupgrade.config import Config, configure_logging, load_config

log = logging.getLogger("pgupgrade")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="pgupgrade", description="RDS Postgres major-version upgrade tool")
    p.add_argument("-c", "--config", default="config.toml", help="Path to config.toml")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("dry-run", help="Inspect state and validate plan without mutating anything")
    sub.add_parser("upgrade", help="Snapshot, copy parameter group, upgrade, validate")
    sub.add_parser("validate", help="Run post-upgrade validation only")
    args = p.parse_args(argv)

    cfg = load_config(args.config)
    configure_logging(cfg.logging)

    session = aws_rds.make_session(cfg.aws.region, cfg.aws.profile)
    rds = aws_rds.rds_client(session)

    try:
        target = aws_rds.discover_target(rds, cfg.database.host, cfg.database.identifier)
    except LookupError as e:
        log.error("%s", e)
        return 2

    log.info("Topology: %s", target.topology.value)
    log.info("Engine: %s %s", target.engine, target.engine_version)
    if target.cluster_id:
        log.info("Cluster: %s (members: %s)", target.cluster_id, target.member_instance_ids)
    else:
        log.info("Instance: %s", target.instance_id)

    if args.cmd == "dry-run":
        return _do_dry_run(cfg, rds, target)
    if args.cmd == "upgrade":
        return _do_upgrade(cfg, rds, target)
    if args.cmd == "validate":
        return _do_post_validate(cfg, rds, target, expected_version=cfg.database.target_version)
    return 1


# ---------- dry-run ----------

def _do_dry_run(cfg: Config, rds: Any, target: aws_rds.TargetRef) -> int:
    print("\n=== RDS describe ===")
    print(json.dumps(_sanitize_describe(target.describe), indent=2, default=str))

    print("\n=== Topology ===")
    print(target.topology.value)

    print("\n=== Parameter groups ===")
    if target.cluster_param_group:
        print(f"cluster: {target.cluster_param_group}")
    for inst_id, pg_name in target.instance_param_groups.items():
        print(f"instance {inst_id}: {pg_name}")

    identifier = target.cluster_id or target.instance_id
    assert identifier
    snap_name = aws_rds.snapshot_id(cfg.snapshot.identifier_prefix, identifier, target.engine_version)
    print(f"\n=== Planned snapshot ===\n{snap_name}")

    print("\n=== Planned target parameter groups ===")
    if target.cluster_param_group:
        new_cluster_pg = aws_rds.param_group_name(
            target.cluster_id or "", cfg.database.target_version, cfg.paramgroup.cluster_suffix
        )
        print(f"new cluster PG: {new_cluster_pg}")
    for inst_id in target.instance_param_groups:
        new_inst_pg = aws_rds.param_group_name(
            inst_id, cfg.database.target_version, cfg.paramgroup.instance_suffix
        )
        print(f"new instance PG ({inst_id}): {new_inst_pg}")

    print("\n=== Upgrade path validation ===")
    valid = aws_rds.valid_upgrade_target(
        rds, target.engine, target.engine_version, cfg.database.target_version
    )
    print(f"{target.engine_version} -> {cfg.database.target_version} valid major upgrade: {valid}")
    if not valid:
        log.error("Target version %s is not a valid major upgrade from %s",
                  cfg.database.target_version, target.engine_version)

    print("\n=== Databases ===")
    try:
        dbs = pg.list_databases(cfg.database)
    except Exception as e:
        log.error("Cannot connect to Postgres: %s", e)
        return 3
    for db in dbs:
        print(f"  {db}")

    print("\n=== Extensions ===")
    findings = pg.list_extensions(cfg.database, dbs)
    drop_recreate: list[tuple[str, str]] = []
    alter_update: list[tuple[str, str]] = []
    review: list[tuple[str, str]] = []
    unknown: list[tuple[str, str]] = []
    for db_ext in findings:
        print(f"\n  [{db_ext.dbname}]")
        for ext in db_ext.extensions:
            print(f"    {ext.name:30s} v{ext.version:10s} schema={ext.schema:15s} -> {ext.category}")
            tag = (db_ext.dbname, ext.name)
            if ext.category == "drop_recreate":
                drop_recreate.append(tag)
            elif ext.category == "alter_update":
                alter_update.append(tag)
            elif ext.category == "review":
                review.append(tag)
            else:
                unknown.append(tag)

    print("\n=== Extension action summary ===")
    print(f"  DROP/RECREATE required (operator action): {len(drop_recreate)}")
    for db, ext in drop_recreate:
        print(f"    - {db}.{ext}")
    print(f"  ALTER EXTENSION UPDATE post-upgrade:      {len(alter_update)}")
    for db, ext in alter_update:
        print(f"    - {db}.{ext}")
    print(f"  Manual review:                            {len(review)}")
    for db, ext in review:
        print(f"    - {db}.{ext}")
    print(f"  Unknown (will be left alone):             {len(unknown)}")

    if drop_recreate:
        log.warning("DROP/RECREATE extensions present. Resolve manually before running upgrade.")
    if not valid:
        return 4
    if drop_recreate:
        return 5
    return 0


# ---------- upgrade ----------

def _do_upgrade(cfg: Config, rds: Any, target: aws_rds.TargetRef) -> int:
    # 1. Pre-upgrade validation: upgrade path
    if not aws_rds.valid_upgrade_target(
        rds, target.engine, target.engine_version, cfg.database.target_version
    ):
        log.error("Invalid major-version upgrade path %s -> %s",
                  target.engine_version, cfg.database.target_version)
        return 4

    # 2. Pre-upgrade validation: dangerous extensions present?
    dbs = pg.list_databases(cfg.database)
    findings = pg.list_extensions(cfg.database, dbs)
    risky = [(d.dbname, e.name) for d in findings for e in d.extensions if e.category == "drop_recreate"]
    if risky:
        log.error("Refusing to upgrade: drop/recreate extensions present: %s", risky)
        log.error("Resolve manually (DROP, then run upgrade, then CREATE) and re-run.")
        return 5

    # 3. Snapshot + wait
    identifier = target.cluster_id or target.instance_id
    assert identifier
    snap_id = aws_rds.snapshot_id(cfg.snapshot.identifier_prefix, identifier, target.engine_version)
    aws_rds.create_snapshot(rds, target, snap_id)
    aws_rds.wait_snapshot_available(rds, target, snap_id)

    # 4. Build new parameter groups in target family
    target_family = aws_rds.engine_family(rds, target.engine, cfg.database.target_version)
    log.info("Target parameter group family: %s", target_family)

    new_cluster_pg: str | None = None
    if target.cluster_param_group:
        new_cluster_pg = aws_rds.param_group_name(
            target.cluster_id or "", cfg.database.target_version, cfg.paramgroup.cluster_suffix
        )
        aws_rds.copy_user_modified_params(
            rds,
            source_name=target.cluster_param_group,
            target_name=new_cluster_pg,
            target_family=target_family,
            is_cluster=True,
        )

    new_instance_pgs: dict[str, str] = {}
    for inst_id, src_pg in target.instance_param_groups.items():
        new_pg = aws_rds.param_group_name(
            inst_id, cfg.database.target_version, cfg.paramgroup.instance_suffix
        )
        aws_rds.copy_user_modified_params(
            rds,
            source_name=src_pg,
            target_name=new_pg,
            target_family=target_family,
            is_cluster=False,
        )
        new_instance_pgs[inst_id] = new_pg

    # 5. Initiate upgrade based on topology
    if target.cluster_id:
        # Aurora and Multi-AZ DB cluster: modify cluster; each instance PG gets attached after.
        assert new_cluster_pg
        aws_rds.initiate_cluster_upgrade(
            rds, target.cluster_id, cfg.database.target_version, new_cluster_pg
        )
        aws_rds.wait_cluster_available(rds, target.cluster_id)
        for inst_id, new_pg in new_instance_pgs.items():
            aws_rds.attach_instance_param_group(rds, inst_id, new_pg)
            aws_rds.wait_instance_available(rds, inst_id)
    else:
        assert target.instance_id
        new_pg = new_instance_pgs[target.instance_id]
        aws_rds.initiate_instance_upgrade(
            rds, target.instance_id, cfg.database.target_version, new_pg
        )
        aws_rds.wait_instance_available(rds, target.instance_id)
        # Read replicas auto-upgrade with the primary; just wait for each.
        for replica_id in target.member_instance_ids:
            aws_rds.wait_instance_available(rds, replica_id)

    # 6. Post-upgrade validation
    return _do_post_validate(cfg, rds, target, expected_version=cfg.database.target_version)


# ---------- post-upgrade validate ----------

def _do_post_validate(cfg: Config, rds: Any, target: aws_rds.TargetRef, expected_version: str) -> int:
    # Re-discover to pick up new engine version.
    target = aws_rds.discover_target(rds, cfg.database.host, cfg.database.identifier)
    actual = target.engine_version
    log.info("Engine version reported by RDS: %s (expected %s)", actual, expected_version)
    if not actual.startswith(expected_version.split(".")[0] + "."):
        log.error("Engine major version mismatch after upgrade")
        return 6

    server_v = pg.server_version(cfg.database)
    log.info("server_version (SQL): %s", server_v)

    dbs = pg.list_databases(cfg.database)
    log.info("Databases after upgrade: %d", len(dbs))

    findings = pg.list_extensions(cfg.database, dbs)
    allowed = set(cfg.extensions.auto_update_after_upgrade)
    updated: list[str] = []
    skipped: list[str] = []
    failed: list[str] = []
    for d in findings:
        for ext in d.extensions:
            if ext.name not in allowed:
                continue
            try:
                old_v, new_v = pg.alter_extension_update(cfg.database, d.dbname, ext.name)
                if old_v != new_v:
                    log.info("Updated %s.%s: %s -> %s", d.dbname, ext.name, old_v, new_v)
                    updated.append(f"{d.dbname}.{ext.name}")
                else:
                    log.info("%s.%s already at %s", d.dbname, ext.name, new_v)
                    skipped.append(f"{d.dbname}.{ext.name}")
            except Exception as e:
                log.error("ALTER EXTENSION %s on %s failed: %s", ext.name, d.dbname, e)
                failed.append(f"{d.dbname}.{ext.name}")

    print("\n=== Post-upgrade summary ===")
    print(f"  engine version: {actual}")
    print(f"  databases:      {len(dbs)}")
    print(f"  ext updated:    {len(updated)}")
    print(f"  ext at-version: {len(skipped)}")
    print(f"  ext failed:     {len(failed)}")

    return 7 if failed else 0


def _sanitize_describe(d: dict[str, Any]) -> dict[str, Any]:
    redacted = {"MasterUserPassword", "TdeCredentialPassword"}
    return {k: ("***" if k in redacted else v) for k, v in d.items()}


if __name__ == "__main__":
    sys.exit(main())

# bg-upgrade

Blue/Green upgrade orchestrator for AWS RDS PostgreSQL and Aurora PostgreSQL,
covering single-AZ, Multi-AZ, Multi-AZ + read replica, and Aurora cluster
topologies. Designed to be run from a central account that assumes a role into
each target account.

## What it does

For each target listed in the config file, the orchestrator runs the following
phases. Progress is persisted after each phase, so a failed run can be resumed
without re-doing completed work.

1. `INIT` — record target + resolve topology (RDS instance vs. Aurora cluster).
2. `PRECONDITIONS` — engine version is 14, automated backups on, logical
   replication enabled, no in-flight maintenance, storage headroom, B/G not
   already present, read replicas healthy, etc.
3. `PARAM_GROUP` — ensure a target-version parameter group exists with logical
   replication enabled (created if missing, never mutated in place).
4. `CREATE_BLUE_GREEN` — call `create_blue_green_deployment` with target
   engine version + target parameter group.
5. `WAIT_GREEN_AVAILABLE` — poll until the green environment reaches
   `AVAILABLE` and replication lag is within tolerance.
6. `PRE_SWITCHOVER_VALIDATION` — run lightweight checks against the green
   environment.
7. `SWITCHOVER` — `switchover_blue_green_deployment` with a configurable
   timeout.
8. `POST_VALIDATION` — confirm the renamed instance/cluster is on the new
   version, replicas (if any) followed, connections succeed.
9. `CLEANUP` — optionally delete the now-renamed blue resources.
10. `DONE`.

## Usage

```bash
pip install -e .
bg-upgrade \
    --config config/targets.yaml \
    --state-dir ./state \
    --log-group /rds/bg-upgrade \
    --target prod-orders-db   # optional; omit to run all
```

Add `--dry-run` to print phase transitions without calling mutating APIs.
Add `--cleanup` to allow the orchestrator to delete the old blue resources at
the end (otherwise the deployment is left in a switched-over state for manual
verification).

## Required IAM

The role assumed in each target account needs `rds:*` for the target cluster /
instance, `rds:CreateBlueGreenDeployment`, `rds:SwitchoverBlueGreenDeployment`,
`rds:DeleteBlueGreenDeployment`, plus `iam:PassRole` if the instance uses an
enhanced-monitoring role. The caller in the central account needs
`sts:AssumeRole` on the target role and `logs:*` on the configured log group.

## Resumability

State is stored in `--state-dir/<account>__<target>.json`. Each phase writes
its own block before advancing, so re-running picks up where it left off.
Delete the file to start over for that target.

from bg_upgrade.state import Phase, StateStore, TargetState


def test_record_phase_advances(tmp_path):
    store = StateStore(tmp_path)
    state = store.load(key="acc__db1", target_name="db1", account_id="acc")
    assert state.current_phase is Phase.INIT
    state.record_phase(Phase.INIT, {"engine": "postgres"})
    assert state.current_phase is Phase.PRECONDITIONS
    assert state.phases["INIT"]["engine"] == "postgres"


def test_resume_picks_up_after_persist(tmp_path):
    store = StateStore(tmp_path)
    state = store.load(key="acc__db1", target_name="db1", account_id="acc")
    state.record_phase(Phase.INIT, {})
    state.record_phase(Phase.PRECONDITIONS, {"checks_run": ["x"]})
    store.save(key="acc__db1", state=state)

    reloaded = store.load(key="acc__db1", target_name="db1", account_id="acc")
    assert reloaded.current_phase is Phase.PARAM_GROUP
    assert reloaded.phases["PRECONDITIONS"]["checks_run"] == ["x"]


def test_done_terminal(tmp_path):
    store = StateStore(tmp_path)
    state = TargetState(target_name="x", account_id="a", current_phase=Phase.DONE)
    assert state.is_complete()
    state.record_phase(Phase.DONE, {})
    # advancing past DONE stays on DONE
    assert state.current_phase is Phase.DONE

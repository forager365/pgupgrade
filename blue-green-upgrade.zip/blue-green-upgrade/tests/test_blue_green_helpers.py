from bg_upgrade.aws.rds import Topology
from bg_upgrade.upgrade.blue_green import (
    derive_bg_name,
    derive_target_family,
    derive_target_pg_name,
)


def _topology(kind: str, identifier: str, pg: str) -> Topology:
    return Topology(
        kind=kind,
        identifier=identifier,
        arn=f"arn:aws:rds:us-east-1:1:{identifier}",
        engine="postgres" if kind == "rds-instance" else "aurora-postgresql",
        engine_version="14.10",
        multi_az=False,
        storage_encrypted=True,
        parameter_group_name=pg,
        parameter_group_family="postgres14",
    )


def test_target_family_aurora_vs_rds():
    assert derive_target_family("17.2", aurora=False) == "postgres17"
    assert derive_target_family("17.2", aurora=True) == "aurora-postgresql17"


def test_target_pg_name_is_deterministic():
    topo = _topology("rds-instance", "orders", "default.postgres14")
    a = derive_target_pg_name(topo, "17.2")
    b = derive_target_pg_name(topo, "17.2")
    assert a == b
    assert "pg17-2" in a


def test_bg_name_truncated():
    topo = _topology("rds-instance", "x" * 200, "pg")
    name = derive_bg_name(topo)
    assert len(name) <= 60
    assert name.startswith("bg-")

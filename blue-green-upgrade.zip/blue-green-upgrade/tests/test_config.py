from pathlib import Path

import pytest

from bg_upgrade.config import load_config
from bg_upgrade.exceptions import ConfigError


def _write(tmp_path: Path, body: str) -> Path:
    p = tmp_path / "targets.yaml"
    p.write_text(body)
    return p


def test_load_config_applies_defaults(tmp_path):
    cfg_path = _write(tmp_path, """
logging:
  cloudwatch_log_group: /rds/bg
defaults:
  target_engine_version: "17.2"
targets:
  - name: t1
    account_id: "111111111111"
    region: us-east-1
    role_arn: arn:aws:iam::111111111111:role/X
    kind: rds-instance
    identifier: db1
""")
    cfg = load_config(cfg_path)
    assert len(cfg.targets) == 1
    t = cfg.targets[0]
    assert t.source_engine_version == "14"
    assert t.target_engine_version == "17.2"
    assert t.green_wait_timeout_seconds == 7200


def test_load_config_rejects_unknown_kind(tmp_path):
    cfg_path = _write(tmp_path, """
logging:
  cloudwatch_log_group: /rds/bg
targets:
  - name: t1
    account_id: "1"
    region: us-east-1
    role_arn: arn:aws:iam::1:role/X
    kind: dynamodb
    identifier: db1
""")
    with pytest.raises(ConfigError):
        load_config(cfg_path)


def test_load_config_requires_targets(tmp_path):
    cfg_path = _write(tmp_path, """
logging:
  cloudwatch_log_group: /rds/bg
targets: []
""")
    with pytest.raises(ConfigError):
        load_config(cfg_path)


def test_state_key_combines_account_and_name(tmp_path):
    cfg_path = _write(tmp_path, """
logging:
  cloudwatch_log_group: /rds/bg
targets:
  - name: orders
    account_id: "111111111111"
    region: us-east-1
    role_arn: arn:aws:iam::111111111111:role/X
    kind: rds-instance
    identifier: db1
""")
    cfg = load_config(cfg_path)
    assert cfg.targets[0].state_key() == "111111111111__orders"

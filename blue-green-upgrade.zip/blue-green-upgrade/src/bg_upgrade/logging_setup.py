"""Structured logging to stdout + CloudWatch Logs.

Each upgrade run gets its own CloudWatch log stream so multiple parallel runs
do not interleave. Log records include the target name as an ``extra`` field.
"""

from __future__ import annotations

import json
import logging
import socket
import threading
import time
from datetime import datetime, timezone
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError


_CW_CLIENT_CONFIG = Config(
    retries={"max_attempts": 10, "mode": "adaptive"},
    user_agent_extra="bg-upgrade/0.1",
)


class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key in ("target", "account_id", "phase", "bg_id"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


class CloudWatchHandler(logging.Handler):
    """A small CloudWatch Logs handler.

    Writes batches synchronously; this is fine for an orchestrator that logs
    O(100) events per upgrade. For higher volumes, swap for ``watchtower``.
    """

    def __init__(self, *, log_group: str, log_stream: str, client=None) -> None:
        super().__init__()
        self._log_group = log_group
        self._log_stream = log_stream
        self._client = client or boto3.client("logs", config=_CW_CLIENT_CONFIG)
        self._lock = threading.Lock()
        self._ensure_group_and_stream()

    def _ensure_group_and_stream(self) -> None:
        try:
            self._client.create_log_group(logGroupName=self._log_group)
        except ClientError as exc:
            if exc.response["Error"]["Code"] != "ResourceAlreadyExistsException":
                raise
        try:
            self._client.create_log_stream(
                logGroupName=self._log_group, logStreamName=self._log_stream
            )
        except ClientError as exc:
            if exc.response["Error"]["Code"] != "ResourceAlreadyExistsException":
                raise

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
            event = {
                "timestamp": int(record.created * 1000),
                "message": message,
            }
            with self._lock:
                self._client.put_log_events(
                    logGroupName=self._log_group,
                    logStreamName=self._log_stream,
                    logEvents=[event],
                )
        except Exception:
            # Never raise from the logging path.
            self.handleError(record)


def configure_logging(
    *,
    log_group: str,
    stream_prefix: str,
    run_id: str,
    level: int = logging.INFO,
    cloudwatch: bool = True,
) -> logging.Logger:
    """Install JSON stdout + (optionally) CloudWatch handlers on the root logger."""
    stream_name = f"{stream_prefix}/{socket.gethostname()}/{run_id}-{int(time.time())}"
    formatter = _JsonFormatter()

    root = logging.getLogger()
    root.setLevel(level)
    # Clear handlers in case configure_logging is called twice (tests).
    root.handlers.clear()

    stdout = logging.StreamHandler()
    stdout.setFormatter(formatter)
    root.addHandler(stdout)

    if cloudwatch:
        cw = CloudWatchHandler(log_group=log_group, log_stream=stream_name)
        cw.setFormatter(formatter)
        root.addHandler(cw)

    logger = logging.getLogger("bg_upgrade")
    logger.info("logging initialized", extra={"target": None})
    return logger


def target_logger(base: logging.Logger, *, target: str, account_id: str) -> logging.LoggerAdapter:
    """Return an adapter that attaches target/account_id to every record."""
    return logging.LoggerAdapter(base, extra={"target": target, "account_id": account_id})

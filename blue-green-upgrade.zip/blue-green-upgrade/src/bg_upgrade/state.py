"""Resumable per-target state, persisted as JSON.

Each target gets its own file under ``state_dir``. A phase writes its own
result block before the orchestrator advances ``current_phase``, so a crashed
run resumes from the last *completed* phase.
"""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any


class Phase(StrEnum):
    INIT = "INIT"
    PRECONDITIONS = "PRECONDITIONS"
    PARAM_GROUP = "PARAM_GROUP"
    CREATE_BLUE_GREEN = "CREATE_BLUE_GREEN"
    WAIT_GREEN_AVAILABLE = "WAIT_GREEN_AVAILABLE"
    PRE_SWITCHOVER_VALIDATION = "PRE_SWITCHOVER_VALIDATION"
    SWITCHOVER = "SWITCHOVER"
    POST_VALIDATION = "POST_VALIDATION"
    CLEANUP = "CLEANUP"
    DONE = "DONE"


PHASE_ORDER: tuple[Phase, ...] = (
    Phase.INIT,
    Phase.PRECONDITIONS,
    Phase.PARAM_GROUP,
    Phase.CREATE_BLUE_GREEN,
    Phase.WAIT_GREEN_AVAILABLE,
    Phase.PRE_SWITCHOVER_VALIDATION,
    Phase.SWITCHOVER,
    Phase.POST_VALIDATION,
    Phase.CLEANUP,
    Phase.DONE,
)


@dataclass
class TargetState:
    target_name: str
    account_id: str
    current_phase: Phase = Phase.INIT
    started_at: str = field(default_factory=lambda: _utcnow_iso())
    updated_at: str = field(default_factory=lambda: _utcnow_iso())
    phases: dict[str, dict[str, Any]] = field(default_factory=dict)

    def record_phase(self, phase: Phase, payload: dict[str, Any]) -> None:
        self.phases[phase.value] = {
            "completed_at": _utcnow_iso(),
            **payload,
        }
        self.current_phase = _next_phase(phase)
        self.updated_at = _utcnow_iso()

    def is_complete(self) -> bool:
        return self.current_phase is Phase.DONE

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_name": self.target_name,
            "account_id": self.account_id,
            "current_phase": self.current_phase.value,
            "started_at": self.started_at,
            "updated_at": self.updated_at,
            "phases": self.phases,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TargetState":
        return cls(
            target_name=data["target_name"],
            account_id=data["account_id"],
            current_phase=Phase(data["current_phase"]),
            started_at=data["started_at"],
            updated_at=data["updated_at"],
            phases=dict(data.get("phases") or {}),
        )


class StateStore:
    """File-backed state store; one JSON file per target."""

    def __init__(self, state_dir: str | Path) -> None:
        self._dir = Path(state_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def path_for(self, key: str) -> Path:
        return self._dir / f"{key}.json"

    def load(self, *, key: str, target_name: str, account_id: str) -> TargetState:
        path = self.path_for(key)
        if not path.is_file():
            return TargetState(target_name=target_name, account_id=account_id)
        with path.open("r", encoding="utf-8") as fh:
            return TargetState.from_dict(json.load(fh))

    def save(self, *, key: str, state: TargetState) -> None:
        path = self.path_for(key)
        # Atomic write: tmp file in the same dir, then rename.
        fd, tmp = tempfile.mkstemp(dir=self._dir, prefix=f".{key}.", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(state.to_dict(), fh, indent=2, sort_keys=True)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, path)
        except BaseException:
            with _suppress():
                os.unlink(tmp)
            raise


def _next_phase(phase: Phase) -> Phase:
    idx = PHASE_ORDER.index(phase)
    return PHASE_ORDER[min(idx + 1, len(PHASE_ORDER) - 1)]


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class _suppress:
    def __enter__(self):  # noqa: D401 — tiny context manager
        return self

    def __exit__(self, exc_type, exc, tb):
        return True

"""Blue/Green upgrade orchestrator for AWS RDS and Aurora PostgreSQL."""

__all__ = ["__version__"]
__version__ = "0.1.0"

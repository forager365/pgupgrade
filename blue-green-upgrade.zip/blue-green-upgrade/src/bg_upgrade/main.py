"""CLI entry point for the blue/green upgrade orchestrator."""

from __future__ import annotations

import argparse
import logging
import sys
import uuid

from .aws.session import SessionFactory
from .config import AppConfig, Target, load_config
from .exceptions import UpgradeError
from .logging_setup import configure_logging
from .state import StateStore
from .upgrade.orchestrator import Orchestrator, RunOptions


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    cfg = load_config(args.config)

    run_id = uuid.uuid4().hex[:12]
    logger = configure_logging(
        log_group=cfg.logging.cloudwatch_log_group,
        stream_prefix=cfg.logging.cloudwatch_log_stream_prefix,
        run_id=run_id,
        cloudwatch=not args.no_cloudwatch,
    )
    logger.info("starting run %s", run_id)

    targets = _select_targets(cfg, args.target)
    if not targets:
        logger.error("no targets matched filter: %s", args.target)
        return 2

    orchestrator = Orchestrator(
        session_factory=SessionFactory(external_id=args.external_id),
        state_store=StateStore(args.state_dir),
        logger=logger,
        run_id=run_id,
        options=RunOptions(
            dry_run=args.dry_run,
            cleanup_old_blue=args.cleanup,
        ),
    )

    failed: list[str] = []
    for target in targets:
        try:
            orchestrator.run_target(target)
        except UpgradeError as exc:
            failed.append(target.name)
            logger.error("target %s failed: %s", target.name, exc)
            if args.fail_fast:
                break

    if failed:
        logger.error("run %s finished with failures: %s", run_id, failed)
        return 1
    logger.info("run %s complete", run_id)
    return 0


def _select_targets(cfg: AppConfig, name: str | None) -> list[Target]:
    if name is None:
        return list(cfg.targets)
    return [t for t in cfg.targets if t.name == name]


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="bg-upgrade",
        description="Blue/green major-version upgrade for RDS / Aurora PostgreSQL",
    )
    p.add_argument("--config", required=True, help="path to targets YAML")
    p.add_argument("--state-dir", required=True, help="directory for resumable state files")
    p.add_argument("--target", help="only run a single target by name")
    p.add_argument("--dry-run", action="store_true", help="skip mutating API calls")
    p.add_argument("--cleanup", action="store_true",
                   help="permit deletion of old blue resources during CLEANUP phase")
    p.add_argument("--fail-fast", action="store_true",
                   help="stop at the first failing target")
    p.add_argument("--external-id", help="STS ExternalId required by some target roles")
    p.add_argument("--no-cloudwatch", action="store_true",
                   help="log only to stdout (useful for local dev)")
    return p.parse_args(argv)


if __name__ == "__main__":
    sys.exit(main())

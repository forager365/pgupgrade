"""Cross-account session factory backed by STS AssumeRole.

The orchestrator runs in a central account and assumes a role in each target
account. Credentials are cached per (role_arn, region) until shortly before
expiry to avoid repeated STS calls during a long-running upgrade.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import boto3
from botocore.config import Config


_REFRESH_BUFFER = timedelta(minutes=5)
_DEFAULT_SESSION_DURATION = 3600
_BOTO_CONFIG = Config(
    retries={"max_attempts": 10, "mode": "adaptive"},
    user_agent_extra="bg-upgrade/0.1",
)


@dataclass(frozen=True)
class _CachedSession:
    session: boto3.Session
    expires_at: datetime


class SessionFactory:
    """Thread-safe cache of assumed-role sessions."""

    def __init__(self, external_id: str | None = None) -> None:
        self._cache: dict[tuple[str, str], _CachedSession] = {}
        self._lock = threading.Lock()
        self._external_id = external_id
        self._sts = boto3.client("sts", config=_BOTO_CONFIG)

    def for_target(self, *, role_arn: str, region: str, session_name: str) -> boto3.Session:
        key = (role_arn, region)
        now = datetime.now(timezone.utc)
        with self._lock:
            cached = self._cache.get(key)
            if cached and cached.expires_at - _REFRESH_BUFFER > now:
                return cached.session
            session = self._assume(role_arn, region, session_name)
            expires_at = now + timedelta(seconds=_DEFAULT_SESSION_DURATION)
            self._cache[key] = _CachedSession(session=session, expires_at=expires_at)
            return session

    def _assume(self, role_arn: str, region: str, session_name: str) -> boto3.Session:
        params: dict[str, object] = {
            "RoleArn": role_arn,
            "RoleSessionName": session_name,
            "DurationSeconds": _DEFAULT_SESSION_DURATION,
        }
        if self._external_id:
            params["ExternalId"] = self._external_id
        creds = self._sts.assume_role(**params)["Credentials"]
        return boto3.Session(
            aws_access_key_id=creds["AccessKeyId"],
            aws_secret_access_key=creds["SecretAccessKey"],
            aws_session_token=creds["SessionToken"],
            region_name=region,
        )


def make_client(session: boto3.Session, service: str):
    """Build a boto3 client with the project's standard retry/UA config."""
    return session.client(service, config=_BOTO_CONFIG)

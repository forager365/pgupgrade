"""Thin wrappers around the RDS API used by the orchestrator.

The wrappers normalise the differences between Aurora clusters and RDS
instances behind one ``Topology`` view so the upgrade logic does not have to
branch on engine kind everywhere.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Iterable

from botocore.exceptions import ClientError

from ..exceptions import BlueGreenError, TopologyError


# --- Topology -------------------------------------------------------------


@dataclass(frozen=True, kw_only=True)
class Topology:
    """Normalised view of a target's current state."""

    kind: str                       # "rds-instance" | "aurora-cluster"
    identifier: str
    arn: str
    engine: str                     # "postgres" | "aurora-postgresql"
    engine_version: str
    multi_az: bool
    storage_encrypted: bool
    parameter_group_name: str       # cluster pg for Aurora, db pg for RDS
    parameter_group_family: str
    read_replica_ids: tuple[str, ...] = ()
    has_pending_modified_values: bool = False
    backup_retention_period: int = 0


# --- Client ---------------------------------------------------------------


class RdsClient:
    """Wrapper that exposes only what the orchestrator needs."""

    def __init__(self, boto_client) -> None:
        self._c = boto_client

    # -- discovery ---------------------------------------------------------

    def describe_topology(self, *, kind: str, identifier: str) -> Topology:
        if kind == "rds-instance":
            return self._describe_instance(identifier)
        if kind == "aurora-cluster":
            return self._describe_cluster(identifier)
        raise TopologyError(f"unsupported kind: {kind}")

    def _describe_instance(self, identifier: str) -> Topology:
        try:
            resp = self._c.describe_db_instances(DBInstanceIdentifier=identifier)
        except ClientError as exc:
            raise TopologyError(f"describe_db_instances({identifier}) failed: {exc}") from exc
        instances = resp.get("DBInstances") or []
        if not instances:
            raise TopologyError(f"db instance not found: {identifier}")
        inst = instances[0]
        pg = (inst.get("DBParameterGroups") or [{}])[0]
        pg_name = pg.get("DBParameterGroupName", "")
        return Topology(
            kind="rds-instance",
            identifier=inst["DBInstanceIdentifier"],
            arn=inst["DBInstanceArn"],
            engine=inst["Engine"],
            engine_version=inst["EngineVersion"],
            multi_az=bool(inst.get("MultiAZ")),
            storage_encrypted=bool(inst.get("StorageEncrypted")),
            parameter_group_name=pg_name,
            parameter_group_family=self._param_group_family(pg_name) if pg_name else "",
            read_replica_ids=tuple(inst.get("ReadReplicaDBInstanceIdentifiers") or ()),
            has_pending_modified_values=bool(inst.get("PendingModifiedValues") or {}),
            backup_retention_period=int(inst.get("BackupRetentionPeriod") or 0),
        )

    def _describe_cluster(self, identifier: str) -> Topology:
        try:
            resp = self._c.describe_db_clusters(DBClusterIdentifier=identifier)
        except ClientError as exc:
            raise TopologyError(f"describe_db_clusters({identifier}) failed: {exc}") from exc
        clusters = resp.get("DBClusters") or []
        if not clusters:
            raise TopologyError(f"db cluster not found: {identifier}")
        cl = clusters[0]
        pg_name = cl.get("DBClusterParameterGroup", "")
        # An Aurora cluster's read replicas are non-writer cluster members.
        replicas = tuple(
            m["DBInstanceIdentifier"]
            for m in (cl.get("DBClusterMembers") or [])
            if not m.get("IsClusterWriter")
        )
        return Topology(
            kind="aurora-cluster",
            identifier=cl["DBClusterIdentifier"],
            arn=cl["DBClusterArn"],
            engine=cl["Engine"],
            engine_version=cl["EngineVersion"],
            multi_az=bool(cl.get("MultiAZ")),
            storage_encrypted=bool(cl.get("StorageEncrypted")),
            parameter_group_name=pg_name,
            parameter_group_family=self._cluster_param_group_family(pg_name) if pg_name else "",
            read_replica_ids=replicas,
            has_pending_modified_values=bool(cl.get("PendingModifiedValues") or {}),
            backup_retention_period=int(cl.get("BackupRetentionPeriod") or 0),
        )

    def _param_group_family(self, name: str) -> str:
        resp = self._c.describe_db_parameter_groups(DBParameterGroupName=name)
        return (resp["DBParameterGroups"][0] or {}).get("DBParameterGroupFamily", "")

    def _cluster_param_group_family(self, name: str) -> str:
        resp = self._c.describe_db_cluster_parameter_groups(DBClusterParameterGroupName=name)
        return (resp["DBClusterParameterGroups"][0] or {}).get("DBParameterGroupFamily", "")

    # -- parameter groups --------------------------------------------------

    def parameter_value(self, *, kind: str, group_name: str, parameter: str) -> str | None:
        """Return the effective value of a parameter, or None if unset."""
        paginator_name = (
            "describe_db_parameters" if kind == "rds-instance"
            else "describe_db_cluster_parameters"
        )
        kw = (
            {"DBParameterGroupName": group_name}
            if kind == "rds-instance"
            else {"DBClusterParameterGroupName": group_name}
        )
        for page in self._c.get_paginator(paginator_name).paginate(**kw):
            for p in page.get("Parameters", []):
                if p.get("ParameterName") == parameter:
                    return p.get("ParameterValue")
        return None

    def ensure_target_param_group(
        self,
        *,
        kind: str,
        source_family: str,
        target_family: str,
        source_group_name: str,
        target_group_name: str,
        required_params: dict[str, str],
    ) -> str:
        """Create a target-version parameter group if absent and set required params.

        Returns the parameter-group name. Never mutates a pre-existing group.
        """
        exists = self._param_group_exists(kind=kind, name=target_group_name)
        if not exists:
            description = f"bg-upgrade target group derived from {source_group_name}"
            if kind == "rds-instance":
                self._c.create_db_parameter_group(
                    DBParameterGroupName=target_group_name,
                    DBParameterGroupFamily=target_family,
                    Description=description,
                )
            else:
                self._c.create_db_cluster_parameter_group(
                    DBClusterParameterGroupName=target_group_name,
                    DBParameterGroupFamily=target_family,
                    Description=description,
                )
            self._set_params(kind=kind, group_name=target_group_name, params=required_params)
        return target_group_name

    def _param_group_exists(self, *, kind: str, name: str) -> bool:
        try:
            if kind == "rds-instance":
                self._c.describe_db_parameter_groups(DBParameterGroupName=name)
            else:
                self._c.describe_db_cluster_parameter_groups(DBClusterParameterGroupName=name)
            return True
        except ClientError as exc:
            if exc.response["Error"]["Code"] in {
                "DBParameterGroupNotFound",
                "DBClusterParameterGroupNotFoundFault",
            }:
                return False
            raise

    def _set_params(self, *, kind: str, group_name: str, params: dict[str, str]) -> None:
        payload = [
            {"ParameterName": k, "ParameterValue": v, "ApplyMethod": "pending-reboot"}
            for k, v in params.items()
        ]
        if not payload:
            return
        if kind == "rds-instance":
            self._c.modify_db_parameter_group(
                DBParameterGroupName=group_name, Parameters=payload
            )
        else:
            self._c.modify_db_cluster_parameter_group(
                DBClusterParameterGroupName=group_name, Parameters=payload
            )

    # -- blue/green --------------------------------------------------------

    def create_blue_green(
        self,
        *,
        name: str,
        source_arn: str,
        target_engine_version: str,
        target_db_parameter_group: str | None = None,
        target_db_cluster_parameter_group: str | None = None,
    ) -> str:
        params: dict[str, Any] = {
            "BlueGreenDeploymentName": name,
            "Source": source_arn,
            "TargetEngineVersion": target_engine_version,
        }
        if target_db_parameter_group:
            params["TargetDBParameterGroupName"] = target_db_parameter_group
        if target_db_cluster_parameter_group:
            params["TargetDBClusterParameterGroupName"] = target_db_cluster_parameter_group
        try:
            resp = self._c.create_blue_green_deployment(**params)
        except ClientError as exc:
            raise BlueGreenError(f"create_blue_green_deployment failed: {exc}") from exc
        return resp["BlueGreenDeployment"]["BlueGreenDeploymentIdentifier"]

    def describe_blue_green(self, bg_id: str) -> dict[str, Any]:
        resp = self._c.describe_blue_green_deployments(
            BlueGreenDeploymentIdentifier=bg_id
        )
        items = resp.get("BlueGreenDeployments") or []
        if not items:
            raise BlueGreenError(f"blue/green deployment not found: {bg_id}")
        return items[0]

    def find_blue_green_by_source(self, source_arn: str) -> str | None:
        """Return an existing B/G deployment id for this source, if any."""
        paginator = self._c.get_paginator("describe_blue_green_deployments")
        for page in paginator.paginate():
            for dep in page.get("BlueGreenDeployments") or []:
                if dep.get("Source") == source_arn and dep.get("Status") not in {
                    "DELETED",
                    "DELETING",
                }:
                    return dep["BlueGreenDeploymentIdentifier"]
        return None

    def switchover_blue_green(self, *, bg_id: str, timeout_seconds: int) -> None:
        try:
            self._c.switchover_blue_green_deployment(
                BlueGreenDeploymentIdentifier=bg_id,
                SwitchoverTimeout=timeout_seconds,
            )
        except ClientError as exc:
            raise BlueGreenError(f"switchover failed: {exc}") from exc

    def delete_blue_green(self, *, bg_id: str, delete_target: bool) -> None:
        try:
            self._c.delete_blue_green_deployment(
                BlueGreenDeploymentIdentifier=bg_id,
                DeleteTarget=delete_target,
            )
        except ClientError as exc:
            raise BlueGreenError(f"delete_blue_green_deployment failed: {exc}") from exc

    # -- waiters -----------------------------------------------------------

    def wait_blue_green_status(
        self,
        *,
        bg_id: str,
        target_statuses: Iterable[str],
        failure_statuses: Iterable[str] = ("INVALID_CONFIGURATION", "DELETED"),
        timeout_seconds: int,
        poll_interval: int = 30,
    ) -> dict[str, Any]:
        targets = set(target_statuses)
        failures = set(failure_statuses)
        deadline = time.monotonic() + timeout_seconds
        last: dict[str, Any] = {}
        while time.monotonic() < deadline:
            last = self.describe_blue_green(bg_id)
            status = last.get("Status", "")
            if status in targets:
                return last
            if status in failures:
                raise BlueGreenError(
                    f"blue/green deployment {bg_id} entered failure state {status!r}"
                )
            time.sleep(poll_interval)
        raise BlueGreenError(
            f"timed out after {timeout_seconds}s waiting for {bg_id} to reach {targets!r}; "
            f"last status={last.get('Status')!r}"
        )

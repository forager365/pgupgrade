"""Blue/Green deployment lifecycle operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..aws.rds import RdsClient, Topology
from ..exceptions import BlueGreenError


@dataclass(frozen=True, kw_only=True)
class CreatedDeployment:
    bg_id: str
    name: str


def derive_target_pg_name(topology: Topology, target_engine_version: str) -> str:
    """Deterministic name for the version-bumped parameter group.

    Using a deterministic name makes the operation idempotent: a resumed run
    finds and reuses the group instead of creating a new one.
    """
    suffix = target_engine_version.replace(".", "-")
    base = topology.parameter_group_name or topology.identifier
    return f"{base}-pg{suffix}"[:255]


def derive_target_family(target_engine_version: str, *, aurora: bool) -> str:
    major = target_engine_version.split(".", 1)[0]
    return f"aurora-postgresql{major}" if aurora else f"postgres{major}"


def ensure_target_param_group(
    rds: RdsClient,
    topology: Topology,
    *,
    target_engine_version: str,
) -> str:
    """Create the target-version parameter group if missing."""
    aurora = topology.kind == "aurora-cluster"
    target_family = derive_target_family(target_engine_version, aurora=aurora)
    target_group_name = derive_target_pg_name(topology, target_engine_version)
    required = {"rds.logical_replication": "1"}
    return rds.ensure_target_param_group(
        kind=topology.kind,
        source_family=topology.parameter_group_family,
        target_family=target_family,
        source_group_name=topology.parameter_group_name,
        target_group_name=target_group_name,
        required_params=required,
    )


def derive_bg_name(topology: Topology) -> str:
    return f"bg-{topology.identifier}"[:60]


def create(
    rds: RdsClient,
    topology: Topology,
    *,
    target_engine_version: str,
    target_param_group: str,
) -> CreatedDeployment:
    """Create the blue/green deployment, or return the existing one."""
    existing = rds.find_blue_green_by_source(topology.arn)
    if existing:
        return CreatedDeployment(bg_id=existing, name=derive_bg_name(topology))

    name = derive_bg_name(topology)
    kwargs: dict[str, Any] = {
        "name": name,
        "source_arn": topology.arn,
        "target_engine_version": target_engine_version,
    }
    if topology.kind == "aurora-cluster":
        kwargs["target_db_cluster_parameter_group"] = target_param_group
    else:
        kwargs["target_db_parameter_group"] = target_param_group
    bg_id = rds.create_blue_green(**kwargs)
    return CreatedDeployment(bg_id=bg_id, name=name)


def wait_until_available(rds: RdsClient, *, bg_id: str, timeout_seconds: int) -> dict[str, Any]:
    """Wait until the green environment is AVAILABLE and ready to switch."""
    return rds.wait_blue_green_status(
        bg_id=bg_id,
        target_statuses=("AVAILABLE",),
        timeout_seconds=timeout_seconds,
    )


def switchover(rds: RdsClient, *, bg_id: str, timeout_seconds: int) -> dict[str, Any]:
    rds.switchover_blue_green(bg_id=bg_id, timeout_seconds=timeout_seconds)
    return rds.wait_blue_green_status(
        bg_id=bg_id,
        target_statuses=("SWITCHOVER_COMPLETED",),
        failure_statuses=("SWITCHOVER_FAILED", "INVALID_CONFIGURATION", "DELETED"),
        timeout_seconds=max(timeout_seconds * 2, 600),
    )


def delete_old_blue(rds: RdsClient, *, bg_id: str) -> None:
    rds.delete_blue_green(bg_id=bg_id, delete_target=False)


def assert_safe_to_switch(deployment: dict[str, Any]) -> None:
    """Sanity-check the deployment object before initiating switchover."""
    status = deployment.get("Status")
    if status != "AVAILABLE":
        raise BlueGreenError(f"deployment not AVAILABLE (status={status!r})")
    tasks = deployment.get("Tasks") or []
    incomplete = [t for t in tasks if t.get("Status") not in {"COMPLETED", "SKIPPED"}]
    if incomplete:
        raise BlueGreenError(
            f"deployment has incomplete tasks: {[t.get('Name') for t in incomplete]}"
        )

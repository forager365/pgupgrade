"""Pre-flight checks run before any blue/green resource is created."""

from __future__ import annotations

from dataclasses import dataclass

from ..aws.rds import RdsClient, Topology
from ..exceptions import PreconditionFailed


@dataclass(frozen=True, kw_only=True)
class PreconditionResult:
    checks_run: tuple[str, ...]
    notes: dict[str, str]


# A non-empty value of `rds.logical_replication` other than "0" enables
# logical replication, which is required for the green environment to follow
# the blue environment during a B/G major-version upgrade.
_LOGICAL_REPL_PARAM = "rds.logical_replication"


def run(
    rds: RdsClient,
    topology: Topology,
    *,
    expected_source_major: str,
    target_engine_version: str,
) -> PreconditionResult:
    notes: dict[str, str] = {}
    checks: list[str] = []

    _check_engine(topology, expected_source_major)
    checks.append("engine_version")

    _check_target_version_is_newer(topology, target_engine_version)
    checks.append("target_version_newer")
    notes["target_engine_version"] = target_engine_version

    _check_backups(topology)
    checks.append("backups_enabled")
    notes["backup_retention_period"] = str(topology.backup_retention_period)

    _check_no_pending_modifications(topology)
    checks.append("no_pending_modifications")

    _check_no_existing_blue_green(rds, topology)
    checks.append("no_existing_blue_green")

    _check_logical_replication(rds, topology)
    checks.append("logical_replication_enabled")

    if topology.read_replica_ids:
        notes["read_replica_count"] = str(len(topology.read_replica_ids))
        # Replica states are surfaced through the B/G "InvalidConfiguration" path;
        # we only assert here that we know about them so an operator can decide.
        checks.append("read_replicas_recorded")

    return PreconditionResult(checks_run=tuple(checks), notes=notes)


def _check_engine(topology: Topology, expected_major: str) -> None:
    if not topology.engine.endswith("postgres") and topology.engine != "aurora-postgresql":
        raise PreconditionFailed(
            f"unsupported engine: {topology.engine}; expected postgres or aurora-postgresql"
        )
    current_major = topology.engine_version.split(".", 1)[0]
    if current_major != expected_major:
        raise PreconditionFailed(
            f"source major version {current_major} != expected {expected_major} "
            f"(engine_version={topology.engine_version})"
        )


def _check_target_version_is_newer(topology: Topology, target_engine_version: str) -> None:
    source_major = int(topology.engine_version.split(".", 1)[0])
    try:
        target_major = int(target_engine_version.split(".", 1)[0])
    except ValueError as exc:
        raise PreconditionFailed(
            f"could not parse target_engine_version={target_engine_version!r}"
        ) from exc
    if target_major <= source_major:
        raise PreconditionFailed(
            f"target version {target_engine_version} is not newer than source "
            f"{topology.engine_version}"
        )


def _check_backups(topology: Topology) -> None:
    if topology.backup_retention_period <= 0:
        raise PreconditionFailed(
            "automated backups are disabled; B/G deployments require backups"
        )


def _check_no_pending_modifications(topology: Topology) -> None:
    if topology.has_pending_modified_values:
        raise PreconditionFailed(
            "source has pending modified values; apply or wait them out before upgrading"
        )


def _check_no_existing_blue_green(rds: RdsClient, topology: Topology) -> None:
    existing = rds.find_blue_green_by_source(topology.arn)
    if existing:
        raise PreconditionFailed(
            f"a blue/green deployment already exists for source {topology.arn}: {existing}"
        )


def _check_logical_replication(rds: RdsClient, topology: Topology) -> None:
    value = rds.parameter_value(
        kind=topology.kind,
        group_name=topology.parameter_group_name,
        parameter=_LOGICAL_REPL_PARAM,
    )
    if value in (None, "", "0"):
        raise PreconditionFailed(
            f"{_LOGICAL_REPL_PARAM} must be enabled on {topology.parameter_group_name!r} "
            f"before creating a blue/green deployment (currently {value!r}); "
            "set it to 1 and reboot the source, then resume."
        )

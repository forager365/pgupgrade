"""Phase-by-phase upgrade orchestrator.

Each call to ``run_target`` advances state through ``state.Phase`` values until
``DONE`` or until a phase raises. Already-completed phases are skipped using
the persisted state, so a failed run can be resumed by simply re-running.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

from ..aws.rds import RdsClient, Topology
from ..aws.session import SessionFactory, make_client
from ..config import Target
from ..exceptions import UpgradeError
from ..state import Phase, StateStore, TargetState
from . import blue_green, postvalidate, preconditions


@dataclass(frozen=True, kw_only=True)
class RunOptions:
    dry_run: bool = False
    cleanup_old_blue: bool = False


class Orchestrator:
    def __init__(
        self,
        *,
        session_factory: SessionFactory,
        state_store: StateStore,
        logger: logging.Logger,
        run_id: str,
        options: RunOptions,
    ) -> None:
        self._sessions = session_factory
        self._state = state_store
        self._logger = logger
        self._run_id = run_id
        self._opts = options

    def run_target(self, target: Target) -> TargetState:
        state = self._state.load(
            key=target.state_key(),
            target_name=target.name,
            account_id=target.account_id,
        )
        log = logging.LoggerAdapter(
            self._logger,
            extra={"target": target.name, "account_id": target.account_id},
        )

        if state.is_complete():
            log.info("target already complete; nothing to do")
            return state

        rds = self._rds_client(target)

        # The phase handlers are pure functions of (rds, target, state) and
        # return a payload dict that gets persisted alongside the phase. Each
        # handler must be idempotent — a resumed run will call it again only
        # if its phase had not been recorded as complete.
        handlers: dict[Phase, Callable[[RdsClient, Target, TargetState], dict]] = {
            Phase.INIT: self._phase_init,
            Phase.PRECONDITIONS: self._phase_preconditions,
            Phase.PARAM_GROUP: self._phase_param_group,
            Phase.CREATE_BLUE_GREEN: self._phase_create_bg,
            Phase.WAIT_GREEN_AVAILABLE: self._phase_wait_green,
            Phase.PRE_SWITCHOVER_VALIDATION: self._phase_pre_switch_validation,
            Phase.SWITCHOVER: self._phase_switchover,
            Phase.POST_VALIDATION: self._phase_post_validation,
            Phase.CLEANUP: self._phase_cleanup,
        }

        while state.current_phase is not Phase.DONE:
            phase = state.current_phase
            handler = handlers[phase]
            log.info("phase start", extra={"phase": phase.value, "target": target.name,
                                           "account_id": target.account_id})
            try:
                if self._opts.dry_run:
                    payload = {"dry_run": True}
                else:
                    payload = handler(rds, target, state)
            except UpgradeError as exc:
                log.error(
                    "phase failed: %s", exc,
                    extra={"phase": phase.value, "target": target.name,
                           "account_id": target.account_id},
                )
                raise
            state.record_phase(phase, payload)
            self._state.save(key=target.state_key(), state=state)
            log.info(
                "phase complete",
                extra={"phase": phase.value, "target": target.name,
                       "account_id": target.account_id},
            )
        return state

    # -- per-phase handlers ------------------------------------------------

    def _phase_init(self, rds: RdsClient, target: Target, _: TargetState) -> dict:
        topology = rds.describe_topology(kind=target.kind, identifier=target.identifier)
        return {"topology": _topology_to_dict(topology)}

    def _phase_preconditions(self, rds: RdsClient, target: Target, _: TargetState) -> dict:
        topology = rds.describe_topology(kind=target.kind, identifier=target.identifier)
        result = preconditions.run(
            rds, topology,
            expected_source_major=target.source_engine_version,
            target_engine_version=target.target_engine_version,
        )
        return {"checks_run": list(result.checks_run), "notes": result.notes}

    def _phase_param_group(self, rds: RdsClient, target: Target, _: TargetState) -> dict:
        topology = rds.describe_topology(kind=target.kind, identifier=target.identifier)
        name = blue_green.ensure_target_param_group(
            rds, topology, target_engine_version=target.target_engine_version
        )
        return {"target_parameter_group": name}

    def _phase_create_bg(self, rds: RdsClient, target: Target, state: TargetState) -> dict:
        topology = rds.describe_topology(kind=target.kind, identifier=target.identifier)
        pg_name = state.phases[Phase.PARAM_GROUP.value]["target_parameter_group"]
        created = blue_green.create(
            rds, topology,
            target_engine_version=target.target_engine_version,
            target_param_group=pg_name,
        )
        return {"bg_id": created.bg_id, "bg_name": created.name}

    def _phase_wait_green(self, rds: RdsClient, target: Target, state: TargetState) -> dict:
        bg_id = state.phases[Phase.CREATE_BLUE_GREEN.value]["bg_id"]
        deployment = blue_green.wait_until_available(
            rds, bg_id=bg_id, timeout_seconds=target.green_wait_timeout_seconds,
        )
        return {"status": deployment.get("Status"), "tasks": deployment.get("Tasks", [])}

    def _phase_pre_switch_validation(
        self, rds: RdsClient, _: Target, state: TargetState
    ) -> dict:
        bg_id = state.phases[Phase.CREATE_BLUE_GREEN.value]["bg_id"]
        deployment = rds.describe_blue_green(bg_id)
        blue_green.assert_safe_to_switch(deployment)
        return {"status": deployment.get("Status")}

    def _phase_switchover(self, rds: RdsClient, target: Target, state: TargetState) -> dict:
        bg_id = state.phases[Phase.CREATE_BLUE_GREEN.value]["bg_id"]
        deployment = blue_green.switchover(
            rds, bg_id=bg_id, timeout_seconds=target.switchover_timeout_seconds
        )
        return {"status": deployment.get("Status")}

    def _phase_post_validation(self, rds: RdsClient, target: Target, _: TargetState) -> dict:
        result = postvalidate.run(
            rds,
            kind=target.kind,
            identifier=target.identifier,
            target_engine_version=target.target_engine_version,
        )
        return {
            "checks_run": list(result.checks_run),
            "final_engine_version": result.final_engine_version,
            "replica_versions": result.replica_versions,
        }

    def _phase_cleanup(self, rds: RdsClient, target: Target, state: TargetState) -> dict:
        bg_id = state.phases[Phase.CREATE_BLUE_GREEN.value]["bg_id"]
        if self._opts.cleanup_old_blue and target.delete_old_blue_on_cleanup:
            blue_green.delete_old_blue(rds, bg_id=bg_id)
            return {"deleted_old_blue": True, "bg_id": bg_id}
        return {"deleted_old_blue": False, "bg_id": bg_id}

    # -- helpers -----------------------------------------------------------

    def _rds_client(self, target: Target) -> RdsClient:
        session = self._sessions.for_target(
            role_arn=target.role_arn,
            region=target.region,
            session_name=f"bg-upgrade-{self._run_id}",
        )
        return RdsClient(make_client(session, "rds"))


def _topology_to_dict(topology: Topology) -> dict:
    return {
        "kind": topology.kind,
        "identifier": topology.identifier,
        "arn": topology.arn,
        "engine": topology.engine,
        "engine_version": topology.engine_version,
        "multi_az": topology.multi_az,
        "storage_encrypted": topology.storage_encrypted,
        "parameter_group_name": topology.parameter_group_name,
        "parameter_group_family": topology.parameter_group_family,
        "read_replica_ids": list(topology.read_replica_ids),
        "backup_retention_period": topology.backup_retention_period,
    }



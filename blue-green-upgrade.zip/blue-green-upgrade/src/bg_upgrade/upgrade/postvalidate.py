"""Post-switchover validations."""

from __future__ import annotations

from dataclasses import dataclass

from ..aws.rds import RdsClient, Topology
from ..exceptions import PostValidationFailed


@dataclass(frozen=True, kw_only=True)
class PostValidationResult:
    checks_run: tuple[str, ...]
    final_engine_version: str
    replica_versions: dict[str, str]


def run(
    rds: RdsClient,
    *,
    kind: str,
    identifier: str,
    target_engine_version: str,
) -> PostValidationResult:
    topology = rds.describe_topology(kind=kind, identifier=identifier)
    checks: list[str] = []

    _check_version(topology, target_engine_version)
    checks.append("version_matches_target")

    _check_no_pending_modifications(topology)
    checks.append("no_pending_modifications")

    replica_versions = _check_replicas(rds, topology, target_engine_version)
    if replica_versions:
        checks.append("replicas_on_target_version")

    return PostValidationResult(
        checks_run=tuple(checks),
        final_engine_version=topology.engine_version,
        replica_versions=replica_versions,
    )


def _check_version(topology: Topology, target_engine_version: str) -> None:
    target_major = target_engine_version.split(".", 1)[0]
    actual_major = topology.engine_version.split(".", 1)[0]
    if actual_major != target_major:
        raise PostValidationFailed(
            f"post-switchover engine version {topology.engine_version} does not match "
            f"target major {target_major}"
        )


def _check_no_pending_modifications(topology: Topology) -> None:
    if topology.has_pending_modified_values:
        raise PostValidationFailed(
            f"{topology.identifier} has pending modified values after switchover"
        )


def _check_replicas(
    rds: RdsClient,
    topology: Topology,
    target_engine_version: str,
) -> dict[str, str]:
    if not topology.read_replica_ids:
        return {}
    target_major = target_engine_version.split(".", 1)[0]
    versions: dict[str, str] = {}
    laggards: list[str] = []
    for replica_id in topology.read_replica_ids:
        replica = rds.describe_topology(kind="rds-instance", identifier=replica_id)
        versions[replica_id] = replica.engine_version
        if replica.engine_version.split(".", 1)[0] != target_major:
            laggards.append(f"{replica_id}={replica.engine_version}")
    if laggards:
        raise PostValidationFailed(
            f"replicas did not reach target major {target_major}: {laggards}"
        )
    return versions

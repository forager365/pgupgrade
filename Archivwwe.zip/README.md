# Blue/Green Postgres Upgrader (bggowails)

A desktop tool for performing **major-version upgrades of Amazon RDS for
PostgreSQL and Aurora PostgreSQL** using AWS **Blue/Green Deployments**, driven
by the AWS SDK for Go v2 and presented through a [Wails](https://wails.io)
(Go + Svelte) desktop UI.

It authenticates with an **SSO profile**, reads a **TOML configuration**, detects
the database **topology**, checks **preconditions**, builds the **green**
environment on the target version with the supplied **parameter groups**,
disables **logical replication** on green, drops/recreates **extensions** as
required, runs **smoke tests** comparing row counts between blue and green, and
only then performs the **switchover**. Every action is streamed to the UI and
written to a timestamped **activity log**. A **dry-run** mode enumerates every
step without making any changes.

---

## Architecture

```
                          ┌──────────────────────────────────────────────┐
                          │                Wails Desktop App               │
                          │                                                │
   ┌────────────┐         │  ┌───────────────┐        ┌────────────────┐  │
   │  Svelte UI │◀────────┼──│  app.go (bind) │◀──────▶│ runtime.Events │  │
   │ (frontend) │  events │  │  Validate/Dry  │ progress│  log / progress│  │
   │            │────────▶│  │  Run/RunUpgrade│  +log   └────────────────┘  │
   └────────────┘  calls  │  └───────┬───────┘                             │
                          │          │                                     │
                          │   ┌──────▼────────────────────────────────┐    │
                          │   │        internal/upgrade (orchestrator) │    │
                          │   │   Plan • DryRun • Run (phased flow)     │    │
                          │   └──┬───────┬────────┬───────┬────────┬───┘    │
                          └──────┼───────┼────────┼───────┼────────┼────────┘
                                 │       │        │       │        │
                       ┌─────────▼─┐ ┌───▼────┐ ┌─▼──────┐│  ┌─────▼──────┐
                       │  config   │ │  awsx  │ │topology││  │ logging    │
                       │  (TOML)   │ │ SSO+STS│ │ detect ││  │ file+sink  │
                       └───────────┘ └───┬────┘ └─┬──────┘│  └────────────┘
                                         │        │       │
                       ┌─────────────────▼────────▼───┐ ┌─▼───────────────┐
                       │     bluegreen (RDS API)       │ │  pg (pgx driver) │
                       │  Create/Wait/Switchover/Delete│ │ counts/ext/logical│
                       └───────────────┬───────────────┘ └─┬───────────────┘
                                       │                    │
                ┌──────────────────────▼──────┐   ┌─────────▼───────────────┐
                │  preconditions (gate)        │   │  smoketest (blue==green)│
                └──────────────────────────────┘   └─────────────────────────┘
                                       │                    │
                              ╔════════▼════════╗  ╔════════▼════════╗
                              ║  AWS RDS / Aurora ║  ║ Postgres (pgx)  ║
                              ╚═════════════════╝  ╚═════════════════╝
```

### Package layout

| Package | Responsibility |
|---|---|
| `main` (`main.go`, `app.go`) | Wails entry point; binds backend methods to the Svelte frontend; emits `log` and `progress` events. |
| `internal/config` | Loads & validates the TOML configuration; resolves secrets from env vars; redaction for logging. |
| `internal/awsx` | Builds AWS SDK v2 clients from an **SSO profile** + region; `sts:GetCallerIdentity` auth check. |
| `internal/topology` | Detects the topology (RDS instance, Multi-AZ ± replicas, Aurora cluster) and resolves the source ARN/endpoint. |
| `internal/pg` | All in-database work via **pgx**: row counts, extension drop/recreate, logical-replication teardown. Identifiers are validated & quoted. |
| `internal/preconditions` | Gating checks: version path, engine family, parameter groups, connectivity, logical-replication state. |
| `internal/bluegreen` | Wraps the RDS **Blue/Green Deployment** API: create, wait-available, switchover, delete, green-endpoint resolution. |
| `internal/smoketest` | Compares configured table counts / scalar queries between blue and green. |
| `internal/upgrade` | The orchestrator: builds the **plan**, runs a read-only **dry run**, and executes the phased upgrade. |
| `internal/logging` | Timestamped activity log file + live sink to the UI. |

### Upgrade flow (real run)

1. **Auth** — verify the SSO session (`sts:GetCallerIdentity`).
2. **Detect topology** — RDS instance / Multi-AZ / Aurora; resolve source ARN.
3. **Connect** to the source (blue) database with pgx.
4. **Preconditions** — abort if any *fatal* check fails.
5. **Drop extensions on blue** (only those marked `drop_before_upgrade`).
6. **Create blue/green deployment** on the target version with parameter groups.
7. **Wait** until the green environment is `AVAILABLE`.
8. **Resolve green endpoint** (auto-discovered or from config).
9. **Disable logical replication** on green (subscriptions, publications, slots).
10. **Recreate extensions** on green (those marked `recreate`).
11. **Smoke tests** — compare counts/queries blue vs green. **Mismatch ⇒ no switchover.**
12. **Switchover** — promote green to the blue endpoints.
13. **Cleanup** — optionally delete the old blue environment.

> The **dry run** performs only the read-only steps (auth + topology detection)
> and then prints the full ordered plan, marking each step as mutating or not.

---

## Prerequisites

- **Go** 1.23+ (the repo uses Go toolchain `go 1.25.0`; `wails build` will fetch it).
- **Wails** v2.12+ (`wails version`).
- **Node** 18+ / npm (for the Svelte frontend).
- **AWS CLI v2** configured with an SSO profile:
  ```sh
  aws configure sso --profile my-sso-profile
  aws sso login --profile my-sso-profile
  ```
- Network/security-group access from the host to the RDS/Aurora endpoint on 5432.

## Configuration

Copy `config/example.toml` and edit it. The DB password may be supplied via an
environment variable (`password_env`) instead of being written to the file:

```sh
export BGG_DB_PASSWORD='…'
```

Key sections: `[aws]` (SSO profile + region), `[upgrade]` (source/target versions,
topology, blue/green name), `[target]` (instance or cluster identifier),
`[parameter_groups]` (instance and/or cluster), `[database]` (pgx credentials),
`[[extensions]]` (drop/recreate flags), `[smoke]` (count tables & queries),
`[options]` (logical-replication teardown, extension-recreate toggle).
See `config/example.toml` for the full, commented schema.

## Running

Development (hot-reload):

```sh
wails dev
```

Production build (creates `build/bin/bggowails.app` on macOS):

```sh
wails build
```

In the app:
1. The config editor is pre-filled with the bundled example — edit it.
2. **Validate** — parse & validate the config (no AWS calls).
3. **Dry run** — authenticate, detect topology, and list every planned step.
4. **Run upgrade** — execute the full flow; progress, logs, preconditions and
   smoke results stream into the right-hand tabs.

Activity logs are written to `./logs/bggowails-<timestamp>.log`.

## Safety notes

- **Switchover is gated** on both preconditions and smoke tests passing.
- SQL identifiers from config are validated and double-quoted to avoid injection.
- The old (blue) environment is **retained by default**; deletion is opt-in via
  `delete_blue_after_switch`.
- Passwords are redacted from validated-config output and never logged.

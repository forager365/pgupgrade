package main

import (
	"context"
	_ "embed"
	"fmt"

	"github.com/wailsapp/wails/v2/pkg/runtime"

	"bggowails/internal/config"
	"bggowails/internal/logging"
	"bggowails/internal/upgrade"
)

//go:embed config/example.toml
var exampleConfig string

// App is the Wails application backend bound to the Svelte frontend.
type App struct {
	ctx context.Context
}

// NewApp creates a new App.
func NewApp() *App {
	return &App{}
}

// startup stores the runtime context used to emit events to the frontend.
func (a *App) startup(ctx context.Context) {
	a.ctx = ctx
}

// ExampleConfig returns the bundled example TOML for the config editor.
func (a *App) ExampleConfig() string {
	return exampleConfig
}

// ValidateConfig parses TOML and returns a redacted view, or an error string.
func (a *App) ValidateConfig(tomlText string) (config.Config, error) {
	c, err := config.LoadString(tomlText)
	if err != nil {
		return config.Config{}, err
	}
	return c.Redacted(), nil
}

// DryRun parses the config and returns the planned steps without mutating.
func (a *App) DryRun(tomlText string) ([]upgrade.Step, error) {
	cfg, err := config.LoadString(tomlText)
	if err != nil {
		return nil, err
	}
	log, err := a.newLogger()
	if err != nil {
		return nil, err
	}
	defer log.Close()

	runner := upgrade.NewRunner(cfg, log, a.emitProgress)
	steps, _, err := runner.DryRun(a.ctx)
	if err != nil {
		return steps, err
	}
	return steps, nil
}

// RunUpgrade executes the full upgrade and returns the final report. Progress
// and log lines stream to the frontend via Wails events ("progress", "log").
func (a *App) RunUpgrade(tomlText string) (*upgrade.Report, error) {
	cfg, err := config.LoadString(tomlText)
	if err != nil {
		return nil, err
	}
	log, err := a.newLogger()
	if err != nil {
		return nil, err
	}
	defer log.Close()

	runner := upgrade.NewRunner(cfg, log, a.emitProgress)
	report, err := runner.Run(a.ctx)
	if err != nil {
		a.emitProgress(upgrade.Event{Phase: "fatal", Status: "error", Message: err.Error()})
	}
	return report, err
}

// newLogger creates a file logger whose entries also stream to the UI.
func (a *App) newLogger() (*logging.Logger, error) {
	sink := func(e logging.Entry) {
		if a.ctx != nil {
			runtime.EventsEmit(a.ctx, "log", e)
		}
	}
	log, err := logging.New("logs", sink)
	if err != nil {
		return nil, fmt.Errorf("init logger: %w", err)
	}
	return log, nil
}

func (a *App) emitProgress(e upgrade.Event) {
	if a.ctx != nil {
		runtime.EventsEmit(a.ctx, "progress", e)
	}
}

package main

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/fatih/color"
)

type Status string

const (
	PASS Status = "PASS"
	FAIL Status = "FAIL"
	WARN Status = "WARN"
	SKIP Status = "SKIP"
	INFO Status = "INFO"
)

type CheckResult struct {
	Name    string                 `json:"name"`
	Status  Status                 `json:"status"`
	Message string                 `json:"message"`
	Details map[string]interface{} `json:"details,omitempty"`
}

type Report struct {
	ID        string        `json:"id"`
	DBName    string        `json:"dbname,omitempty"`
	Timestamp string        `json:"timestamp"`
	Results   []CheckResult `json:"results"`
}

func (r *Report) Add(result CheckResult) {
	r.Results = append(r.Results, result)
}

func (r *Report) Summary() map[string]int {
	counts := map[string]int{
		string(PASS): 0,
		string(FAIL): 0,
		string(WARN): 0,
		string(SKIP): 0,
		string(INFO): 0,
	}
	for _, res := range r.Results {
		counts[string(res.Status)]++
	}
	return counts
}

func (r *Report) HasFailures() bool {
	for _, res := range r.Results {
		if res.Status == FAIL {
			return true
		}
	}
	return false
}

func (r *Report) Print() {
	width := 88
	title := "PRE-SWITCHOVER VALIDATION REPORT"
	if r.DBName != "" {
		title = "SQL-LEVEL PRE-SWITCHOVER CHECKS"
	}

	fmt.Println("\n" + strings.Repeat("=", width))
	fmt.Printf("  %s\n", title)
	fmt.Printf("  ID:        %s\n", r.ID)
	if r.DBName != "" {
		fmt.Printf("  Database:  %s\n", r.DBName)
	}
	fmt.Printf("  Timestamp: %s\n", r.Timestamp)
	fmt.Println(strings.Repeat("=", width))

	for _, res := range r.Results {
		var c *color.Color
		switch res.Status {
		case PASS:
			c = color.New(color.FgGreen)
		case FAIL:
			c = color.New(color.FgRed)
		case WARN:
			c = color.New(color.FgYellow)
		case SKIP:
			c = color.New(color.FgHiBlack)
		case INFO:
			c = color.New(color.FgBlue)
		}

		tag := fmt.Sprintf("[%s]", res.Status)
		c.Printf("\n  %-6s  %s\n", tag, res.Name)
		fmt.Printf("          %s\n", res.Message)
		if res.Details != nil {
			for k, v := range res.Details {
				val, _ := json.Marshal(v)
				valStr := string(val)
				if len(valStr) > 200 {
					valStr = valStr[:200] + "..."
				}
				fmt.Printf("          %s: %s\n", k, valStr)
			}
		}
	}

	summary := r.Summary()
	fmt.Println("\n" + strings.Repeat("-", width))
	fmt.Print("  SUMMARY  ")
	for _, s := range []Status{PASS, FAIL, WARN, SKIP, INFO} {
		fmt.Printf("%s: %d  ", s, summary[string(s)])
	}
	fmt.Println()

	if r.HasFailures() {
		color.New(color.FgRed).Printf("\n  >>> Resolve FAIL items before switchover <<<\n")
	} else {
		color.New(color.FgGreen).Printf("\n  >>> All critical checks passed — safe to proceed <<<\n")
	}
	fmt.Println(strings.Repeat("=", width) + "\n")
}

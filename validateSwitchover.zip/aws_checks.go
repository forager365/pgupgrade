package main

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/cloudwatch"
	cwtypes "github.com/aws/aws-sdk-go-v2/service/cloudwatch/types"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
)

type AWSChecks struct {
	rdsClient *rds.Client
	cwClient  *cloudwatch.Client
	region    string
	profile   string
}

func NewAWSChecks(ctx context.Context, region, profile string) (*AWSChecks, error) {
	var cfg aws.Config
	var err error

	if profile != "" {
		cfg, err = config.LoadDefaultConfig(ctx,
			config.WithRegion(region),
			config.WithSharedConfigProfile(profile),
		)
	} else {
		cfg, err = config.LoadDefaultConfig(ctx,
			config.WithRegion(region),
		)
	}

	if err != nil {
		return nil, fmt.Errorf("unable to load SDK config: %v", err)
	}

	return &AWSChecks{
		rdsClient: rds.NewFromConfig(cfg),
		cwClient:  cloudwatch.NewFromConfig(cfg),
		region:    region,
		profile:   profile,
	}, nil
}

func (a *AWSChecks) GetBGDDetails(ctx context.Context, bgdID string) (*rdstypes.BlueGreenDeployment, error) {
	resp, err := a.rdsClient.DescribeBlueGreenDeployments(ctx, &rds.DescribeBlueGreenDeploymentsInput{
		BlueGreenDeploymentIdentifier: aws.String(bgdID),
	})
	if err != nil {
		return nil, err
	}
	if len(resp.BlueGreenDeployments) == 0 {
		return nil, fmt.Errorf("blue/green deployment %s not found", bgdID)
	}
	return &resp.BlueGreenDeployments[0], nil
}

func (a *AWSChecks) RunAll(ctx context.Context, bgdID string) (*Report, error) {
	report := &Report{
		ID:        bgdID,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	fmt.Printf("\nFetching blue/green deployment %s ...\n", bgdID)
	bgd, err := a.getBGD(ctx, bgdID)
	if err != nil {
		return nil, err
	}

	blueID := arnToInstanceID(*bgd.Source)
	greenID := arnToInstanceID(*bgd.Target)
	fmt.Printf("  Blue:  %s\n", blueID)
	fmt.Printf("  Green: %s\n\n", greenID)

	a.checkBGDStatus(report, bgd)
	a.checkInstanceStatus(ctx, report, blueID, "Blue")
	a.checkInstanceStatus(ctx, report, greenID, "Green")
	a.checkReplicationHealth(report, bgd)
	a.checkReplicaLag(ctx, report, greenID, "Green (ReplicaLag)", "ReplicaLag", 30.0)
	a.checkReplicaLag(ctx, report, blueID, "Blue (OldestReplicationSlotLag)", "OldestReplicationSlotLag", 5.0*1024*1024)
	a.checkExternalReplication(ctx, report, blueID)
	a.checkDatabaseConnections(ctx, report, blueID, "Blue")
	a.checkDatabaseConnections(ctx, report, greenID, "Green")
	a.checkWriteActivity(ctx, report, blueID, "Blue")
	a.checkParameterGroupPending(ctx, report, blueID, "Blue")
	a.checkParameterGroupPending(ctx, report, greenID, "Green")
	a.checkEngineVersions(ctx, report, blueID, greenID)
	a.checkReadReplicas(ctx, report, blueID, greenID)
	a.checkIAMRoles(ctx, report, blueID, greenID)
	a.checkStorage(ctx, report, blueID, "Blue")
	a.checkStorage(ctx, report, greenID, "Green")
	a.checkMultiAZ(ctx, report, blueID, "Blue")
	a.checkMultiAZ(ctx, report, greenID, "Green")

	report.Add(CheckResult{
		Name:    "DNS TTL Reminder",
		Status:  WARN,
		Message: "Verify network/client DNS cache TTL <= 5s (RDS default). Higher TTL can route writes to old blue after switchover.",
	})

	return report, nil
}

func (a *AWSChecks) getBGD(ctx context.Context, bgdID string) (*rdstypes.BlueGreenDeployment, error) {
	resp, err := a.rdsClient.DescribeBlueGreenDeployments(ctx, &rds.DescribeBlueGreenDeploymentsInput{
		BlueGreenDeploymentIdentifier: aws.String(bgdID),
	})
	if err != nil {
		return nil, err
	}
	if len(resp.BlueGreenDeployments) == 0 {
		return nil, fmt.Errorf("blue/green deployment %s not found", bgdID)
	}
	return &resp.BlueGreenDeployments[0], nil
}

func arnToInstanceID(arn string) string {
	parts := strings.Split(arn, ":")
	return parts[len(parts)-1]
}

func (a *AWSChecks) checkBGDStatus(report *Report, bgd *rdstypes.BlueGreenDeployment) {
	status := aws.ToString(bgd.Status)
	if status == "AVAILABLE" {
		report.Add(CheckResult{Name: "BGD Status", Status: PASS, Message: "Deployment is AVAILABLE."})
	} else {
		report.Add(CheckResult{Name: "BGD Status", Status: FAIL, Message: fmt.Sprintf("Deployment is %s; must be AVAILABLE for switchover.", status)})
	}
}

func (a *AWSChecks) checkInstanceStatus(ctx context.Context, report *Report, instanceID, label string) {
	resp, err := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(instanceID),
	})
	if err != nil {
		report.Add(CheckResult{Name: label + " Instance Status", Status: FAIL, Message: err.Error()})
		return
	}
	status := aws.ToString(resp.DBInstances[0].DBInstanceStatus)
	if status == "available" {
		report.Add(CheckResult{Name: label + " Instance Status", Status: PASS, Message: instanceID + " is available."})
	} else {
		report.Add(CheckResult{Name: label + " Instance Status", Status: FAIL, Message: fmt.Sprintf("%s is %s; must be available.", instanceID, status)})
	}
}

func (a *AWSChecks) checkReplicationHealth(report *Report, bgd *rdstypes.BlueGreenDeployment) {
	tasks := bgd.Tasks
	found := false
	for _, task := range tasks {
		name := aws.ToString(task.Name)
		status := aws.ToString(task.Status)
		if strings.Contains(strings.ToLower(name), "replication") {
			found = true
			if status == "COMPLETED" || status == "AVAILABLE" || status == "IN_SYNC" {
				report.Add(CheckResult{Name: "Replication Health (BGD Tasks)", Status: PASS, Message: fmt.Sprintf("Task '%s' status: %s.", name, status)})
			} else {
				report.Add(CheckResult{Name: "Replication Health (BGD Tasks)", Status: WARN, Message: fmt.Sprintf("Task '%s' status: %s. Verify replication is healthy.", name, status)})
			}
		}
	}
	if !found {
		report.Add(CheckResult{Name: "Replication Health (BGD Tasks)", Status: INFO, Message: "No replication task entries found on deployment; check console for replication state."})
	}
}

func (a *AWSChecks) checkReplicaLag(ctx context.Context, report *Report, instanceID, label, metricName string, threshold float64) {
	now := time.Now()
	resp, err := a.cwClient.GetMetricStatistics(ctx, &cloudwatch.GetMetricStatisticsInput{
		Namespace:  aws.String("AWS/RDS"),
		MetricName: aws.String(metricName),
		Dimensions: []cwtypes.Dimension{{Name: aws.String("DBInstanceIdentifier"), Value: aws.String(instanceID)}},
		StartTime:  aws.Time(now.Add(-15 * time.Minute)),
		EndTime:    aws.Time(now),
		Period:     aws.Int32(60),
		Statistics: []cwtypes.Statistic{cwtypes.StatisticAverage, cwtypes.StatisticMaximum},
	})
	if err != nil {
		report.Add(CheckResult{Name: label, Status: WARN, Message: "Error fetching CloudWatch metrics: " + err.Error()})
		return
	}

	if len(resp.Datapoints) == 0 {
		report.Add(CheckResult{Name: label, Status: WARN, Message: fmt.Sprintf("No %s datapoints found in last 15 min.", metricName)})
		return
	}

	var latest cwtypes.Datapoint
	for _, dp := range resp.Datapoints {
		if latest.Timestamp == nil || dp.Timestamp.After(*latest.Timestamp) {
			latest = dp
		}
	}

	avg := aws.ToFloat64(latest.Average)
	mx := aws.ToFloat64(latest.Maximum)

	if mx <= threshold {
		report.Add(CheckResult{Name: label, Status: PASS, Message: fmt.Sprintf("Avg=%.1f, Max=%.1f (threshold %.1f).", avg, mx, threshold)})
	} else if mx <= threshold*3 {
		report.Add(CheckResult{Name: label, Status: WARN, Message: fmt.Sprintf("Avg=%.1f, Max=%.1f — elevated but may converge.", avg, mx)})
	} else {
		report.Add(CheckResult{Name: label, Status: FAIL, Message: fmt.Sprintf("Avg=%.1f, Max=%.1f — too high for safe switchover.", avg, mx)})
	}
}

func (a *AWSChecks) checkDatabaseConnections(ctx context.Context, report *Report, instanceID, label string) {
	now := time.Now()
	resp, err := a.cwClient.GetMetricStatistics(ctx, &cloudwatch.GetMetricStatisticsInput{
		Namespace:  aws.String("AWS/RDS"),
		MetricName: aws.String("DatabaseConnections"),
		Dimensions: []cwtypes.Dimension{{Name: aws.String("DBInstanceIdentifier"), Value: aws.String(instanceID)}},
		StartTime:  aws.Time(now.Add(-10 * time.Minute)),
		EndTime:    aws.Time(now),
		Period:     aws.Int32(60),
		Statistics: []cwtypes.Statistic{cwtypes.StatisticAverage, cwtypes.StatisticMaximum},
	})
	if err != nil {
		report.Add(CheckResult{Name: label + " Database Connections", Status: WARN, Message: "Error fetching CloudWatch metrics: " + err.Error()})
		return
	}

	if len(resp.Datapoints) == 0 {
		report.Add(CheckResult{Name: label + " Database Connections", Status: WARN, Message: "No DatabaseConnections datapoints available."})
		return
	}

	var latest cwtypes.Datapoint
	for _, dp := range resp.Datapoints {
		if latest.Timestamp == nil || dp.Timestamp.After(*latest.Timestamp) {
			latest = dp
		}
	}

	avg := aws.ToFloat64(latest.Average)
	mx := aws.ToFloat64(latest.Maximum)

	if mx <= 100 {
		report.Add(CheckResult{Name: label + " Database Connections", Status: PASS, Message: fmt.Sprintf("Avg=%.0f, Max=%.0f — within normal range.", avg, mx)})
	} else {
		report.Add(CheckResult{Name: label + " Database Connections", Status: WARN, Message: fmt.Sprintf("Avg=%.0f, Max=%.0f — consider reducing before switchover.", avg, mx)})
	}
}

func (a *AWSChecks) checkWriteActivity(ctx context.Context, report *Report, instanceID, label string) {
	now := time.Now()
	for _, metric := range []string{"WriteIOPS", "WriteThroughput"} {
		resp, err := a.cwClient.GetMetricStatistics(ctx, &cloudwatch.GetMetricStatisticsInput{
			Namespace:  aws.String("AWS/RDS"),
			MetricName: aws.String(metric),
			Dimensions: []cwtypes.Dimension{{Name: aws.String("DBInstanceIdentifier"), Value: aws.String(instanceID)}},
			StartTime:  aws.Time(now.Add(-10 * time.Minute)),
			EndTime:    aws.Time(now),
			Period:     aws.Int32(60),
			Statistics: []cwtypes.Statistic{cwtypes.StatisticAverage, cwtypes.StatisticMaximum},
		})
		if err != nil {
			continue
		}
		if len(resp.Datapoints) > 0 {
			var latest cwtypes.Datapoint
			for _, dp := range resp.Datapoints {
				if latest.Timestamp == nil || dp.Timestamp.After(*latest.Timestamp) {
					latest = dp
				}
			}
			avg := aws.ToFloat64(latest.Average)
			mx := aws.ToFloat64(latest.Maximum)
			report.Add(CheckResult{Name: label + " " + metric, Status: INFO, Message: fmt.Sprintf("Avg=%.1f, Max=%.1f", avg, mx)})
		}
	}
}

func (a *AWSChecks) checkExternalReplication(ctx context.Context, report *Report, instanceID string) {
	resp, err := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(instanceID),
	})
	if err != nil {
		report.Add(CheckResult{Name: "External Replication (Blue)", Status: FAIL, Message: err.Error()})
		return
	}
	inst := resp.DBInstances[0]
	source := aws.ToString(inst.ReadReplicaSourceDBInstanceIdentifier)

	if source != "" {
		report.Add(CheckResult{Name: "External Replication (Blue)", Status: WARN, Message: "Blue instance is a read replica of " + source + ". Run SQL checks for logical pub/sub."})
	} else {
		report.Add(CheckResult{Name: "External Replication (Blue)", Status: PASS, Message: "No external replication source detected via API."})
	}
}

func (a *AWSChecks) checkParameterGroupPending(ctx context.Context, report *Report, instanceID, label string) {
	resp, err := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(instanceID),
	})
	if err != nil {
		report.Add(CheckResult{Name: label + " Parameter Group", Status: FAIL, Message: err.Error()})
		return
	}
	inst := resp.DBInstances[0]
	needsReboot := false
	for _, pg := range inst.DBParameterGroups {
		if aws.ToString(pg.ParameterApplyStatus) == "pending-reboot" {
			needsReboot = true
			break
		}
	}

	if needsReboot {
		report.Add(CheckResult{Name: label + " Parameter Group", Status: WARN, Message: instanceID + " has pending-reboot parameter changes."})
	} else if inst.PendingModifiedValues != nil {
		report.Add(CheckResult{Name: label + " Parameter Group", Status: WARN, Message: instanceID + " has pending modifications."})
	} else {
		report.Add(CheckResult{Name: label + " Parameter Group", Status: PASS, Message: instanceID + " has no pending changes."})
	}
}

func (a *AWSChecks) checkEngineVersions(ctx context.Context, report *Report, blueID, greenID string) {
	blueResp, _ := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(blueID)})
	greenResp, _ := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(greenID)})

	if len(blueResp.DBInstances) > 0 && len(greenResp.DBInstances) > 0 {
		bv := aws.ToString(blueResp.DBInstances[0].EngineVersion)
		gv := aws.ToString(greenResp.DBInstances[0].EngineVersion)
		if bv == gv {
			report.Add(CheckResult{Name: "Engine Version", Status: INFO, Message: "Both on PostgreSQL " + bv})
		} else {
			report.Add(CheckResult{Name: "Engine Version", Status: INFO, Message: fmt.Sprintf("Blue=%s, Green=%s", bv, gv)})
		}
	}
}

func (a *AWSChecks) checkReadReplicas(ctx context.Context, report *Report, blueID, greenID string) {
	blueResp, _ := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(blueID)})
	greenResp, _ := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(greenID)})

	if len(blueResp.DBInstances) > 0 && len(greenResp.DBInstances) > 0 {
		blueRR := blueResp.DBInstances[0].ReadReplicaDBInstanceIdentifiers
		greenRR := greenResp.DBInstances[0].ReadReplicaDBInstanceIdentifiers
		report.Add(CheckResult{Name: "Read Replicas", Status: INFO, Message: fmt.Sprintf("Blue has %d, Green has %d.", len(blueRR), len(greenRR))})
		if len(blueRR) != len(greenRR) {
			report.Add(CheckResult{Name: "Read Replica Count Mismatch", Status: WARN, Message: "Blue and green have different replica counts."})
		}
	}
}

func (a *AWSChecks) checkIAMRoles(ctx context.Context, report *Report, blueID, greenID string) {
	blueResp, _ := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(blueID)})
	greenResp, _ := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{DBInstanceIdentifier: aws.String(greenID)})

	if len(blueResp.DBInstances) > 0 && len(greenResp.DBInstances) > 0 {
		blueRoles := blueResp.DBInstances[0].AssociatedRoles
		greenRoles := greenResp.DBInstances[0].AssociatedRoles
		if len(blueRoles) > 0 && len(greenRoles) == 0 {
			report.Add(CheckResult{Name: "IAM Role Association", Status: WARN, Message: "Blue has roles but green has none. Roles are NOT auto-copied."})
		} else {
			report.Add(CheckResult{Name: "IAM Role Association", Status: PASS, Message: fmt.Sprintf("Blue roles: %d, Green roles: %d", len(blueRoles), len(greenRoles))})
		}
	}
}

func (a *AWSChecks) checkStorage(ctx context.Context, report *Report, instanceID, label string) {
	resp, err := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(instanceID),
	})
	if err == nil && len(resp.DBInstances) > 0 {
		inst := resp.DBInstances[0]
		st := aws.ToString(inst.StorageType)
		alloc := aws.ToInt32(inst.AllocatedStorage)
		report.Add(CheckResult{Name: label + " Storage", Status: INFO, Message: fmt.Sprintf("Type=%s, AllocatedGB=%d", st, alloc)})
	}
}

func (a *AWSChecks) checkMultiAZ(ctx context.Context, report *Report, instanceID, label string) {
	resp, err := a.rdsClient.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(instanceID),
	})
	if err == nil && len(resp.DBInstances) > 0 {
		multiAZ := aws.ToBool(resp.DBInstances[0].MultiAZ)
		report.Add(CheckResult{Name: label + " Multi-AZ", Status: INFO, Message: fmt.Sprintf("MultiAZ=%v", multiAZ)})
	}
}

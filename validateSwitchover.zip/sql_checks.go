package main

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/feature/rds/auth"
	"github.com/jackc/pgx/v5"
)

type SQLChecks struct {
	host     string
	port     int
	user     string
	password string
	iam      bool
	region   string
	profile  string
}

func NewSQLChecks(host string, port int, user, password string, iam bool, region, profile string) *SQLChecks {
	return &SQLChecks{
		host:     host,
		port:     port,
		user:     user,
		password: password,
		iam:      iam,
		region:   region,
		profile:  profile,
	}
}

func (s *SQLChecks) getIAMToken(ctx context.Context) (string, error) {
	var cfg aws.Config
	var err error

	if s.profile != "" {
		cfg, err = config.LoadDefaultConfig(ctx,
			config.WithRegion(s.region),
			config.WithSharedConfigProfile(s.profile),
		)
	} else {
		cfg, err = config.LoadDefaultConfig(ctx,
			config.WithRegion(s.region),
		)
	}

	if err != nil {
		return "", err
	}

	endpoint := fmt.Sprintf("%s:%d", s.host, s.port)
	return auth.BuildAuthToken(ctx, endpoint, s.region, s.user, cfg.Credentials)
}

func (s *SQLChecks) connect(ctx context.Context, dbname string) (*pgx.Conn, error) {
	password := s.password
	if s.iam {
		token, err := s.getIAMToken(ctx)
		if err != nil {
			return nil, fmt.Errorf("failed to get IAM token: %v", err)
		}
		password = token
	}

	connStr := fmt.Sprintf("postgres://%s:%s@%s:%d/%s?sslmode=require", s.user, password, s.host, s.port, dbname)
	return pgx.Connect(ctx, connStr)
}

func (s *SQLChecks) RunAll(ctx context.Context, dbname string) (*Report, error) {
	report := &Report{
		ID:        s.host,
		DBName:    dbname,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	conn, err := s.connect(ctx, dbname)
	if err != nil {
		report.Add(CheckResult{Name: "Connection", Status: FAIL, Message: "Cannot connect: " + err.Error()})
		return report, nil
	}
	defer conn.Close(ctx)

	report.Add(CheckResult{Name: "Connection", Status: PASS, Message: fmt.Sprintf("Connected to %s as %s.", dbname, s.user)})

	s.checkReplicationSlotLag(ctx, report, conn)
	s.checkLongRunningQueries(ctx, report, conn)
	s.checkActiveDDL(ctx, report, conn)
	s.checkActiveWrites(ctx, report, conn)
	s.checkIdleInTransaction(ctx, report, conn)
	s.checkPreparedTransactions(ctx, report, conn)
	s.checkPublications(ctx, report, conn)
	s.checkSubscriptions(ctx, report, conn)
	s.checkTablesWithoutPK(ctx, report, conn)
	s.checkUnloggedTables(ctx, report, conn)
	s.checkLargeObjects(ctx, report, conn)
	s.checkExtensionCompatibility(ctx, report, conn)
	s.checkSequenceCount(ctx, report, conn)
	s.checkAnalyzeFreshness(ctx, report, conn)

	report.Add(CheckResult{
		Name:    "default_transaction_read_only Override",
		Status:  WARN,
		Message: "Audit your application: ensure no sessions override default_transaction_read_only to 'off' at session level.",
	})

	return report, nil
}

func (s *SQLChecks) GetAllDatabases(ctx context.Context) ([]string, error) {
	conn, err := s.connect(ctx, "postgres")
	if err != nil {
		return nil, err
	}
	defer conn.Close(ctx)

	rows, err := conn.Query(ctx, "SELECT datname FROM pg_database WHERE datistemplate = false AND datname NOT IN ('rdsadmin') ORDER BY datname")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var databases []string
	for rows.Next() {
		var dbname string
		if err := rows.Scan(&dbname); err != nil {
			return nil, err
		}
		databases = append(databases, dbname)
	}
	return databases, nil
}

func (s *SQLChecks) checkReplicationSlotLag(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := `
        SELECT slot_name, active, (pg_current_wal_lsn() - confirmed_flush_lsn) AS lsn_distance
        FROM pg_catalog.pg_replication_slots
        WHERE slot_type = 'logical';
    `
	rows, err := conn.Query(ctx, sql)
	if err != nil {
		report.Add(CheckResult{Name: "Logical Replication Slots", Status: WARN, Message: "Could not query replication slots: " + err.Error()})
		return
	}
	defer rows.Close()

	found := false
	for rows.Next() {
		found = true
		var name string
		var active bool
		var distance *int64
		if err := rows.Scan(&name, &active, &distance); err != nil {
			continue
		}

		distVal := int64(0)
		if distance != nil {
			distVal = *distance
		}

		if !active {
			report.Add(CheckResult{Name: "Replication Slot: " + name, Status: FAIL, Message: fmt.Sprintf("Slot is INACTIVE. Distance=%d bytes.", distVal)})
		} else if distVal == 0 {
			report.Add(CheckResult{Name: "Replication Slot: " + name, Status: PASS, Message: "Fully caught up."})
		} else if distVal < 1048576 {
			report.Add(CheckResult{Name: "Replication Slot: " + name, Status: PASS, Message: fmt.Sprintf("Near zero lag. lsn_distance=%d bytes.", distVal)})
		} else {
			report.Add(CheckResult{Name: "Replication Slot: " + name, Status: FAIL, Message: fmt.Sprintf("High lag. lsn_distance=%d bytes.", distVal)})
		}
	}

	if !found {
		report.Add(CheckResult{Name: "Logical Replication Slots", Status: INFO, Message: "No logical replication slots found."})
	}
}

func (s *SQLChecks) checkLongRunningQueries(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := `
        SELECT pid, usename, now() - query_start AS duration, query
        FROM pg_stat_activity
        WHERE state = 'active' AND pid <> pg_backend_pid() AND query_start < now() - interval '60 seconds'
        ORDER BY duration DESC;
    `
	rows, err := conn.Query(ctx, sql)
	if err != nil {
		report.Add(CheckResult{Name: "Long-Running Queries", Status: WARN, Message: err.Error()})
		return
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		count++
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Long-Running Queries", Status: PASS, Message: "No active queries running longer than 60s."})
	} else {
		report.Add(CheckResult{Name: "Long-Running Queries", Status: WARN, Message: fmt.Sprintf("%d active query(ies) running > 60s.", count)})
	}
}

func (s *SQLChecks) checkActiveDDL(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := `
        SELECT pid, usename, query
        FROM pg_stat_activity
        WHERE state = 'active' AND pid <> pg_backend_pid()
          AND (query ~* '^\s*(CREATE|ALTER|DROP|TRUNCATE|REINDEX|CLUSTER|VACUUM FULL)' OR query ~* '^\s*REFRESH MATERIALIZED VIEW')
    `
	rows, err := conn.Query(ctx, sql)
	if err != nil {
		report.Add(CheckResult{Name: "Active DDL Statements", Status: WARN, Message: err.Error()})
		return
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		count++
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Active DDL Statements", Status: PASS, Message: "No active DDL statements detected."})
	} else {
		report.Add(CheckResult{Name: "Active DDL Statements", Status: FAIL, Message: fmt.Sprintf("%d active DDL statement(s).", count)})
	}
}

func (s *SQLChecks) checkActiveWrites(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := `
        SELECT pid, usename, query
        FROM pg_stat_activity
        WHERE state IN ('active', 'idle in transaction') AND pid <> pg_backend_pid() AND xact_start IS NOT NULL
          AND query ~* '^\s*(INSERT|UPDATE|DELETE|COPY|MERGE)' AND EXTRACT(EPOCH FROM (now() - xact_start)) > 30
    `
	rows, err := conn.Query(ctx, sql)
	if err != nil {
		report.Add(CheckResult{Name: "Long-Running Write Transactions", Status: WARN, Message: err.Error()})
		return
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		count++
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Long-Running Write Transactions", Status: PASS, Message: "No long-running write transactions (> 30s)."})
	} else {
		report.Add(CheckResult{Name: "Long-Running Write Transactions", Status: WARN, Message: fmt.Sprintf("%d long-running write transaction(s).", count)})
	}
}

func (s *SQLChecks) checkIdleInTransaction(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := `
        SELECT pid, usename FROM pg_stat_activity
        WHERE state = 'idle in transaction' AND pid <> pg_backend_pid() AND EXTRACT(EPOCH FROM (now() - state_change)) > 300
    `
	rows, err := conn.Query(ctx, sql)
	if err != nil {
		report.Add(CheckResult{Name: "Idle-in-Transaction Sessions", Status: WARN, Message: err.Error()})
		return
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		count++
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Idle-in-Transaction Sessions", Status: PASS, Message: "No idle-in-transaction sessions older than 300s."})
	} else {
		report.Add(CheckResult{Name: "Idle-in-Transaction Sessions", Status: WARN, Message: fmt.Sprintf("%d idle-in-transaction session(s) > 300s.", count)})
	}
}

func (s *SQLChecks) checkPreparedTransactions(ctx context.Context, report *Report, conn *pgx.Conn) {
	var count int
	err := conn.QueryRow(ctx, "SELECT COUNT(*) FROM pg_prepared_xacts").Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "Prepared Transactions", Status: WARN, Message: err.Error()})
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Prepared Transactions", Status: PASS, Message: "No prepared (two-phase) transactions."})
	} else {
		report.Add(CheckResult{Name: "Prepared Transactions", Status: FAIL, Message: fmt.Sprintf("%d prepared transaction(s).", count)})
	}
}

func (s *SQLChecks) checkPublications(ctx context.Context, report *Report, conn *pgx.Conn) {
	var count int
	err := conn.QueryRow(ctx, "SELECT COUNT(*) FROM pg_publication WHERE pubname NOT LIKE 'rds_%'").Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "Self-Managed Publications", Status: WARN, Message: err.Error()})
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Self-Managed Publications", Status: PASS, Message: "No self-managed logical publications found."})
	} else {
		report.Add(CheckResult{Name: "Self-Managed Publications", Status: FAIL, Message: fmt.Sprintf("%d self-managed publication(s) found.", count)})
	}
}

func (s *SQLChecks) checkSubscriptions(ctx context.Context, report *Report, conn *pgx.Conn) {
	var count int
	err := conn.QueryRow(ctx, "SELECT COUNT(*) FROM pg_subscription").Scan(&count)
	if err != nil {
		if strings.Contains(err.Error(), "permission denied") {
			report.Add(CheckResult{Name: "Self-Managed Subscriptions", Status: WARN, Message: "Cannot query pg_subscription (insufficient privileges)."})
		} else {
			report.Add(CheckResult{Name: "Self-Managed Subscriptions", Status: WARN, Message: err.Error()})
		}
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Self-Managed Subscriptions", Status: PASS, Message: "No self-managed logical subscriptions found."})
	} else {
		report.Add(CheckResult{Name: "Self-Managed Subscriptions", Status: FAIL, Message: fmt.Sprintf("%d subscription(s) found.", count)})
	}
}

func (s *SQLChecks) checkTablesWithoutPK(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := `
        SELECT COUNT(*)
        FROM pg_catalog.pg_class c
        JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relkind = 'r' AND n.nspname NOT IN ('pg_catalog', 'information_schema', 'pg_toast')
          AND n.nspname NOT LIKE 'pg_temp%'
          AND NOT EXISTS (SELECT 1 FROM pg_catalog.pg_constraint con WHERE con.conrelid = c.oid AND con.contype = 'p')
          AND c.relreplident <> 'f'
    `
	var count int
	err := conn.QueryRow(ctx, sql).Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "Tables Without Primary Key", Status: WARN, Message: err.Error()})
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Tables Without Primary Key", Status: PASS, Message: "All user tables have a primary key or REPLICA IDENTITY FULL."})
	} else {
		report.Add(CheckResult{Name: "Tables Without Primary Key", Status: WARN, Message: fmt.Sprintf("%d table(s) lack a primary key.", count)})
	}
}

func (s *SQLChecks) checkUnloggedTables(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := "SELECT COUNT(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE c.relpersistence = 'u' AND c.relkind = 'r' AND n.nspname NOT IN ('pg_catalog', 'information_schema')"
	var count int
	err := conn.QueryRow(ctx, sql).Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "Unlogged Tables", Status: WARN, Message: err.Error()})
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Unlogged Tables", Status: PASS, Message: "No unlogged tables found."})
	} else {
		report.Add(CheckResult{Name: "Unlogged Tables", Status: WARN, Message: fmt.Sprintf("%d unlogged table(s) found.", count)})
	}
}

func (s *SQLChecks) checkLargeObjects(ctx context.Context, report *Report, conn *pgx.Conn) {
	var count int
	err := conn.QueryRow(ctx, "SELECT COUNT(*) FROM pg_largeobject_metadata").Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "Large Objects", Status: WARN, Message: err.Error()})
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "Large Objects", Status: PASS, Message: "No large objects found."})
	} else {
		report.Add(CheckResult{Name: "Large Objects", Status: WARN, Message: fmt.Sprintf("%d large object(s) detected.", count)})
	}
}

func (s *SQLChecks) checkExtensionCompatibility(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := "SELECT extname FROM pg_extension WHERE extname IN ('pg_partman', 'pg_cron', 'pglogical', 'pgactive')"
	rows, err := conn.Query(ctx, sql)
	if err != nil {
		report.Add(CheckResult{Name: "Extension Compatibility", Status: WARN, Message: err.Error()})
		return
	}
	defer rows.Close()

	var found []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err == nil {
			found = append(found, name)
		}
	}

	if len(found) == 0 {
		report.Add(CheckResult{Name: "Extension Compatibility", Status: PASS, Message: "No problematic extensions found."})
	} else {
		report.Add(CheckResult{Name: "Extension Compatibility", Status: WARN, Message: "Found problematic extensions: " + strings.Join(found, ", ")})
	}
}

func (s *SQLChecks) checkSequenceCount(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := "SELECT COUNT(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind = 'S' AND n.nspname NOT IN ('pg_catalog', 'information_schema')"
	var count int
	err := conn.QueryRow(ctx, sql).Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "Sequence Count", Status: WARN, Message: err.Error()})
		return
	}
	if count < 100 {
		report.Add(CheckResult{Name: "Sequence Count", Status: PASS, Message: fmt.Sprintf("%d sequence(s).", count)})
	} else {
		report.Add(CheckResult{Name: "Sequence Count", Status: INFO, Message: fmt.Sprintf("%d sequence(s).", count)})
	}
}

func (s *SQLChecks) checkAnalyzeFreshness(ctx context.Context, report *Report, conn *pgx.Conn) {
	sql := "SELECT COUNT(*) FROM pg_stat_user_tables WHERE GREATEST(last_analyze, last_autoanalyze) IS NULL OR GREATEST(last_analyze, last_autoanalyze) < now() - interval '7 days'"
	var count int
	err := conn.QueryRow(ctx, sql).Scan(&count)
	if err != nil {
		report.Add(CheckResult{Name: "ANALYZE Freshness", Status: WARN, Message: err.Error()})
		return
	}
	if count == 0 {
		report.Add(CheckResult{Name: "ANALYZE Freshness", Status: PASS, Message: "All user tables analyzed within 7 days."})
	} else {
		report.Add(CheckResult{Name: "ANALYZE Freshness", Status: WARN, Message: fmt.Sprintf("%d table(s) have stale or missing statistics.", count)})
	}
}

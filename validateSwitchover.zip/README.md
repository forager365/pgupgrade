# RDS PostgreSQL Blue/Green Pre-Switchover Validation

Scripts to validate readiness before switching over an AWS RDS PostgreSQL blue/green deployment. Based on [AWS switchover documentation](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/blue-green-deployments-switching.html).

## Files

| Script | Purpose |
|---|---|
| `run_all_checks.py` | Wrapper — runs both API and SQL checks, prints combined verdict |
| `pre_switchover_checks.py` | AWS API-level checks via boto3 (CloudWatch, RDS describe calls) |
| `sql_checks.py` | Database-level checks via psycopg2 (replication lag, DDL, locks, extensions) |

## Prerequisites

```bash
pip install boto3 psycopg2-binary --break-system-packages
```

AWS credentials must be configured (SSO profile, env vars, or instance role).

## Usage

### Full validation (recommended)

```bash
python run_all_checks.py \
    --bgd-id bgd-xxxxxxxxxxxx \
    --host mydb.cluster-xxxx.us-east-1.rds.amazonaws.com \
    --dbname mydb \
    --user iam_user \
    --iam \
    --profile my-sso-profile \
    --region us-east-1
```

### Scan all databases on the instance

```bash
python run_all_checks.py \
    --bgd-id bgd-xxxxxxxxxxxx \
    --host mydb.xxxx.us-east-1.rds.amazonaws.com \
    --user iam_user \
    --iam --all-databases \
    --profile my-sso-profile
```

### API checks only

```bash
python pre_switchover_checks.py --bgd-id bgd-xxxxxxxxxxxx --profile my-profile --region us-east-1
```

### SQL checks only (password auth)

```bash
python sql_checks.py \
    --host mydb.xxxx.us-east-1.rds.amazonaws.com \
    --dbname mydb \
    --user admin \
    --password 'secret'
```

### JSON output (for CI/CD pipelines)

All scripts accept `--json` for machine-readable output.

```bash
python pre_switchover_checks.py --bgd-id bgd-xxx --json | jq '.summary'
```

## Exit codes

- `0` — all critical checks passed, safe to switch over
- `1` — one or more FAIL results, do not switch over

## Checks Reference

### API-Level Checks (`pre_switchover_checks.py`)

| Check | Source | Guardrail? |
|---|---|---|
| BGD Status = AVAILABLE | `describe_blue_green_deployments` | Yes |
| Blue instance status = available | `describe_db_instances` | Yes |
| Green instance status = available | `describe_db_instances` | Yes |
| Replication health (BGD tasks) | BGD task entries | Yes |
| Green ReplicaLag (CloudWatch) | `ReplicaLag` metric | Yes |
| Blue OldestReplicationSlotLag | CloudWatch metric | Yes (logical) |
| External replication (blue) | Read replica source check | Yes |
| DatabaseConnections (blue/green) | CloudWatch metric | Best practice |
| Write activity (blue WriteIOPS) | CloudWatch metric | Best practice |
| Pending parameter group changes | `describe_db_instances` | Best practice |
| Engine version comparison | Blue vs green version | Info |
| Read replica count match | Blue vs green replicas | Info |
| IAM role association | Roles not auto-copied | Best practice |
| Storage type / IOPS | Awareness | Info |
| Multi-AZ status | Awareness | Info |
| DNS TTL reminder | Static reminder | Best practice |

### SQL-Level Checks (`sql_checks.py`)

| Check | Query | Guardrail? |
|---|---|---|
| Logical replication slot lag | `pg_replication_slots` + `pg_current_wal_lsn()` | Yes |
| Long-running queries (> 60s) | `pg_stat_activity` | Yes |
| Active DDL statements | `pg_stat_activity` regex filter | Yes |
| Long-running write transactions | `pg_stat_activity` xact_start | Yes |
| Idle-in-transaction sessions | `pg_stat_activity` state filter | Best practice |
| Prepared (2PC) transactions | `pg_prepared_xacts` | Best practice |
| Self-managed publications | `pg_publication` (non-rds_%) | Yes |
| Self-managed subscriptions | `pg_subscription` | Yes |
| Tables without primary key | `pg_class` + `pg_constraint` | Yes (logical) |
| Unlogged tables | `pg_class.relpersistence = 'u'` | Limitation |
| Large objects | `pg_largeobject_metadata` | Yes (logical) |
| Extension compatibility | `pg_extension` (pg_partman, pg_cron, etc.) | Limitation |
| Sequence count | `pg_class.relkind = 'S'` | Performance |
| ANALYZE freshness | `pg_stat_user_tables.last_analyze` | Best practice |
| default_transaction_read_only | Static audit reminder | Best practice |

## Status Meanings

- **PASS** — check satisfied, no action needed
- **FAIL** — blocker, must resolve before switchover
- **WARN** — review recommended, may not block but carries risk
- **INFO** — informational, no action required
- **SKIP** — check could not run (missing data or permissions)

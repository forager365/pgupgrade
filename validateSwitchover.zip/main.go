package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/fatih/color"
)

func main() {
	// AWS args
	bgdID := flag.String("bgd-id", "", "Blue/green deployment ID")
	profile := flag.String("profile", "", "AWS profile")
	region := flag.String("region", "us-east-1", "AWS region")

	// SQL args
	host := flag.String("host", "", "RDS endpoint")
	port := flag.Int("port", 5432, "Postgres port")
	dbname := flag.String("dbname", "postgres", "Database name")
	user := flag.String("user", "", "Database user")
	password := flag.String("password", "", "Database password")
	iam := flag.Bool("iam", false, "Use IAM auth")
	allDatabases := flag.Bool("all-databases", false, "Check all databases")

	flag.Parse()

	if *bgdID == "" {
		fmt.Println("Error: --bgd-id is required")
		flag.Usage()
		os.Exit(1)
	}

	ctx := context.Background()

	width := 88
	fmt.Println(strings.Repeat("=", width))
	fmt.Println("  FULL PRE-SWITCHOVER VALIDATION (Go)")
	fmt.Printf("  %s\n", time.Now().Format(time.RFC3339))
	fmt.Println(strings.Repeat("=", width))

	// Phase 1: AWS API Checks
	fmt.Println("\n▶ PHASE 1: AWS API Checks")
	awsChecks, err := NewAWSChecks(ctx, *region, *profile)
	if err != nil {
		fmt.Printf("Error initializing AWS checks: %v\n", err)
		os.Exit(1)
	}

	apiReport, err := awsChecks.RunAll(ctx, *bgdID)
	if err != nil {
		fmt.Printf("Error running API checks: %v\n", err)
		os.Exit(1)
	}
	apiReport.Print()

	// Phase 2: SQL Checks
	sqlHasFail := false
	if *host != "" && *user != "" {
		fmt.Println("\n▶ PHASE 2: SQL Database Checks")
		sqlChecks := NewSQLChecks(*host, *port, *user, *password, *iam, *region, *profile)

		var databases []string
		if *allDatabases {
			dbs, err := sqlChecks.GetAllDatabases(ctx)
			if err != nil {
				fmt.Printf("Error fetching databases: %v\n", err)
				os.Exit(1)
			}
			databases = dbs
			fmt.Printf("  Scanning %d database(s): %s\n", len(databases), strings.Join(databases, ", "))
		} else {
			databases = []string{*dbname}
		}

		for _, db := range databases {
			sqlReport, err := sqlChecks.RunAll(ctx, db)
			if err != nil {
				fmt.Printf("Error running SQL checks for %s: %v\n", db, err)
				continue
			}
			sqlReport.Print()
			if sqlReport.HasFailures() {
				sqlHasFail = true
			}
		}
	} else {
		fmt.Println("\n▶ PHASE 2: SQL Database Checks (Skipped: missing --host or --user)")
	}

	// Verdict
	anyFail := apiReport.HasFailures() || sqlHasFail
	fmt.Println(strings.Repeat("=", width))
	if anyFail {
		color.New(color.FgRed, color.Bold).Println("  VERDICT: SWITCHOVER NOT RECOMMENDED — resolve FAIL items above")
	} else {
		color.New(color.FgGreen, color.Bold).Println("  VERDICT: ALL CHECKS PASSED — safe to proceed with switchover")
	}
	fmt.Println(strings.Repeat("=", width))

	if anyFail {
		os.Exit(1)
	}
}

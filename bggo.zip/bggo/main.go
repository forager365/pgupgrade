package main

import (
	"flag"
	"log"
	"net/http"
	"os"
	"path/filepath"

	"github.com/anandbabu/bggo/internal/runlog"
	"github.com/anandbabu/bggo/internal/server"
	"github.com/anandbabu/bggo/internal/upgrade"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8080", "HTTP listen address")
	appDir := flag.String("app-dir", "", "directory containing parameter group JSON files (default: bggo binary's dir)")
	flag.Parse()

	if *appDir == "" {
		exe, err := os.Executable()
		if err != nil {
			log.Fatalf("locate executable: %v", err)
		}
		*appDir = filepath.Dir(exe)
	}
	upgrade.AppDir = *appDir

	bus := runlog.NewBus()
	srv := server.New(bus)

	log.Printf("bggo listening on http://%s (app-dir=%s)", *addr, *appDir)
	if err := http.ListenAndServe(*addr, srv.Routes()); err != nil {
		log.Fatal(err)
	}
}

package upgrade

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/anandbabu/bggo/internal/awsx"
	"github.com/anandbabu/bggo/internal/runlog"
	"github.com/aws/aws-sdk-go-v2/aws"
)

// AppDir is where parameter-group JSON files are read from. Set by main.
var AppDir = "."

// Run executes the blue/green upgrade phases for a single source instance.
// It logs to the bus; the HTTP layer streams those events to the browser.
func Run(ctx context.Context, log *runlog.Bus, req Request) error {
	if err := validate(req); err != nil {
		return err
	}
	log.Infof("loading AWS config for SSO profile %q (region=%s)", req.SSOProfile, req.Region)
	cfg, err := awsx.LoadProfile(ctx, log, req.SSOProfile, req.Region)
	if err != nil {
		return fmt.Errorf("aws config: %w", err)
	}
	rds := newRDS(cfg)

	pgFile, err := loadParamGroupFile(req.ParamGroupFile)
	if err != nil {
		return err
	}

	log.Infof("phase %s", PhaseInit)
	topo, err := rds.describeInstance(ctx, req.SourceInstance)
	if err != nil {
		return err
	}
	log.Infof("source: %s arn=%s engine=%s version=%s pg=%s",
		topo.Identifier, topo.ARN, topo.Engine, topo.EngineVersion, topo.ParameterGroupName)

	log.Infof("phase %s", PhasePreconditions)
	if !strings.HasPrefix(topo.EngineVersion, req.SourceVersion) {
		return fmt.Errorf("source engine version %q does not match requested %q",
			topo.EngineVersion, req.SourceVersion)
	}

	log.Infof("phase %s", PhaseParamGroup)
	family := pgFile.Family
	if family == "" {
		family = deriveFamily(req.TargetVersion)
	}
	desc := fmt.Sprintf("bggo target pg for %s -> %s", topo.Identifier, req.TargetVersion)
	if err := rds.ensureParamGroup(ctx, pgFile.Name, family, desc, pgFile.Parameters); err != nil {
		return err
	}
	log.Infof("parameter group %q ready (family=%s, %d params)", pgFile.Name, family, len(pgFile.Parameters))

	log.Infof("phase %s", PhaseCreateBG)
	existing, err := rds.findBlueGreenBySource(ctx, topo.ARN)
	if err != nil {
		return err
	}
	var bgID string
	if existing != "" {
		bgID = existing
		log.Infof("reusing existing b/g deployment %s", bgID)
	} else {
		bgID, err = rds.createBlueGreen(ctx, deriveBGName(topo.Identifier), topo.ARN, req.TargetVersion, pgFile.Name)
		if err != nil {
			return err
		}
		log.Infof("created b/g deployment %s", bgID)
	}

	log.Infof("phase %s (timeout=%ds)", PhaseWaitGreen, req.GreenWaitTimeoutSeconds)
	if _, err := rds.waitForStatus(ctx, bgID,
		[]string{"AVAILABLE"},
		[]string{"INVALID_CONFIGURATION", "DELETED"},
		time.Duration(req.GreenWaitTimeoutSeconds)*time.Second,
		log.Infof,
	); err != nil {
		return err
	}

	log.Infof("phase %s", PhasePreSwitch)
	d, err := rds.describeBlueGreen(ctx, bgID)
	if err != nil {
		return err
	}
	for _, t := range d.Tasks {
		status := aws.ToString(t.Status)
		if status != "COMPLETED" && status != "SKIPPED" {
			return fmt.Errorf("b/g task %q not done (status=%s)", aws.ToString(t.Name), status)
		}
	}

	log.Infof("phase %s (timeout=%ds)", PhaseSwitchover, req.SwitchoverTimeoutSeconds)
	if err := rds.switchover(ctx, bgID, int32(req.SwitchoverTimeoutSeconds)); err != nil {
		return fmt.Errorf("switchover: %w", err)
	}
	if _, err := rds.waitForStatus(ctx, bgID,
		[]string{"SWITCHOVER_COMPLETED"},
		[]string{"SWITCHOVER_FAILED", "INVALID_CONFIGURATION", "DELETED"},
		time.Duration(max(req.SwitchoverTimeoutSeconds*2, 600))*time.Second,
		log.Infof,
	); err != nil {
		return err
	}

	log.Infof("phase %s", PhasePostValidate)
	after, err := rds.describeInstance(ctx, req.SourceInstance)
	if err != nil {
		return err
	}
	if !strings.HasPrefix(after.EngineVersion, req.TargetVersion) &&
		!strings.HasPrefix(req.TargetVersion, after.EngineVersion) {
		log.Warnf("post-switch engine version is %q, expected to start with %q",
			after.EngineVersion, req.TargetVersion)
	} else {
		log.Infof("post-switch engine version is %q", after.EngineVersion)
	}

	log.Infof("phase %s", PhaseCleanup)
	if req.Cleanup {
		if err := rds.deleteBlueGreen(ctx, bgID, false); err != nil {
			return fmt.Errorf("delete_blue_green: %w", err)
		}
		log.Infof("deleted blue/green deployment %s (kept renamed old-blue instance)", bgID)
	} else {
		log.Infof("cleanup skipped; b/g %s left in place for manual verification", bgID)
	}

	log.Infof("phase %s", PhaseDone)
	return nil
}

func validate(r Request) error {
	missing := []string{}
	if r.SSOProfile == "" {
		missing = append(missing, "sso_profile")
	}
	if r.SourceInstance == "" {
		missing = append(missing, "source_instance")
	}
	if r.SourceVersion == "" {
		missing = append(missing, "source_version")
	}
	if r.TargetVersion == "" {
		missing = append(missing, "target_version")
	}
	if r.ParamGroupFile == "" {
		missing = append(missing, "param_group_file")
	}
	if len(missing) > 0 {
		return fmt.Errorf("missing required fields: %s", strings.Join(missing, ", "))
	}
	return nil
}

func loadParamGroupFile(name string) (ParamGroupFile, error) {
	clean := filepath.Base(name)
	if !strings.HasSuffix(clean, ".json") {
		clean += ".json"
	}
	path := filepath.Join(AppDir, clean)
	raw, err := os.ReadFile(path)
	if err != nil {
		return ParamGroupFile{}, fmt.Errorf("read parameter group file %s: %w", path, err)
	}
	var pg ParamGroupFile
	if err := json.Unmarshal(raw, &pg); err != nil {
		return ParamGroupFile{}, fmt.Errorf("parse parameter group file %s: %w", path, err)
	}
	if pg.Name == "" {
		return ParamGroupFile{}, fmt.Errorf("parameter group file %s missing \"name\"", path)
	}
	return pg, nil
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

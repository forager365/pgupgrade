package upgrade

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
	"github.com/aws/smithy-go"
)

type Topology struct {
	Identifier         string
	ARN                string
	Engine             string
	EngineVersion      string
	ParameterGroupName string
}

type rdsAPI struct {
	c *rds.Client
}

func newRDS(cfg aws.Config) *rdsAPI {
	return &rdsAPI{c: rds.NewFromConfig(cfg)}
}

func (r *rdsAPI) describeInstance(ctx context.Context, id string) (Topology, error) {
	out, err := r.c.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(id),
	})
	if err != nil {
		return Topology{}, fmt.Errorf("describe_db_instances(%s): %w", id, err)
	}
	if len(out.DBInstances) == 0 {
		return Topology{}, fmt.Errorf("db instance not found: %s", id)
	}
	inst := out.DBInstances[0]
	pg := ""
	if len(inst.DBParameterGroups) > 0 {
		pg = aws.ToString(inst.DBParameterGroups[0].DBParameterGroupName)
	}
	return Topology{
		Identifier:         aws.ToString(inst.DBInstanceIdentifier),
		ARN:                aws.ToString(inst.DBInstanceArn),
		Engine:             aws.ToString(inst.Engine),
		EngineVersion:      aws.ToString(inst.EngineVersion),
		ParameterGroupName: pg,
	}, nil
}

func (r *rdsAPI) ensureParamGroup(ctx context.Context, name, family, description string, params map[string]string) error {
	exists, err := r.paramGroupExists(ctx, name)
	if err != nil {
		return err
	}
	if !exists {
		_, err := r.c.CreateDBParameterGroup(ctx, &rds.CreateDBParameterGroupInput{
			DBParameterGroupName:   aws.String(name),
			DBParameterGroupFamily: aws.String(family),
			Description:            aws.String(description),
		})
		if err != nil {
			return fmt.Errorf("create_db_parameter_group(%s): %w", name, err)
		}
	}
	if len(params) == 0 {
		return nil
	}
	payload := make([]rdstypes.Parameter, 0, len(params))
	for k, v := range params {
		payload = append(payload, rdstypes.Parameter{
			ParameterName:  aws.String(k),
			ParameterValue: aws.String(v),
			ApplyMethod:    rdstypes.ApplyMethodPendingReboot,
		})
	}
	_, err = r.c.ModifyDBParameterGroup(ctx, &rds.ModifyDBParameterGroupInput{
		DBParameterGroupName: aws.String(name),
		Parameters:           payload,
	})
	if err != nil {
		return fmt.Errorf("modify_db_parameter_group(%s): %w", name, err)
	}
	return nil
}

func (r *rdsAPI) paramGroupExists(ctx context.Context, name string) (bool, error) {
	_, err := r.c.DescribeDBParameterGroups(ctx, &rds.DescribeDBParameterGroupsInput{
		DBParameterGroupName: aws.String(name),
	})
	if err == nil {
		return true, nil
	}
	var ae smithy.APIError
	if errors.As(err, &ae) && ae.ErrorCode() == "DBParameterGroupNotFound" {
		return false, nil
	}
	return false, err
}

func (r *rdsAPI) findBlueGreenBySource(ctx context.Context, sourceARN string) (string, error) {
	p := rds.NewDescribeBlueGreenDeploymentsPaginator(r.c, &rds.DescribeBlueGreenDeploymentsInput{})
	for p.HasMorePages() {
		page, err := p.NextPage(ctx)
		if err != nil {
			return "", err
		}
		for _, d := range page.BlueGreenDeployments {
			if aws.ToString(d.Source) != sourceARN {
				continue
			}
			status := aws.ToString(d.Status)
			if status == "DELETED" || status == "DELETING" {
				continue
			}
			return aws.ToString(d.BlueGreenDeploymentIdentifier), nil
		}
	}
	return "", nil
}

func (r *rdsAPI) createBlueGreen(ctx context.Context, name, sourceARN, targetVersion, paramGroup string) (string, error) {
	in := &rds.CreateBlueGreenDeploymentInput{
		BlueGreenDeploymentName: aws.String(name),
		Source:                  aws.String(sourceARN),
		TargetEngineVersion:     aws.String(targetVersion),
	}
	if paramGroup != "" {
		in.TargetDBParameterGroupName = aws.String(paramGroup)
	}
	out, err := r.c.CreateBlueGreenDeployment(ctx, in)
	if err != nil {
		return "", fmt.Errorf("create_blue_green_deployment: %w", err)
	}
	return aws.ToString(out.BlueGreenDeployment.BlueGreenDeploymentIdentifier), nil
}

func (r *rdsAPI) describeBlueGreen(ctx context.Context, bgID string) (*rdstypes.BlueGreenDeployment, error) {
	out, err := r.c.DescribeBlueGreenDeployments(ctx, &rds.DescribeBlueGreenDeploymentsInput{
		BlueGreenDeploymentIdentifier: aws.String(bgID),
	})
	if err != nil {
		return nil, err
	}
	if len(out.BlueGreenDeployments) == 0 {
		return nil, fmt.Errorf("blue/green deployment not found: %s", bgID)
	}
	return &out.BlueGreenDeployments[0], nil
}

func (r *rdsAPI) waitForStatus(ctx context.Context, bgID string, targets []string, failures []string, timeout time.Duration, logf func(string, ...any)) (*rdstypes.BlueGreenDeployment, error) {
	deadline := time.Now().Add(timeout)
	for {
		d, err := r.describeBlueGreen(ctx, bgID)
		if err != nil {
			return nil, err
		}
		status := aws.ToString(d.Status)
		logf("b/g %s status=%s", bgID, status)
		if contains(targets, status) {
			return d, nil
		}
		if contains(failures, status) {
			return nil, fmt.Errorf("b/g %s entered failure state %q", bgID, status)
		}
		if time.Now().After(deadline) {
			return nil, fmt.Errorf("timed out after %s waiting for %s to reach %v (last status=%q)", timeout, bgID, targets, status)
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-time.After(30 * time.Second):
		}
	}
}

func (r *rdsAPI) switchover(ctx context.Context, bgID string, timeoutSeconds int32) error {
	_, err := r.c.SwitchoverBlueGreenDeployment(ctx, &rds.SwitchoverBlueGreenDeploymentInput{
		BlueGreenDeploymentIdentifier: aws.String(bgID),
		SwitchoverTimeout:             aws.Int32(timeoutSeconds),
	})
	return err
}

func (r *rdsAPI) deleteBlueGreen(ctx context.Context, bgID string, deleteTarget bool) error {
	_, err := r.c.DeleteBlueGreenDeployment(ctx, &rds.DeleteBlueGreenDeploymentInput{
		BlueGreenDeploymentIdentifier: aws.String(bgID),
		DeleteTarget:                  aws.Bool(deleteTarget),
	})
	return err
}

func contains(haystack []string, needle string) bool {
	for _, s := range haystack {
		if s == needle {
			return true
		}
	}
	return false
}

func deriveBGName(identifier string) string {
	name := "bg-" + identifier
	if len(name) > 60 {
		name = name[:60]
	}
	return name
}

func deriveFamily(targetVersion string) string {
	major := targetVersion
	if i := strings.Index(targetVersion, "."); i >= 0 {
		major = targetVersion[:i]
	}
	return "postgres" + major
}

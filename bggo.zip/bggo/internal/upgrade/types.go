package upgrade

type Phase string

const (
	PhaseInit          Phase = "INIT"
	PhasePreconditions Phase = "PRECONDITIONS"
	PhaseParamGroup    Phase = "PARAM_GROUP"
	PhaseCreateBG      Phase = "CREATE_BLUE_GREEN"
	PhaseWaitGreen     Phase = "WAIT_GREEN_AVAILABLE"
	PhasePreSwitch     Phase = "PRE_SWITCHOVER_VALIDATION"
	PhaseSwitchover    Phase = "SWITCHOVER"
	PhasePostValidate  Phase = "POST_VALIDATION"
	PhaseCleanup       Phase = "CLEANUP"
	PhaseDone          Phase = "DONE"
)

// Request is what the HTTP layer passes in.
type Request struct {
	SSOProfile       string `json:"sso_profile"`
	Region           string `json:"region"`
	SourceInstance   string `json:"source_instance"`
	SourceVersion    string `json:"source_version"`
	TargetVersion    string `json:"target_version"`
	ParamGroupFile   string `json:"param_group_file"`
	Cleanup          bool   `json:"cleanup"`
	SwitchoverTimeoutSeconds int `json:"switchover_timeout_seconds"`
	GreenWaitTimeoutSeconds  int `json:"green_wait_timeout_seconds"`
}

// ParamGroupFile is the on-disk JSON shape for a parameter-group definition.
// Name lets the file be self-describing; Parameters maps param-name to value
// (all applied with ApplyMethod=pending-reboot). Family overrides the
// auto-derived `postgres<major>` if set.
type ParamGroupFile struct {
	Name       string            `json:"name"`
	Family     string            `json:"family,omitempty"`
	Parameters map[string]string `json:"parameters"`
}

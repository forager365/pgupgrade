package server

import (
	"context"
	"embed"
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"

	"github.com/anandbabu/bggo/internal/runlog"
	"github.com/anandbabu/bggo/internal/upgrade"
)

//go:embed web
var webFS embed.FS

type Server struct {
	bus *runlog.Bus

	mu      sync.Mutex
	running bool
	cancel  context.CancelFunc
}

func New(bus *runlog.Bus) *Server { return &Server{bus: bus} }

func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/", s.handleIndex)
	mux.HandleFunc("/run", s.handleRun)
	mux.HandleFunc("/cancel", s.handleCancel)
	mux.HandleFunc("/logs", s.handleLogs)
	return mux
}

func (s *Server) handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	b, err := webFS.ReadFile("web/index.html")
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write(b)
}

func (s *Server) handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	var req upgrade.Request
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	if req.SwitchoverTimeoutSeconds == 0 {
		req.SwitchoverTimeoutSeconds = 600
	}
	if req.GreenWaitTimeoutSeconds == 0 {
		req.GreenWaitTimeoutSeconds = 7200
	}

	s.mu.Lock()
	if s.running {
		s.mu.Unlock()
		http.Error(w, "a run is already in progress", 409)
		return
	}
	s.bus.Reset()
	ctx, cancel := context.WithCancel(context.Background())
	s.running = true
	s.cancel = cancel
	s.mu.Unlock()

	go func() {
		defer func() {
			s.mu.Lock()
			s.running = false
			s.cancel = nil
			s.mu.Unlock()
		}()
		s.bus.Infof("=== run started: %s -> %s on %s (profile=%s) ===",
			req.SourceVersion, req.TargetVersion, req.SourceInstance, req.SSOProfile)
		if err := upgrade.Run(ctx, s.bus, req); err != nil {
			s.bus.Errorf("run failed: %v", err)
			return
		}
		s.bus.Infof("=== run finished successfully ===")
	}()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "started"})
}

func (s *Server) handleCancel(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	s.mu.Lock()
	if s.cancel != nil {
		s.cancel()
		s.bus.Warnf("cancel requested by user")
	}
	s.mu.Unlock()
	w.WriteHeader(204)
}

func (s *Server) handleLogs(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", 500)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")

	ch, hist, unsubscribe := s.bus.Subscribe()
	defer unsubscribe()

	write := func(ev runlog.Event) bool {
		payload, _ := json.Marshal(ev)
		if _, err := fmt.Fprintf(w, "data: %s\n\n", payload); err != nil {
			return false
		}
		flusher.Flush()
		return true
	}

	for _, ev := range hist {
		if !write(ev) {
			return
		}
	}
	ka := time.NewTicker(15 * time.Second)
	defer ka.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case ev, ok := <-ch:
			if !ok {
				return
			}
			if !write(ev) {
				return
			}
		case <-ka.C:
			if _, err := fmt.Fprintf(w, ": keepalive\n\n"); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

// Package runlog is a tiny in-memory pub/sub for run log lines so that
// orchestrator code can emit events without knowing about HTTP, and the
// SSE handler can fan them out to any connected browsers.
package runlog

import (
	"fmt"
	"sync"
	"time"
)

type Event struct {
	Time    time.Time `json:"time"`
	Level   string    `json:"level"`
	Message string    `json:"message"`
}

type Bus struct {
	mu      sync.Mutex
	history []Event
	subs    map[chan Event]struct{}
}

func NewBus() *Bus {
	return &Bus{subs: map[chan Event]struct{}{}}
}

func (b *Bus) Subscribe() (<-chan Event, []Event, func()) {
	ch := make(chan Event, 256)
	b.mu.Lock()
	b.subs[ch] = struct{}{}
	hist := append([]Event(nil), b.history...)
	b.mu.Unlock()
	return ch, hist, func() {
		b.mu.Lock()
		delete(b.subs, ch)
		b.mu.Unlock()
		close(ch)
	}
}

func (b *Bus) emit(level, msg string) {
	ev := Event{Time: time.Now(), Level: level, Message: msg}
	b.mu.Lock()
	b.history = append(b.history, ev)
	if len(b.history) > 2000 {
		b.history = b.history[len(b.history)-2000:]
	}
	subs := make([]chan Event, 0, len(b.subs))
	for ch := range b.subs {
		subs = append(subs, ch)
	}
	b.mu.Unlock()
	for _, ch := range subs {
		select {
		case ch <- ev:
		default:
		}
	}
}

func (b *Bus) Infof(format string, args ...any)  { b.emit("info", fmt.Sprintf(format, args...)) }
func (b *Bus) Warnf(format string, args ...any)  { b.emit("warn", fmt.Sprintf(format, args...)) }
func (b *Bus) Errorf(format string, args ...any) { b.emit("error", fmt.Sprintf(format, args...)) }

func (b *Bus) Reset() {
	b.mu.Lock()
	b.history = nil
	b.mu.Unlock()
}

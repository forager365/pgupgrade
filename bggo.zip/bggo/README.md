# bggo

Go port of the `bg-upgrade` orchestrator with an HTML front end.

## Build / run

```bash
cd bggo
go mod tidy
go build -o bggo .
# On Go < 1.22 + macOS 15+, ad-hoc sign so dyld accepts the binary:
codesign --force --sign - ./bggo
./bggo --addr 127.0.0.1:8080 --app-dir .
```

Open <http://127.0.0.1:8080>.

## Inputs (form)

- **SSO profile** — name of an AWS CLI profile (`~/.aws/config`). If no
  active session, the server runs `aws sso login --profile <name>` and
  streams the device-login URL/code into the log panel.
- **Region** — defaults to whatever the profile is configured with.
- **Source instance** — RDS DB instance identifier (the blue).
- **Source / Target version** — e.g. `14` → `17.2`.
- **Parameter group file** — a JSON file in `--app-dir` (just the name,
  with or without `.json`). See `pg17.json` for the shape.

Logs stream live via Server-Sent Events on `/logs`.

## Parameter group file

```json
{
  "name": "bggo-postgres17-logical-repl",
  "family": "postgres17",
  "parameters": { "rds.logical_replication": "1" }
}
```

`family` is optional; if omitted, `postgres<major>` is derived from the
target version. The group is created if it does not exist and parameters
are applied with `ApplyMethod=pending-reboot`.

## Phases

`INIT` → `PRECONDITIONS` → `PARAM_GROUP` → `CREATE_BLUE_GREEN` →
`WAIT_GREEN_AVAILABLE` → `PRE_SWITCHOVER_VALIDATION` → `SWITCHOVER` →
`POST_VALIDATION` → `CLEANUP` → `DONE`. Mirrors the Python orchestrator.

export namespace config {
	
	export class AWS {
	    SSOProfile: string;
	    Region: string;
	
	    static createFrom(source: any = {}) {
	        return new AWS(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.SSOProfile = source["SSOProfile"];
	        this.Region = source["Region"];
	    }
	}
	export class Options {
	    DropLogicalReplication: boolean;
	    SkipExtensionRecreate: boolean;
	
	    static createFrom(source: any = {}) {
	        return new Options(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.DropLogicalReplication = source["DropLogicalReplication"];
	        this.SkipExtensionRecreate = source["SkipExtensionRecreate"];
	    }
	}
	export class Smoke {
	    CountTables: string[];
	    Queries: string[];
	    GreenHost: string;
	    GreenPort: number;
	
	    static createFrom(source: any = {}) {
	        return new Smoke(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.CountTables = source["CountTables"];
	        this.Queries = source["Queries"];
	        this.GreenHost = source["GreenHost"];
	        this.GreenPort = source["GreenPort"];
	    }
	}
	export class Extension {
	    Name: string;
	    Recreate: boolean;
	    DropBeforeUpgrade: boolean;
	
	    static createFrom(source: any = {}) {
	        return new Extension(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.Name = source["Name"];
	        this.Recreate = source["Recreate"];
	        this.DropBeforeUpgrade = source["DropBeforeUpgrade"];
	    }
	}
	export class Database {
	    Host: string;
	    Port: number;
	    Name: string;
	    User: string;
	    Password: string;
	    PasswordEnv: string;
	    SSLMode: string;
	
	    static createFrom(source: any = {}) {
	        return new Database(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.Host = source["Host"];
	        this.Port = source["Port"];
	        this.Name = source["Name"];
	        this.User = source["User"];
	        this.Password = source["Password"];
	        this.PasswordEnv = source["PasswordEnv"];
	        this.SSLMode = source["SSLMode"];
	    }
	}
	export class ParamGroups {
	    Instance: string;
	    Cluster: string;
	
	    static createFrom(source: any = {}) {
	        return new ParamGroups(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.Instance = source["Instance"];
	        this.Cluster = source["Cluster"];
	    }
	}
	export class Target {
	    DBInstanceIdentifier: string;
	    DBClusterIdentifier: string;
	
	    static createFrom(source: any = {}) {
	        return new Target(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.DBInstanceIdentifier = source["DBInstanceIdentifier"];
	        this.DBClusterIdentifier = source["DBClusterIdentifier"];
	    }
	}
	export class Upgrade {
	    SourceVersion: string;
	    TargetVersion: string;
	    Topology: string;
	    BlueGreenName: string;
	    DeleteAfterSwitch: boolean;
	
	    static createFrom(source: any = {}) {
	        return new Upgrade(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.SourceVersion = source["SourceVersion"];
	        this.TargetVersion = source["TargetVersion"];
	        this.Topology = source["Topology"];
	        this.BlueGreenName = source["BlueGreenName"];
	        this.DeleteAfterSwitch = source["DeleteAfterSwitch"];
	    }
	}
	export class Config {
	    AWS: AWS;
	    Upgrade: Upgrade;
	    Target: Target;
	    ParameterGroups: ParamGroups;
	    Database: Database;
	    Extensions: Extension[];
	    Smoke: Smoke;
	    Options: Options;
	
	    static createFrom(source: any = {}) {
	        return new Config(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.AWS = this.convertValues(source["AWS"], AWS);
	        this.Upgrade = this.convertValues(source["Upgrade"], Upgrade);
	        this.Target = this.convertValues(source["Target"], Target);
	        this.ParameterGroups = this.convertValues(source["ParameterGroups"], ParamGroups);
	        this.Database = this.convertValues(source["Database"], Database);
	        this.Extensions = this.convertValues(source["Extensions"], Extension);
	        this.Smoke = this.convertValues(source["Smoke"], Smoke);
	        this.Options = this.convertValues(source["Options"], Options);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	
	
	
	
	
	

}

export namespace preconditions {
	
	export class Check {
	    name: string;
	    passed: boolean;
	    fatal: boolean;
	    detail: string;
	
	    static createFrom(source: any = {}) {
	        return new Check(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.name = source["name"];
	        this.passed = source["passed"];
	        this.fatal = source["fatal"];
	        this.detail = source["detail"];
	    }
	}
	export class Result {
	    checks: Check[];
	
	    static createFrom(source: any = {}) {
	        return new Result(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.checks = this.convertValues(source["checks"], Check);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}

}

export namespace smoketest {
	
	export class Comparison {
	    label: string;
	    blue: number;
	    green: number;
	    match: boolean;
	    error?: string;
	
	    static createFrom(source: any = {}) {
	        return new Comparison(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.label = source["label"];
	        this.blue = source["blue"];
	        this.green = source["green"];
	        this.match = source["match"];
	        this.error = source["error"];
	    }
	}
	export class Result {
	    comparisons: Comparison[];
	
	    static createFrom(source: any = {}) {
	        return new Result(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.comparisons = this.convertValues(source["comparisons"], Comparison);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}

}

export namespace upgrade {
	
	export class Report {
	    topology: string;
	    deploymentId: string;
	    preconditions: preconditions.Result;
	    smoke: smoketest.Result;
	    switchedOver: boolean;
	    logPath: string;
	
	    static createFrom(source: any = {}) {
	        return new Report(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.topology = source["topology"];
	        this.deploymentId = source["deploymentId"];
	        this.preconditions = this.convertValues(source["preconditions"], preconditions.Result);
	        this.smoke = this.convertValues(source["smoke"], smoketest.Result);
	        this.switchedOver = source["switchedOver"];
	        this.logPath = source["logPath"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class Step {
	    number: number;
	    title: string;
	    detail: string;
	    mutates: boolean;
	
	    static createFrom(source: any = {}) {
	        return new Step(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.number = source["number"];
	        this.title = source["title"];
	        this.detail = source["detail"];
	        this.mutates = source["mutates"];
	    }
	}

}


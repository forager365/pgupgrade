<script lang="ts">
  import { onMount } from "svelte";
  import {
    ExampleConfig,
    ValidateConfig,
    DryRun,
    RunUpgrade,
  } from "../wailsjs/go/main/App";
  import { EventsOn } from "../wailsjs/runtime/runtime";

  let configText = "";
  let busy = false;
  let banner: { kind: "ok" | "err" | "info"; text: string } | null = null;

  type Step = { number: number; title: string; detail: string; mutates: boolean };
  type ProgressEvent = { phase: string; status: string; message: string };
  type LogEntry = { time: string; level: string; phase: string; message: string };

  let steps: Step[] = [];
  let progress: ProgressEvent[] = [];
  let logs: LogEntry[] = [];
  let report: any = null;
  let summary: any = null;
  let tab: "plan" | "progress" | "log" | "report" = "progress";

  onMount(async () => {
    configText = await ExampleConfig();
    EventsOn("progress", (e: ProgressEvent) => {
      progress = [...progress, e];
    });
    EventsOn("log", (e: LogEntry) => {
      logs = [...logs, e];
    });
  });

  function reset() {
    progress = [];
    logs = [];
    report = null;
    banner = null;
  }

  async function onValidate() {
    reset();
    busy = true;
    try {
      summary = await ValidateConfig(configText);
      banner = { kind: "ok", text: "Configuration is valid." };
      tab = "report";
    } catch (e: any) {
      summary = null;
      banner = { kind: "err", text: String(e) };
    } finally {
      busy = false;
    }
  }

  async function onDryRun() {
    reset();
    busy = true;
    tab = "plan";
    try {
      steps = await DryRun(configText);
      banner = { kind: "info", text: `Dry run complete: ${steps.length} steps planned (no changes made).` };
    } catch (e: any) {
      banner = { kind: "err", text: String(e) };
    } finally {
      busy = false;
    }
  }

  async function onRun() {
    if (!confirm("This will create a blue/green deployment and switch over if smoke tests pass. Continue?")) {
      return;
    }
    reset();
    busy = true;
    tab = "progress";
    try {
      report = await RunUpgrade(configText);
      banner = report?.switchedOver
        ? { kind: "ok", text: "Upgrade complete — switched over to green." }
        : { kind: "info", text: "Run finished without switchover (see report)." };
      tab = "report";
    } catch (e: any) {
      banner = { kind: "err", text: String(e) };
      tab = "report";
    } finally {
      busy = false;
    }
  }

  const statusColor = (s: string) =>
    s === "ok" ? "#3fb950" : s === "error" ? "#f85149" : s === "warn" ? "#d29922" : s === "skip" ? "#8b949e" : "#58a6ff";
</script>

<main>
  <header>
    <h1>Blue/Green Postgres Upgrader</h1>
    <span class="sub">RDS &amp; Aurora major-version upgrades via blue/green deployments</span>
  </header>

  {#if banner}
    <div class="banner {banner.kind}">{banner.text}</div>
  {/if}

  <div class="layout">
    <section class="left">
      <div class="panel-head">
        <h2>Configuration (TOML)</h2>
      </div>
      <textarea bind:value={configText} spellcheck="false" class="config"></textarea>
      <div class="actions">
        <button on:click={onValidate} disabled={busy}>Validate</button>
        <button on:click={onDryRun} disabled={busy}>Dry run</button>
        <button class="danger" on:click={onRun} disabled={busy}>Run upgrade</button>
        {#if busy}<span class="spinner">working…</span>{/if}
      </div>
    </section>

    <section class="right">
      <nav class="tabs">
        <button class:active={tab === "progress"} on:click={() => (tab = "progress")}>Progress ({progress.length})</button>
        <button class:active={tab === "plan"} on:click={() => (tab = "plan")}>Plan ({steps.length})</button>
        <button class:active={tab === "log"} on:click={() => (tab = "log")}>Activity log ({logs.length})</button>
        <button class:active={tab === "report"} on:click={() => (tab = "report")}>Report</button>
      </nav>

      <div class="content">
        {#if tab === "progress"}
          {#if progress.length === 0}
            <p class="empty">No activity yet. Run a dry run or upgrade.</p>
          {/if}
          {#each progress as p}
            <div class="event">
              <span class="dot" style="background:{statusColor(p.status)}"></span>
              <span class="phase">{p.phase}</span>
              <span class="msg">{p.message}</span>
            </div>
          {/each}
        {:else if tab === "plan"}
          {#if steps.length === 0}
            <p class="empty">Run a dry run to see the plan.</p>
          {/if}
          <ol class="plan">
            {#each steps as s}
              <li>
                <span class="title">{s.title}{#if s.mutates}<span class="mut">mutates</span>{/if}</span>
                <span class="detail">{s.detail}</span>
              </li>
            {/each}
          </ol>
        {:else if tab === "log"}
          {#if logs.length === 0}
            <p class="empty">No log entries yet.</p>
          {/if}
          <pre class="log">{#each logs as l}{l.time}  [{l.level}]{l.phase ? ` (${l.phase})` : ""}  {l.message}
{/each}</pre>
        {:else if tab === "report"}
          {#if summary}
            <h3>Validated configuration</h3>
            <pre class="json">{JSON.stringify(summary, null, 2)}</pre>
          {/if}
          {#if report}
            <h3>Run report</h3>
            <div class="kv"><b>Topology:</b> {report.topology || "—"}</div>
            <div class="kv"><b>Deployment ID:</b> {report.deploymentId || "—"}</div>
            <div class="kv"><b>Switched over:</b> {report.switchedOver ? "yes" : "no"}</div>
            <div class="kv"><b>Log file:</b> {report.logPath || "—"}</div>

            {#if report.preconditions?.checks}
              <h4>Preconditions</h4>
              <table>
                <tr><th>Check</th><th>Result</th><th>Detail</th></tr>
                {#each report.preconditions.checks as c}
                  <tr>
                    <td>{c.name}</td>
                    <td style="color:{c.passed ? '#3fb950' : c.fatal ? '#f85149' : '#d29922'}">
                      {c.passed ? "pass" : c.fatal ? "FAIL" : "warn"}
                    </td>
                    <td>{c.detail}</td>
                  </tr>
                {/each}
              </table>
            {/if}

            {#if report.smoke?.comparisons}
              <h4>Smoke tests</h4>
              <table>
                <tr><th>Metric</th><th>Blue</th><th>Green</th><th>Match</th></tr>
                {#each report.smoke.comparisons as c}
                  <tr>
                    <td>{c.label}</td>
                    <td>{c.error ? "—" : c.blue}</td>
                    <td>{c.error ? "—" : c.green}</td>
                    <td style="color:{c.match && !c.error ? '#3fb950' : '#f85149'}">
                      {c.error ? c.error : c.match ? "yes" : "NO"}
                    </td>
                  </tr>
                {/each}
              </table>
            {/if}
          {/if}
          {#if !summary && !report}
            <p class="empty">No report yet.</p>
          {/if}
        {/if}
      </div>
    </section>
  </div>
</main>

<style>
  :global(body) { margin: 0; }
  main {
    font-family: "Nunito", system-ui, sans-serif;
    color: #c9d1d9;
    background: #0d1117;
    height: 100vh;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    padding: 16px;
  }
  header { display: flex; align-items: baseline; gap: 12px; margin-bottom: 10px; }
  h1 { font-size: 20px; margin: 0; color: #58a6ff; }
  .sub { color: #8b949e; font-size: 13px; }
  .banner { padding: 8px 12px; border-radius: 6px; margin-bottom: 10px; font-size: 14px; }
  .banner.ok { background: #12351f; color: #3fb950; }
  .banner.err { background: #3a1416; color: #f85149; white-space: pre-wrap; }
  .banner.info { background: #11293f; color: #58a6ff; }
  .layout { display: flex; gap: 16px; flex: 1; min-height: 0; }
  .left, .right { display: flex; flex-direction: column; min-height: 0; }
  .left { flex: 0 0 46%; }
  .right { flex: 1; }
  .panel-head h2, h2 { font-size: 14px; margin: 0 0 6px; color: #8b949e; text-transform: uppercase; letter-spacing: .04em; }
  textarea.config {
    flex: 1; width: 100%; box-sizing: border-box; resize: none;
    background: #010409; color: #c9d1d9; border: 1px solid #30363d; border-radius: 6px;
    font-family: ui-monospace, "SF Mono", Menlo, monospace; font-size: 12.5px; padding: 10px; line-height: 1.5;
  }
  .actions { display: flex; gap: 8px; align-items: center; margin-top: 10px; }
  button {
    background: #21262d; color: #c9d1d9; border: 1px solid #30363d; border-radius: 6px;
    padding: 7px 14px; font-size: 13px; cursor: pointer;
  }
  button:hover:not(:disabled) { background: #30363d; }
  button:disabled { opacity: .5; cursor: default; }
  button.danger { background: #b62324; border-color: #f85149; color: #fff; }
  .spinner { color: #d29922; font-size: 13px; }
  .tabs { display: flex; gap: 4px; margin-bottom: 8px; }
  .tabs button { border-radius: 6px 6px 0 0; }
  .tabs button.active { background: #161b22; border-bottom-color: #161b22; color: #58a6ff; }
  .content {
    flex: 1; overflow: auto; background: #161b22; border: 1px solid #30363d;
    border-radius: 0 6px 6px 6px; padding: 12px; min-height: 0;
  }
  .empty { color: #8b949e; font-style: italic; }
  .event { display: flex; gap: 8px; align-items: baseline; padding: 3px 0; font-size: 13px; border-bottom: 1px solid #21262d; }
  .dot { width: 8px; height: 8px; border-radius: 50%; flex: 0 0 auto; }
  .phase { color: #8b949e; min-width: 110px; font-family: ui-monospace, monospace; font-size: 12px; }
  .msg { flex: 1; }
  ol.plan { margin: 0; padding-left: 22px; }
  ol.plan li { padding: 5px 0; border-bottom: 1px solid #21262d; }
  ol.plan .title { display: block; font-weight: 600; }
  ol.plan .detail { color: #8b949e; font-size: 12.5px; font-family: ui-monospace, monospace; }
  .mut { background: #5a1e02; color: #ffa657; font-size: 10px; padding: 1px 5px; border-radius: 4px; margin-left: 8px; vertical-align: middle; }
  pre.log, pre.json { white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 12px; margin: 0; color: #c9d1d9; }
  .kv { padding: 2px 0; font-size: 13px; }
  h3 { color: #58a6ff; font-size: 14px; margin: 8px 0 4px; }
  h4 { color: #8b949e; font-size: 13px; margin: 14px 0 4px; }
  table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  th, td { text-align: left; padding: 4px 8px; border-bottom: 1px solid #21262d; vertical-align: top; }
  th { color: #8b949e; font-weight: 600; }
</style>

// Package awsx wraps AWS SDK v2 config loading with an SSO-profile-aware
// flow: if the profile already has a valid cached SSO session, use it;
// otherwise shell out to `aws sso login --profile <name>` and stream its
// output to the run log.
package awsx

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"os/exec"

	"github.com/anandbabu/gopgvanilla/internal/runlog"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

// LoadProfile returns an AWS config for the given profile + region.
// If credentials are missing/expired it triggers `aws sso login`.
// An empty profile falls back to the default credential chain.
func LoadProfile(ctx context.Context, log *runlog.Bus, profile, region string) (aws.Config, error) {
	cfg, err := loadConfig(ctx, profile, region)
	if err != nil {
		return aws.Config{}, err
	}
	if err := verifyCallerIdentity(ctx, cfg, log); err == nil {
		return cfg, nil
	} else if profile == "" {
		return aws.Config{}, fmt.Errorf("default credential chain invalid: %w", err)
	} else {
		log.Warnf("active session check failed (%v); running `aws sso login --profile %s`", err, profile)
	}
	if err := ssoLogin(ctx, log, profile); err != nil {
		return aws.Config{}, fmt.Errorf("aws sso login: %w", err)
	}
	cfg, err = loadConfig(ctx, profile, region)
	if err != nil {
		return aws.Config{}, err
	}
	if err := verifyCallerIdentity(ctx, cfg, log); err != nil {
		return aws.Config{}, fmt.Errorf("session still invalid after sso login: %w", err)
	}
	return cfg, nil
}

func loadConfig(ctx context.Context, profile, region string) (aws.Config, error) {
	opts := []func(*config.LoadOptions) error{}
	if profile != "" {
		opts = append(opts, config.WithSharedConfigProfile(profile))
	}
	if region != "" {
		opts = append(opts, config.WithRegion(region))
	}
	return config.LoadDefaultConfig(ctx, opts...)
}

func verifyCallerIdentity(ctx context.Context, cfg aws.Config, log *runlog.Bus) error {
	out, err := sts.NewFromConfig(cfg).GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
	if err != nil {
		return err
	}
	log.Infof("using identity %s (account %s)", aws.ToString(out.Arn), aws.ToString(out.Account))
	return nil
}

func ssoLogin(ctx context.Context, log *runlog.Bus, profile string) error {
	cmd := exec.CommandContext(ctx, "aws", "sso", "login", "--profile", profile)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	cmd.Stderr = cmd.Stdout
	if err := cmd.Start(); err != nil {
		return err
	}
	go pump(stdout, log)
	return cmd.Wait()
}

func pump(r io.Reader, log *runlog.Bus) {
	s := bufio.NewScanner(r)
	s.Buffer(make([]byte, 64*1024), 1024*1024)
	for s.Scan() {
		log.Infof("sso-login: %s", s.Text())
	}
}

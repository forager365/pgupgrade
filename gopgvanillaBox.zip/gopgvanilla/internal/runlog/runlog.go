// Package runlog is an in-memory pub/sub for run events so that orchestrator
// code can emit structured events without knowing about HTTP, and the SSE
// handler can fan them out to any connected browsers. Every event is also
// mirrored to a per-run JSONL audit file when a sink is attached.
package runlog

import (
	"encoding/json"
	"fmt"
	"io"
	"sync"
	"time"
)

// Kind discriminates event payloads on the wire.
const (
	KindLog  = "log"  // a log line (level + message)
	KindStep = "step" // a step status transition (step + status)
	KindRun  = "run"  // run lifecycle (status: started|succeeded|failed|aborted)
)

type Event struct {
	Time    time.Time `json:"time"`
	Kind    string    `json:"kind"`
	Level   string    `json:"level,omitempty"`
	Message string    `json:"message,omitempty"`
	Step    string    `json:"step,omitempty"`
	Status  string    `json:"status,omitempty"`
}

type Bus struct {
	mu      sync.Mutex
	history []Event
	subs    map[chan Event]struct{}
	sink    io.WriteCloser
}

func NewBus() *Bus {
	return &Bus{subs: map[chan Event]struct{}{}}
}

// Subscribe returns a live channel, a snapshot of history, and an unsubscribe func.
func (b *Bus) Subscribe() (<-chan Event, []Event, func()) {
	ch := make(chan Event, 256)
	b.mu.Lock()
	b.subs[ch] = struct{}{}
	hist := append([]Event(nil), b.history...)
	b.mu.Unlock()
	return ch, hist, func() {
		b.mu.Lock()
		delete(b.subs, ch)
		b.mu.Unlock()
		close(ch)
	}
}

// SetSink attaches a writer (e.g. a per-run audit log file). Any previous
// sink is closed. Every subsequent event is appended to it as one JSON line.
func (b *Bus) SetSink(w io.WriteCloser) {
	b.mu.Lock()
	old := b.sink
	b.sink = w
	b.mu.Unlock()
	if old != nil {
		old.Close()
	}
}

func (b *Bus) emit(ev Event) {
	ev.Time = time.Now().UTC()
	b.mu.Lock()
	b.history = append(b.history, ev)
	if len(b.history) > 5000 {
		b.history = b.history[len(b.history)-5000:]
	}
	if b.sink != nil {
		if line, err := json.Marshal(ev); err == nil {
			b.sink.Write(append(line, '\n'))
		}
	}
	subs := make([]chan Event, 0, len(b.subs))
	for ch := range b.subs {
		subs = append(subs, ch)
	}
	b.mu.Unlock()
	for _, ch := range subs {
		select {
		case ch <- ev:
		default:
		}
	}
}

func (b *Bus) Infof(format string, args ...any) {
	b.emit(Event{Kind: KindLog, Level: "info", Message: fmt.Sprintf(format, args...)})
}

func (b *Bus) Warnf(format string, args ...any) {
	b.emit(Event{Kind: KindLog, Level: "warn", Message: fmt.Sprintf(format, args...)})
}

func (b *Bus) Errorf(format string, args ...any) {
	b.emit(Event{Kind: KindLog, Level: "error", Message: fmt.Sprintf(format, args...)})
}

// Step publishes a step status transition (and mirrors it into the audit log).
func (b *Bus) Step(step, status string) {
	b.emit(Event{Kind: KindStep, Step: step, Status: status})
}

// Run publishes a run lifecycle transition.
func (b *Bus) Run(status, message string) {
	b.emit(Event{Kind: KindRun, Status: status, Message: message})
}

func (b *Bus) Reset() {
	b.mu.Lock()
	b.history = nil
	b.mu.Unlock()
}

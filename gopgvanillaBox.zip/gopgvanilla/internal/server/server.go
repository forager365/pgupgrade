// Package server exposes the web UI and run-control API:
//
//	GET  /        embedded single-page UI
//	POST /run     start a run (JSON upgrade.Request)
//	POST /approve resolve the pending step approval {"approve": bool}
//	POST /cancel  cancel the in-flight run
//	GET  /state   current run + step states (for page reloads)
//	GET  /logs    SSE stream of runlog events (logs, step + run transitions)
package server

import (
	"context"
	"embed"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/anandbabu/gopgvanilla/internal/runlog"
	"github.com/anandbabu/gopgvanilla/internal/upgrade"
)

//go:embed web
var webFS embed.FS

type Server struct {
	bus        *runlog.Bus
	logDir     string
	baseConfig upgrade.Request

	mu      sync.Mutex
	running bool
	runner  *upgrade.Runner
	cancel  context.CancelFunc
	lastRun string // started|succeeded|failed|aborted|"" (idle)
	mode    upgrade.Mode
}

// New creates a server; logDir receives one JSONL audit file per run.
func New(bus *runlog.Bus, logDir string, baseConfig upgrade.Request) *Server {
	return &Server{bus: bus, logDir: logDir, baseConfig: baseConfig}
}

func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/", s.handleIndex)
	mux.HandleFunc("/run", s.handleRun)
	mux.HandleFunc("/approve", s.handleApprove)
	mux.HandleFunc("/cancel", s.handleCancel)
	mux.HandleFunc("/state", s.handleState)
	mux.HandleFunc("/logs", s.handleLogs)
	return mux
}

func (s *Server) handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	b, err := webFS.ReadFile("web/index.html")
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write(b)
}

func (s *Server) handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	var input struct {
		Interactive bool `json:"interactive"`
	}
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		http.Error(w, "malformed request body: "+err.Error(), 400)
		return
	}
	
	req := s.baseConfig
	req.Interactive = input.Interactive

	req.ApplyDefaults()
	if err := req.Validate(); err != nil {
		http.Error(w, err.Error(), 422)
		return
	}

	s.mu.Lock()
	if s.running {
		s.mu.Unlock()
		http.Error(w, "a run is already in progress", 409)
		return
	}
	s.bus.Reset()
	if err := s.attachAuditLog(req); err != nil {
		s.mu.Unlock()
		http.Error(w, "cannot open audit log: "+err.Error(), 500)
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	runner := upgrade.NewRunner(s.bus, req)
	s.running = true
	s.runner = runner
	s.cancel = cancel
	s.lastRun = "started"
	s.mode = req.Mode
	s.mu.Unlock()

	go func() {
		defer func() {
			s.mu.Lock()
			s.running = false
			s.cancel = nil
			s.mu.Unlock()
		}()
		s.bus.Run("started", fmt.Sprintf("mode=%s target_version=%s host=%s identifier=%s interactive=%v",
			req.Mode, req.TargetVersion, req.Host, req.Identifier, req.Interactive))
		err := runner.Run(ctx)
		switch {
		case err == nil:
			s.setLastRun("succeeded")
			s.bus.Run("succeeded", "run finished successfully")
		case err == upgrade.ErrAborted || ctx.Err() != nil:
			s.setLastRun("aborted")
			s.bus.Run("aborted", fmt.Sprintf("run aborted: %v", err))
		default:
			s.setLastRun("failed")
			s.bus.Errorf("run failed: %v", err)
			s.bus.Run("failed", fmt.Sprintf("run failed: %v", err))
		}
	}()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "started"})
}

// attachAuditLog opens logs/<mode>-<timestamp>.jsonl and wires it to the bus.
// Caller holds s.mu.
func (s *Server) attachAuditLog(req upgrade.Request) error {
	if err := os.MkdirAll(s.logDir, 0o755); err != nil {
		return err
	}
	name := fmt.Sprintf("%s-%s.jsonl", req.Mode, time.Now().UTC().Format("20060102T150405Z"))
	f, err := os.OpenFile(filepath.Join(s.logDir, name), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return err
	}
	s.bus.SetSink(f)
	s.bus.Infof("audit log: %s", filepath.Join(s.logDir, name))
	return nil
}

func (s *Server) setLastRun(v string) {
	s.mu.Lock()
	s.lastRun = v
	s.mu.Unlock()
}

func (s *Server) handleApprove(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	var body struct {
		Approve bool `json:"approve"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "malformed request body: "+err.Error(), 400)
		return
	}
	s.mu.Lock()
	runner := s.runner
	running := s.running
	s.mu.Unlock()
	if !running || runner == nil {
		http.Error(w, "no run in progress", 409)
		return
	}
	if !runner.Decide(body.Approve) {
		http.Error(w, "no step is awaiting approval", 409)
		return
	}
	w.WriteHeader(204)
}

func (s *Server) handleCancel(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	s.mu.Lock()
	if s.cancel != nil {
		s.cancel()
		s.bus.Warnf("cancel requested by operator")
	}
	s.mu.Unlock()
	w.WriteHeader(204)
}

func (s *Server) handleState(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	runner := s.runner
	state := map[string]any{
		"running":  s.running,
		"last_run": s.lastRun,
		"mode":     s.mode,
	}
	s.mu.Unlock()
	if runner != nil {
		steps, awaiting := runner.Steps()
		state["steps"] = steps
		state["awaiting"] = awaiting
	} else {
		state["steps"] = []upgrade.StepState{}
		state["awaiting"] = ""
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(state)
}

func (s *Server) handleLogs(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", 500)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")

	ch, hist, unsubscribe := s.bus.Subscribe()
	defer unsubscribe()

	write := func(ev runlog.Event) bool {
		payload, _ := json.Marshal(ev)
		if _, err := fmt.Fprintf(w, "data: %s\n\n", payload); err != nil {
			return false
		}
		flusher.Flush()
		return true
	}

	for _, ev := range hist {
		if !write(ev) {
			return
		}
	}
	ka := time.NewTicker(15 * time.Second)
	defer ka.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case ev, ok := <-ch:
			if !ok {
				return
			}
			if !write(ev) {
				return
			}
		case <-ka.C:
			if _, err := fmt.Fprintf(w, ": keepalive\n\n"); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

package upgrade

// Extension categories describe the operator action required for a Postgres
// major-version upgrade:
//
//	CategoryDropRecreate : pg_upgrade refuses to carry these across; must DROP
//	                       before and CREATE after (or reinstall from backup).
//	                       Highest risk — the run refuses to proceed.
//	CategoryAlterUpdate  : carried across by pg_upgrade but require
//	                       ALTER EXTENSION ... UPDATE afterwards to relink to
//	                       the new shared library.
//	CategoryReview       : may need manual review; behavior depends on version.
//	CategoryUnknown      : not in the table; left alone.
const (
	CategoryDropRecreate = "drop_recreate"
	CategoryAlterUpdate  = "alter_update"
	CategoryReview       = "review"
	CategoryUnknown      = "unknown"
)

var extensionClass = map[string]string{
	// Spatial / GIS
	"postgis":                      CategoryAlterUpdate,
	"postgis_topology":             CategoryAlterUpdate,
	"postgis_raster":               CategoryAlterUpdate,
	"postgis_tiger_geocoder":       CategoryAlterUpdate,
	"address_standardizer":         CategoryAlterUpdate,
	"address_standardizer_data_us": CategoryAlterUpdate,
	"pgrouting":                    CategoryAlterUpdate,
	// Reorg / maintenance
	"pg_repack":  CategoryDropRecreate,
	"pg_partman": CategoryAlterUpdate,
	// Stats / instrumentation
	"pg_stat_statements": CategoryAlterUpdate,
	"pg_hint_plan":       CategoryAlterUpdate,
	"auto_explain":       CategoryAlterUpdate,
	// Common contribs
	"hstore":     CategoryAlterUpdate,
	"citext":     CategoryAlterUpdate,
	"pgcrypto":   CategoryAlterUpdate,
	"uuid-ossp":  CategoryAlterUpdate,
	"ltree":      CategoryAlterUpdate,
	"tablefunc":  CategoryAlterUpdate,
	"btree_gin":  CategoryAlterUpdate,
	"btree_gist": CategoryAlterUpdate,
	"intarray":   CategoryAlterUpdate,
	"unaccent":   CategoryAlterUpdate,
	// FDW / external
	"postgres_fdw": CategoryAlterUpdate,
	"dblink":       CategoryAlterUpdate,
	"tds_fdw":      CategoryReview,
	// AWS-specific
	"aws_s3":      CategoryReview,
	"aws_commons": CategoryReview,
	"aws_lambda":  CategoryReview,
	// Logical decoding / replication helpers
	"pglogical": CategoryDropRecreate,
	"wal2json":  CategoryReview,
}

type ExtensionFinding struct {
	Name     string `json:"name"`
	Version  string `json:"version"`
	Schema   string `json:"schema"`
	Category string `json:"category"`
}

type DatabaseExtensions struct {
	DBName     string             `json:"dbname"`
	Extensions []ExtensionFinding `json:"extensions"`
}

func classifyExtension(name string) string {
	if c, ok := extensionClass[name]; ok {
		return c
	}
	return CategoryUnknown
}

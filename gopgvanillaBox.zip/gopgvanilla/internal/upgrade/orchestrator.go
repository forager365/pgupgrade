package upgrade

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/anandbabu/gopgvanilla/internal/awsx"
	"github.com/anandbabu/gopgvanilla/internal/runlog"
)

// ErrAborted is returned when the operator declines a step approval.
var ErrAborted = errors.New("run aborted by operator")

// StepState is the operator-facing view of one step.
type StepState struct {
	ID     string `json:"id"`
	Title  string `json:"title"`
	Status string `json:"status"`
}

// Runner executes one upgrade run as an ordered sequence of steps. In
// interactive mode it pauses before each step and waits for operator approval
// via Approve/Abort. All transitions are published to the bus (and therefore
// to the SSE stream and the per-run audit log).
type Runner struct {
	bus *runlog.Bus
	req Request

	mu       sync.Mutex
	steps    []StepState
	awaiting string // step ID awaiting approval, "" if none
	decision chan bool

	// shared run state populated by steps
	rds    *rdsAPI
	target TargetRef
}

func NewRunner(bus *runlog.Bus, req Request) *Runner {
	ids := StepsForMode(req.Mode)
	steps := make([]StepState, 0, len(ids))
	for _, id := range ids {
		steps = append(steps, StepState{ID: id, Title: StepTitles[id], Status: StatusPending})
	}
	return &Runner{bus: bus, req: req, steps: steps, decision: make(chan bool, 1)}
}

// Steps returns a snapshot of step states plus the step awaiting approval.
func (r *Runner) Steps() ([]StepState, string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := append([]StepState(nil), r.steps...)
	return out, r.awaiting
}

// Decide resolves a pending approval gate. approve=false aborts the run.
// Returns false if no step is awaiting approval.
func (r *Runner) Decide(approve bool) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.awaiting == "" {
		return false
	}
	select {
	case r.decision <- approve:
		return true
	default:
		return false
	}
}

func (r *Runner) setStatus(id, status string) {
	r.mu.Lock()
	for i := range r.steps {
		if r.steps[i].ID == id {
			r.steps[i].Status = status
		}
	}
	if status == StatusAwaitingApproval {
		r.awaiting = id
	} else if r.awaiting == id {
		r.awaiting = ""
	}
	r.mu.Unlock()
	r.bus.Step(id, status)
}

// gate blocks until the operator approves the step (interactive mode only).
func (r *Runner) gate(ctx context.Context, id string) error {
	if !r.req.Interactive {
		return nil
	}
	r.setStatus(id, StatusAwaitingApproval)
	r.bus.Infof("awaiting operator approval for step %s (%s)", id, StepTitles[id])
	select {
	case <-ctx.Done():
		return ctx.Err()
	case approved := <-r.decision:
		if !approved {
			r.bus.Warnf("operator declined step %s", id)
			return ErrAborted
		}
		r.bus.Infof("operator approved step %s", id)
		return nil
	}
}

type stepFunc func(ctx context.Context) error

// Run executes the workflow for the request's mode.
func (r *Runner) Run(ctx context.Context) error {
	impl := map[string]stepFunc{
		StepDiscover:     r.stepDiscover,
		StepValidatePath: r.stepValidatePath,
		StepInspectExt:   r.stepInspectExtensions,
		StepPlan:         r.stepPlanReview,
		StepSnapshot:     r.stepSnapshot,
		StepParamGroups:  r.stepParamGroups,
		StepUpgrade:      r.stepUpgrade,
		StepPostValidate: r.stepPostValidate,
		StepUpdateExt:    r.stepUpdateExtensions,
	}

	r.bus.Infof("run mode: %s | target version: %s | interactive: %v",
		r.req.Mode, r.req.TargetVersion, r.req.Interactive)

	for _, st := range append([]StepState(nil), r.steps...) {
		if err := r.gate(ctx, st.ID); err != nil {
			r.markRemaining(st.ID, StatusAborted)
			return err
		}
		r.setStatus(st.ID, StatusRunning)
		r.bus.Infof("=== step %s: %s ===", st.ID, StepTitles[st.ID])
		start := time.Now()
		if err := impl[st.ID](ctx); err != nil {
			r.setStatus(st.ID, StatusFailed)
			r.markRemaining(st.ID, StatusSkipped)
			return fmt.Errorf("step %s: %w", st.ID, err)
		}
		r.bus.Infof("step %s completed in %s", st.ID, time.Since(start).Round(time.Second))
		r.setStatus(st.ID, StatusCompleted)
	}
	return nil
}

// markRemaining sets every step after `afterID` (and `afterID` itself when
// aborting at its gate) to the given terminal status.
func (r *Runner) markRemaining(afterID, status string) {
	r.mu.Lock()
	seen := false
	var ids []string
	for i := range r.steps {
		if r.steps[i].ID == afterID {
			seen = true
			if r.steps[i].Status == StatusAwaitingApproval || r.steps[i].Status == StatusPending {
				r.steps[i].Status = status
				ids = append(ids, r.steps[i].ID)
			}
			continue
		}
		if seen && r.steps[i].Status == StatusPending {
			r.steps[i].Status = status
			ids = append(ids, r.steps[i].ID)
		}
	}
	r.mu.Unlock()
	for _, id := range ids {
		r.bus.Step(id, status)
	}
}

// ---------- steps ----------

func (r *Runner) stepDiscover(ctx context.Context) error {
	r.bus.Infof("loading AWS config (profile=%q region=%s)", r.req.SSOProfile, r.req.Region)
	cfg, err := awsx.LoadProfile(ctx, r.bus, r.req.SSOProfile, r.req.Region)
	if err != nil {
		return fmt.Errorf("aws config: %w", err)
	}
	r.rds = newRDS(cfg, r.bus)

	target, err := r.rds.discoverTarget(ctx, r.req.Host, r.req.Identifier)
	if err != nil {
		return err
	}
	r.target = target

	r.bus.Infof("topology: %s", target.Topology)
	r.bus.Infof("engine: %s %s", target.Engine, target.EngineVersion)
	if target.ClusterID != "" {
		r.bus.Infof("cluster: %s (members: %v)", target.ClusterID, target.MemberInstanceIDs)
		r.bus.Infof("cluster parameter group: %s", target.ClusterParamGroup)
	} else {
		r.bus.Infof("instance: %s", target.InstanceID)
		if len(target.MemberInstanceIDs) > 0 {
			r.bus.Infof("read replicas: %v", target.MemberInstanceIDs)
		}
	}
	for inst, pg := range target.InstanceParamGroups {
		r.bus.Infof("instance parameter group (%s): %s", inst, pg)
	}

	if !strings.Contains(target.Engine, "postgres") {
		return fmt.Errorf("target engine %q is not a Postgres engine", target.Engine)
	}
	switch target.Topology {
	case TopoAuroraServerlessV1:
		return fmt.Errorf("aurora serverless v1 does not support in-place major version upgrades via this tool")
	}
	return nil
}

func (r *Runner) stepValidatePath(ctx context.Context) error {
	cur, tgt := r.target.EngineVersion, r.req.TargetVersion
	if majorOf(tgt) <= majorOf(cur) {
		return fmt.Errorf("target version %s is not a major upgrade from %s", tgt, cur)
	}
	valid, err := r.rds.validUpgradeTarget(ctx, r.target.Engine, cur, tgt)
	if err != nil {
		return err
	}
	r.bus.Infof("%s -> %s valid major upgrade: %v", cur, tgt, valid)
	if !valid {
		return fmt.Errorf("target version %s is not a valid major upgrade from %s (per RDS ValidUpgradeTarget)", tgt, cur)
	}
	return nil
}

func (r *Runner) stepInspectExtensions(ctx context.Context) error {
	dbs, err := pgListDatabases(ctx, r.req)
	if err != nil {
		return fmt.Errorf("cannot connect to Postgres: %w", err)
	}
	r.bus.Infof("databases (%d): %s", len(dbs), strings.Join(dbs, ", "))

	findings, err := pgListExtensions(ctx, r.busWarnf, r.req, dbs)
	if err != nil {
		return err
	}

	byCategory := map[string][]string{}
	for _, d := range findings {
		for _, e := range d.Extensions {
			r.bus.Infof("  [%s] %s v%s schema=%s -> %s", d.DBName, e.Name, e.Version, e.Schema, e.Category)
			byCategory[e.Category] = append(byCategory[e.Category], d.DBName+"."+e.Name)
		}
	}

	summary := func(cat, label string) {
		items := byCategory[cat]
		sort.Strings(items)
		r.bus.Infof("%s: %d %v", label, len(items), items)
	}
	summary(CategoryDropRecreate, "DROP/RECREATE required (operator action)")
	summary(CategoryAlterUpdate, "ALTER EXTENSION UPDATE post-upgrade")
	summary(CategoryReview, "manual review")
	summary(CategoryUnknown, "unknown (left alone)")

	if risky := byCategory[CategoryDropRecreate]; len(risky) > 0 {
		if r.req.Mode == ModeUpgrade {
			return fmt.Errorf("refusing to upgrade: drop/recreate extensions present: %v — resolve manually (DROP, upgrade, CREATE) and re-run", risky)
		}
		r.bus.Warnf("DROP/RECREATE extensions present: %v — resolve manually before running upgrade", risky)
	}
	return nil
}

func (r *Runner) stepPlanReview(ctx context.Context) error {
	identifier := r.target.Identifier()
	r.bus.Infof("planned snapshot: %s", snapshotID(r.req.SnapshotPrefix, identifier, r.target.EngineVersion))
	if r.target.ClusterParamGroup != "" {
		r.bus.Infof("planned cluster parameter group: %s",
			paramGroupName(r.target.ClusterID, r.req.TargetVersion, r.req.ClusterPGSfx))
	}
	for inst := range r.target.InstanceParamGroups {
		r.bus.Infof("planned instance parameter group (%s): %s",
			inst, paramGroupName(inst, r.req.TargetVersion, r.req.InstancePGSfx))
	}
	r.bus.Infof("dry-run complete; no mutations were made")
	return nil
}

func (r *Runner) stepSnapshot(ctx context.Context) error {
	snapID := snapshotID(r.req.SnapshotPrefix, r.target.Identifier(), r.target.EngineVersion)
	if err := r.rds.createSnapshot(ctx, r.target, snapID); err != nil {
		return err
	}
	return r.rds.waitSnapshotAvailable(ctx, r.target, snapID,
		time.Duration(r.req.SnapshotTimeoutSeconds)*time.Second)
}

func (r *Runner) stepParamGroups(ctx context.Context) error {
	family, err := r.rds.engineFamily(ctx, r.target.Engine, r.req.TargetVersion)
	if err != nil {
		return err
	}
	r.bus.Infof("target parameter group family: %s", family)

	if r.target.ClusterParamGroup != "" {
		newClusterPG := paramGroupName(r.target.ClusterID, r.req.TargetVersion, r.req.ClusterPGSfx)
		if err := r.rds.copyUserModifiedParams(ctx, r.target.ClusterParamGroup, newClusterPG, family, true); err != nil {
			return err
		}
	}
	for inst, srcPG := range r.target.InstanceParamGroups {
		newPG := paramGroupName(inst, r.req.TargetVersion, r.req.InstancePGSfx)
		if err := r.rds.copyUserModifiedParams(ctx, srcPG, newPG, family, false); err != nil {
			return err
		}
	}
	return nil
}

func (r *Runner) stepUpgrade(ctx context.Context) error {
	timeout := time.Duration(r.req.UpgradeTimeoutSeconds) * time.Second
	major := majorStr(r.req.TargetVersion)

	if r.target.ClusterID != "" {
		// Aurora / Multi-AZ DB cluster: modify the cluster; attach each
		// instance parameter group afterwards.
		newClusterPG := paramGroupName(r.target.ClusterID, r.req.TargetVersion, r.req.ClusterPGSfx)
		if err := r.rds.initiateClusterUpgrade(ctx, r.target.ClusterID, r.req.TargetVersion, newClusterPG); err != nil {
			return err
		}
		if err := r.rds.waitClusterUpgraded(ctx, r.target.ClusterID, major, timeout); err != nil {
			return err
		}
		for inst := range r.target.InstanceParamGroups {
			newPG := paramGroupName(inst, r.req.TargetVersion, r.req.InstancePGSfx)
			if err := r.rds.attachInstanceParamGroup(ctx, inst, newPG); err != nil {
				return err
			}
			if err := r.rds.waitInstanceUpgraded(ctx, inst, "", timeout); err != nil {
				return err
			}
		}
		return nil
	}

	newPG := paramGroupName(r.target.InstanceID, r.req.TargetVersion, r.req.InstancePGSfx)
	if err := r.rds.initiateInstanceUpgrade(ctx, r.target.InstanceID, r.req.TargetVersion, newPG); err != nil {
		return err
	}
	if err := r.rds.waitInstanceUpgraded(ctx, r.target.InstanceID, major, timeout); err != nil {
		return err
	}
	// Read replicas auto-upgrade with the primary; wait for each.
	for _, replica := range r.target.MemberInstanceIDs {
		if err := r.rds.waitInstanceUpgraded(ctx, replica, major, timeout); err != nil {
			return err
		}
	}
	return nil
}

func (r *Runner) stepPostValidate(ctx context.Context) error {
	// Re-discover to pick up the new engine version.
	target, err := r.rds.discoverTarget(ctx, r.req.Host, r.req.Identifier)
	if err != nil {
		return err
	}
	r.target = target

	expected := r.req.TargetVersion
	actual := target.EngineVersion
	r.bus.Infof("engine version reported by RDS: %s (expected %s)", actual, expected)
	if !strings.HasPrefix(actual, majorStr(expected)+".") && actual != expected {
		return fmt.Errorf("engine major version mismatch after upgrade: got %s, expected %s", actual, expected)
	}

	serverV, err := pgServerVersion(ctx, r.req)
	if err != nil {
		return fmt.Errorf("SQL connectivity check failed: %w", err)
	}
	r.bus.Infof("server_version (SQL): %s", serverV)
	if !strings.HasPrefix(serverV, majorStr(expected)+".") && serverV != majorStr(expected) {
		return fmt.Errorf("SQL server_version %q does not match expected major %s", serverV, majorStr(expected))
	}

	dbs, err := pgListDatabases(ctx, r.req)
	if err != nil {
		return err
	}
	r.bus.Infof("databases after upgrade: %d (%s)", len(dbs), strings.Join(dbs, ", "))
	if len(dbs) == 0 {
		return fmt.Errorf("no user databases visible after upgrade")
	}
	return nil
}

func (r *Runner) stepUpdateExtensions(ctx context.Context) error {
	allowed := r.req.AutoUpdateSet()
	if len(allowed) == 0 {
		r.bus.Infof("no extensions in the auto-update allowlist; nothing to do")
		return nil
	}

	dbs, err := pgListDatabases(ctx, r.req)
	if err != nil {
		return err
	}
	findings, err := pgListExtensions(ctx, r.busWarnf, r.req, dbs)
	if err != nil {
		return err
	}

	var updated, atVersion, failed []string
	for _, d := range findings {
		for _, ext := range d.Extensions {
			if !allowed[ext.Name] {
				continue
			}
			tag := d.DBName + "." + ext.Name
			oldV, newV, err := pgAlterExtensionUpdate(ctx, r.req, d.DBName, ext.Name)
			if err != nil {
				r.bus.Errorf("ALTER EXTENSION %s on %s failed: %v", ext.Name, d.DBName, err)
				failed = append(failed, tag)
				continue
			}
			if oldV != newV {
				r.bus.Infof("updated %s: %s -> %s", tag, oldV, newV)
				updated = append(updated, tag)
			} else {
				r.bus.Infof("%s already at %s", tag, newV)
				atVersion = append(atVersion, tag)
			}
		}
	}

	r.bus.Infof("extension update summary: updated=%d at-version=%d failed=%d",
		len(updated), len(atVersion), len(failed))
	if len(failed) > 0 {
		return fmt.Errorf("extension updates failed: %v", failed)
	}
	return nil
}

// ---------- helpers ----------

func (r *Runner) busWarnf(format string, args ...any) { r.bus.Warnf(format, args...) }

func majorStr(version string) string {
	if i := strings.Index(version, "."); i >= 0 {
		return version[:i]
	}
	return version
}

func majorOf(version string) int {
	var n int
	fmt.Sscanf(majorStr(version), "%d", &n)
	return n
}

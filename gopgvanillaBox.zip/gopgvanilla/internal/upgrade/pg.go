package upgrade

import (
	"context"
	"fmt"
	"net/url"
	"time"

	"github.com/jackc/pgx/v5"
)

// pgConnect opens a connection to one database on the target server.
// dbname == "" falls back to the maintenance database from the request.
func pgConnect(ctx context.Context, req Request, dbname string) (*pgx.Conn, error) {
	if dbname == "" {
		dbname = req.DBName
	}
	q := url.Values{}
	q.Set("sslmode", req.SSLMode)
	q.Set("connect_timeout", "15")
	if req.SSLRootCert != "" {
		q.Set("sslrootcert", req.SSLRootCert)
	}
	dsn := fmt.Sprintf("postgres://%s:%s@%s:%d/%s?%s",
		url.QueryEscape(req.User), url.QueryEscape(req.Password),
		req.Host, req.Port, url.PathEscape(dbname), q.Encode())

	ctx, cancel := context.WithTimeout(ctx, 20*time.Second)
	defer cancel()
	conn, err := pgx.Connect(ctx, dsn)
	if err != nil {
		return nil, fmt.Errorf("connect to %s/%s: %w", req.Host, dbname, err)
	}
	return conn, nil
}

func pgServerVersion(ctx context.Context, req Request) (string, error) {
	conn, err := pgConnect(ctx, req, "")
	if err != nil {
		return "", err
	}
	defer conn.Close(ctx)
	var v string
	if err := conn.QueryRow(ctx, "SHOW server_version").Scan(&v); err != nil {
		return "", fmt.Errorf("SHOW server_version: %w", err)
	}
	return v, nil
}

func pgListDatabases(ctx context.Context, req Request) ([]string, error) {
	conn, err := pgConnect(ctx, req, "")
	if err != nil {
		return nil, err
	}
	defer conn.Close(ctx)
	rows, err := conn.Query(ctx,
		`SELECT datname FROM pg_database
		  WHERE datistemplate = false AND datallowconn = true
		  ORDER BY datname`)
	if err != nil {
		return nil, fmt.Errorf("list databases: %w", err)
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return nil, err
		}
		out = append(out, name)
	}
	return out, rows.Err()
}

// pgListExtensions collects installed extensions per database. Databases that
// cannot be connected to are reported with an empty finding list plus a warning,
// matching the Python behavior.
func pgListExtensions(ctx context.Context, log logf, req Request, dbnames []string) ([]DatabaseExtensions, error) {
	out := make([]DatabaseExtensions, 0, len(dbnames))
	for _, db := range dbnames {
		findings, err := pgListExtensionsOne(ctx, req, db)
		if err != nil {
			log("cannot list extensions on %s: %v", db, err)
			findings = nil
		}
		out = append(out, DatabaseExtensions{DBName: db, Extensions: findings})
	}
	return out, nil
}

func pgListExtensionsOne(ctx context.Context, req Request, db string) ([]ExtensionFinding, error) {
	conn, err := pgConnect(ctx, req, db)
	if err != nil {
		return nil, err
	}
	defer conn.Close(ctx)
	rows, err := conn.Query(ctx,
		`SELECT e.extname, e.extversion, n.nspname
		   FROM pg_extension e
		   JOIN pg_namespace n ON n.oid = e.extnamespace
		  ORDER BY e.extname`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var findings []ExtensionFinding
	for rows.Next() {
		var f ExtensionFinding
		if err := rows.Scan(&f.Name, &f.Version, &f.Schema); err != nil {
			return nil, err
		}
		f.Category = classifyExtension(f.Name)
		findings = append(findings, f)
	}
	return findings, rows.Err()
}

// pgAlterExtensionUpdate runs ALTER EXTENSION <ext> UPDATE and returns
// (old_version, new_version). Extension names come from pg_extension, but a
// charset whitelist is still enforced before interpolating the identifier.
func pgAlterExtensionUpdate(ctx context.Context, req Request, dbname, ext string) (string, string, error) {
	if !safeIdentifier(ext) {
		return "", "", fmt.Errorf("refusing to ALTER EXTENSION on unsafe name: %q", ext)
	}
	conn, err := pgConnect(ctx, req, dbname)
	if err != nil {
		return "", "", err
	}
	defer conn.Close(ctx)

	var oldV string
	if err := conn.QueryRow(ctx,
		"SELECT extversion FROM pg_extension WHERE extname = $1", ext).Scan(&oldV); err != nil {
		if err == pgx.ErrNoRows {
			oldV = ""
		} else {
			return "", "", err
		}
	}
	if _, err := conn.Exec(ctx, fmt.Sprintf(`ALTER EXTENSION %q UPDATE`, ext)); err != nil {
		return oldV, "", fmt.Errorf("ALTER EXTENSION %s UPDATE: %w", ext, err)
	}
	var newV string
	if err := conn.QueryRow(ctx,
		"SELECT extversion FROM pg_extension WHERE extname = $1", ext).Scan(&newV); err != nil {
		return oldV, "", err
	}
	return oldV, newV, nil
}

func safeIdentifier(name string) bool {
	if len(name) == 0 || len(name) > 63 {
		return false
	}
	for _, c := range name {
		ok := c == '_' || c == '-' ||
			(c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
		if !ok {
			return false
		}
	}
	return true
}

// logf lets pg helpers emit warnings without importing runlog directly.
type logf func(format string, args ...any)

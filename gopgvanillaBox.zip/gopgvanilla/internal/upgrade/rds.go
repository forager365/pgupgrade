package upgrade

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/anandbabu/gopgvanilla/internal/runlog"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/retry"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	rdstypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
	"github.com/aws/smithy-go"
)

// Topology mirrors the Python enum.
type Topology string

const (
	TopoRDSSingle           Topology = "rds-single"
	TopoRDSMultiAZ          Topology = "rds-multi-az"
	TopoRDSMultiAZCluster   Topology = "rds-multi-az-cluster"
	TopoRDSWithReadReplicas Topology = "rds-with-read-replicas"
	TopoAuroraProvisioned   Topology = "aurora-provisioned"
	TopoAuroraServerlessV1  Topology = "aurora-serverless-v1"
	TopoAuroraServerlessV2  Topology = "aurora-serverless-v2"
)

// TargetRef is the resolved RDS target: exactly one of InstanceID/ClusterID
// is set, plus topology and parameter-group wiring for the upgrade plan.
type TargetRef struct {
	Topology            Topology          `json:"topology"`
	InstanceID          string            `json:"instance_id,omitempty"`
	ClusterID           string            `json:"cluster_id,omitempty"`
	Engine              string            `json:"engine"`
	EngineVersion       string            `json:"engine_version"`
	InstanceParamGroups map[string]string `json:"instance_param_groups"`
	ClusterParamGroup   string            `json:"cluster_param_group,omitempty"`
	MemberInstanceIDs   []string          `json:"member_instance_ids"`
}

func (t TargetRef) Identifier() string {
	if t.ClusterID != "" {
		return t.ClusterID
	}
	return t.InstanceID
}

type rdsAPI struct {
	c            *rds.Client
	log          *runlog.Bus
	lastStatuses map[string]string
}

func newRDS(cfg aws.Config, log *runlog.Bus) *rdsAPI {
	return &rdsAPI{
		c: rds.NewFromConfig(cfg, func(o *rds.Options) {
			o.Retryer = retry.NewStandard(func(so *retry.StandardOptions) { so.MaxAttempts = 5 })
		}),
		log:          log,
		lastStatuses: map[string]string{},
	}
}

// ---------- Topology discovery ----------

// discoverTarget resolves the connection host (or explicit identifier) to an
// RDS instance or Aurora cluster and classifies the topology.
func (r *rdsAPI) discoverTarget(ctx context.Context, host, identifier string) (TargetRef, error) {
	cluster, err := r.findCluster(ctx, host, identifier)
	if err != nil {
		return TargetRef{}, err
	}
	if cluster != nil {
		return r.classifyCluster(ctx, *cluster)
	}

	inst, err := r.findInstance(ctx, host, identifier)
	if err != nil {
		return TargetRef{}, err
	}
	if inst != nil {
		return r.classifyInstance(ctx, *inst)
	}

	return TargetRef{}, fmt.Errorf(
		"no RDS instance or Aurora cluster found matching host=%q identifier=%q", host, identifier)
}

func (r *rdsAPI) findCluster(ctx context.Context, host, identifier string) (*rdstypes.DBCluster, error) {
	p := rds.NewDescribeDBClustersPaginator(r.c, &rds.DescribeDBClustersInput{})
	for p.HasMorePages() {
		page, err := p.NextPage(ctx)
		if err != nil {
			return nil, fmt.Errorf("describe_db_clusters: %w", err)
		}
		for i := range page.DBClusters {
			c := page.DBClusters[i]
			if identifier != "" && aws.ToString(c.DBClusterIdentifier) == identifier {
				return &c, nil
			}
			if identifier == "" &&
				(aws.ToString(c.Endpoint) == host || aws.ToString(c.ReaderEndpoint) == host) {
				return &c, nil
			}
		}
	}
	return nil, nil
}

func (r *rdsAPI) findInstance(ctx context.Context, host, identifier string) (*rdstypes.DBInstance, error) {
	p := rds.NewDescribeDBInstancesPaginator(r.c, &rds.DescribeDBInstancesInput{})
	for p.HasMorePages() {
		page, err := p.NextPage(ctx)
		if err != nil {
			return nil, fmt.Errorf("describe_db_instances: %w", err)
		}
		for i := range page.DBInstances {
			inst := page.DBInstances[i]
			if identifier != "" && aws.ToString(inst.DBInstanceIdentifier) == identifier {
				return &inst, nil
			}
			if identifier == "" && inst.Endpoint != nil && aws.ToString(inst.Endpoint.Address) == host {
				return &inst, nil
			}
		}
	}
	return nil, nil
}

func (r *rdsAPI) memberInstances(ctx context.Context, memberIDs []string) ([]rdstypes.DBInstance, error) {
	if len(memberIDs) == 0 {
		return nil, nil
	}
	out, err := r.c.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		Filters: []rdstypes.Filter{{Name: aws.String("db-instance-id"), Values: memberIDs}},
	})
	if err != nil {
		return nil, fmt.Errorf("describe_db_instances(members): %w", err)
	}
	return out.DBInstances, nil
}

func (r *rdsAPI) classifyCluster(ctx context.Context, c rdstypes.DBCluster) (TargetRef, error) {
	memberIDs := make([]string, 0, len(c.DBClusterMembers))
	for _, m := range c.DBClusterMembers {
		memberIDs = append(memberIDs, aws.ToString(m.DBInstanceIdentifier))
	}

	members, err := r.memberInstances(ctx, memberIDs)
	if err != nil {
		return TargetRef{}, err
	}

	var topo Topology
	if aws.ToString(c.EngineMode) == "serverless" {
		topo = TopoAuroraServerlessV1
	} else {
		// Serverless v2: provisioned mode but instance class is db.serverless.
		topo = TopoAuroraProvisioned
		for _, m := range members {
			if aws.ToString(m.DBInstanceClass) == "db.serverless" {
				topo = TopoAuroraServerlessV2
				break
			}
		}
	}

	// Per-instance parameter groups (cluster members each have an instance PG too).
	instPGs := map[string]string{}
	for _, m := range members {
		if len(m.DBParameterGroups) > 0 {
			instPGs[aws.ToString(m.DBInstanceIdentifier)] =
				aws.ToString(m.DBParameterGroups[0].DBParameterGroupName)
		}
	}

	return TargetRef{
		Topology:            topo,
		ClusterID:           aws.ToString(c.DBClusterIdentifier),
		Engine:              aws.ToString(c.Engine),
		EngineVersion:       aws.ToString(c.EngineVersion),
		InstanceParamGroups: instPGs,
		ClusterParamGroup:   aws.ToString(c.DBClusterParameterGroup),
		MemberInstanceIDs:   memberIDs,
	}, nil
}

func (r *rdsAPI) classifyInstance(ctx context.Context, inst rdstypes.DBInstance) (TargetRef, error) {
	if cid := aws.ToString(inst.DBClusterIdentifier); cid != "" {
		// It's an Aurora member; classify via the cluster instead.
		out, err := r.c.DescribeDBClusters(ctx, &rds.DescribeDBClustersInput{
			DBClusterIdentifier: aws.String(cid),
		})
		if err != nil {
			return TargetRef{}, fmt.Errorf("describe_db_clusters(%s): %w", cid, err)
		}
		if len(out.DBClusters) > 0 {
			return r.classifyCluster(ctx, out.DBClusters[0])
		}
	}

	hasReadReplication := false
	for _, s := range inst.StatusInfos {
		if aws.ToString(s.StatusType) == "read replication" {
			hasReadReplication = true
		}
	}
	hasReadReplicas := len(inst.ReadReplicaDBInstanceIdentifiers) > 0
	multiAZ := aws.ToBool(inst.MultiAZ)

	var topo Topology
	switch {
	case hasReadReplicas:
		topo = TopoRDSWithReadReplicas
	case multiAZ:
		topo = TopoRDSMultiAZ
	case hasReadReplication:
		topo = TopoRDSMultiAZCluster
	default:
		topo = TopoRDSSingle
	}

	instPGs := map[string]string{}
	if len(inst.DBParameterGroups) > 0 {
		instPGs[aws.ToString(inst.DBInstanceIdentifier)] =
			aws.ToString(inst.DBParameterGroups[0].DBParameterGroupName)
	}

	return TargetRef{
		Topology:            topo,
		InstanceID:          aws.ToString(inst.DBInstanceIdentifier),
		Engine:              aws.ToString(inst.Engine),
		EngineVersion:       aws.ToString(inst.EngineVersion),
		InstanceParamGroups: instPGs,
		MemberInstanceIDs:   inst.ReadReplicaDBInstanceIdentifiers,
	}, nil
}

// ---------- Upgrade path validation ----------

func (r *rdsAPI) validUpgradeTarget(ctx context.Context, engine, currentVersion, targetVersion string) (bool, error) {
	out, err := r.c.DescribeDBEngineVersions(ctx, &rds.DescribeDBEngineVersionsInput{
		Engine:        aws.String(engine),
		EngineVersion: aws.String(currentVersion),
	})
	if err != nil {
		return false, fmt.Errorf("describe_db_engine_versions(%s %s): %w", engine, currentVersion, err)
	}
	for _, ver := range out.DBEngineVersions {
		for _, tgt := range ver.ValidUpgradeTarget {
			if aws.ToString(tgt.EngineVersion) == targetVersion && aws.ToBool(tgt.IsMajorVersionUpgrade) {
				return true, nil
			}
		}
	}
	return false, nil
}

func (r *rdsAPI) engineFamily(ctx context.Context, engine, version string) (string, error) {
	out, err := r.c.DescribeDBEngineVersions(ctx, &rds.DescribeDBEngineVersionsInput{
		Engine:        aws.String(engine),
		EngineVersion: aws.String(version),
	})
	if err != nil {
		return "", fmt.Errorf("describe_db_engine_versions(%s %s): %w", engine, version, err)
	}
	if len(out.DBEngineVersions) == 0 {
		return "", fmt.Errorf("unknown engine version %s %s", engine, version)
	}
	return aws.ToString(out.DBEngineVersions[0].DBParameterGroupFamily), nil
}

// ---------- Naming ----------

// snapshotID builds an RDS-safe snapshot identifier:
// <=255 chars, letters/digits/hyphens, must start with a letter.
func snapshotID(prefix, identifier, version string) string {
	ts := time.Now().UTC().Format("20060102t150405Z")
	verSafe := strings.ReplaceAll(version, ".", "-")
	return fmt.Sprintf("%s-%s-%s-%s", prefix, identifier, verSafe, ts)
}

// paramGroupName builds an RDS-safe parameter group name.
func paramGroupName(identifier, version, suffix string) string {
	verSafe := strings.ReplaceAll(version, ".", "-")
	return fmt.Sprintf("%s-v-%s-%s", identifier, verSafe, suffix)
}

// ---------- Snapshot ----------

func (r *rdsAPI) createSnapshot(ctx context.Context, target TargetRef, snapID string) error {
	if target.ClusterID != "" {
		r.log.Infof("creating cluster snapshot %s for %s", snapID, target.ClusterID)
		_, err := r.c.CreateDBClusterSnapshot(ctx, &rds.CreateDBClusterSnapshotInput{
			DBClusterSnapshotIdentifier: aws.String(snapID),
			DBClusterIdentifier:         aws.String(target.ClusterID),
		})
		if err != nil {
			return fmt.Errorf("create_db_cluster_snapshot(%s): %w", snapID, err)
		}
		return nil
	}
	r.log.Infof("creating instance snapshot %s for %s", snapID, target.InstanceID)
	_, err := r.c.CreateDBSnapshot(ctx, &rds.CreateDBSnapshotInput{
		DBSnapshotIdentifier: aws.String(snapID),
		DBInstanceIdentifier: aws.String(target.InstanceID),
	})
	if err != nil {
		return fmt.Errorf("create_db_snapshot(%s): %w", snapID, err)
	}
	return nil
}

func (r *rdsAPI) waitSnapshotAvailable(ctx context.Context, target TargetRef, snapID string, timeout time.Duration) error {
	fetch := func() (string, error) {
		if target.ClusterID != "" {
			out, err := r.c.DescribeDBClusterSnapshots(ctx, &rds.DescribeDBClusterSnapshotsInput{
				DBClusterSnapshotIdentifier: aws.String(snapID),
			})
			if err != nil {
				return "", err
			}
			if len(out.DBClusterSnapshots) == 0 {
				return "", fmt.Errorf("cluster snapshot disappeared: %s", snapID)
			}
			return aws.ToString(out.DBClusterSnapshots[0].Status), nil
		}
		out, err := r.c.DescribeDBSnapshots(ctx, &rds.DescribeDBSnapshotsInput{
			DBSnapshotIdentifier: aws.String(snapID),
		})
		if err != nil {
			return "", err
		}
		if len(out.DBSnapshots) == 0 {
			return "", fmt.Errorf("snapshot disappeared: %s", snapID)
		}
		return aws.ToString(out.DBSnapshots[0].Status), nil
	}

	r.log.Infof("waiting for snapshot %s to become available (timeout %s)", snapID, timeout)
	return pollStatus(ctx, timeout, 30*time.Second, func() (bool, error) {
		status, err := fetch()
		if err != nil {
			return false, err
		}
		r.logStatusChange("snapshot "+snapID, status)
		if status == "failed" || status == "error" {
			return false, fmt.Errorf("snapshot %s entered status %q", snapID, status)
		}
		return status == "available", nil
	})
}

// ---------- Parameter group copy across families ----------

// copyUserModifiedParams creates a parameter group in targetFamily and applies
// the user-modified parameters from sourceName that remain valid there.
func (r *rdsAPI) copyUserModifiedParams(ctx context.Context, sourceName, targetName, targetFamily string, isCluster bool) error {
	kind := "instance"
	if isCluster {
		kind = "cluster"
	}

	exists, err := r.paramGroupExists(ctx, targetName, isCluster)
	if err != nil {
		return err
	}
	if exists {
		r.log.Infof("parameter group %s already exists; reusing", targetName)
	} else {
		r.log.Infof("creating %s parameter group %s (family %s)", kind, targetName, targetFamily)
		desc := aws.String("Auto-created by gopgvanilla from " + sourceName)
		if isCluster {
			_, err = r.c.CreateDBClusterParameterGroup(ctx, &rds.CreateDBClusterParameterGroupInput{
				DBClusterParameterGroupName: aws.String(targetName),
				DBParameterGroupFamily:      aws.String(targetFamily),
				Description:                 desc,
			})
		} else {
			_, err = r.c.CreateDBParameterGroup(ctx, &rds.CreateDBParameterGroupInput{
				DBParameterGroupName:   aws.String(targetName),
				DBParameterGroupFamily: aws.String(targetFamily),
				Description:            desc,
			})
		}
		if err != nil {
			return fmt.Errorf("create %s parameter group %s: %w", kind, targetName, err)
		}
	}

	// Collect user-modified, modifiable params from the source group.
	userParams, err := r.listParams(ctx, sourceName, "user", isCluster)
	if err != nil {
		return err
	}
	var applicableSrc []rdstypes.Parameter
	for _, p := range userParams {
		if p.ParameterName != nil && p.ParameterValue != nil && aws.ToBool(p.IsModifiable) {
			applyMethod := p.ApplyMethod
			if applyMethod == "" {
				applyMethod = rdstypes.ApplyMethodPendingReboot
			}
			applicableSrc = append(applicableSrc, rdstypes.Parameter{
				ParameterName:  p.ParameterName,
				ParameterValue: p.ParameterValue,
				ApplyMethod:    applyMethod,
			})
		}
	}
	if len(applicableSrc) == 0 {
		r.log.Infof("no user-modified parameters to copy from %s", sourceName)
		return nil
	}

	// Validate each param is known in the target family.
	targetParams, err := r.listParams(ctx, targetName, "", isCluster)
	if err != nil {
		return err
	}
	known := map[string]bool{}
	for _, p := range targetParams {
		known[aws.ToString(p.ParameterName)] = true
	}

	var applicable []rdstypes.Parameter
	var skipped []string
	for _, p := range applicableSrc {
		if known[aws.ToString(p.ParameterName)] {
			applicable = append(applicable, p)
		} else {
			skipped = append(skipped, aws.ToString(p.ParameterName))
		}
	}
	if len(skipped) > 0 {
		r.log.Warnf("skipping parameters absent in target family %s: %v", targetFamily, skipped)
	}

	// Modify in chunks of 20 (AWS limit).
	for i := 0; i < len(applicable); i += 20 {
		end := i + 20
		if end > len(applicable) {
			end = len(applicable)
		}
		chunk := applicable[i:end]
		if isCluster {
			_, err = r.c.ModifyDBClusterParameterGroup(ctx, &rds.ModifyDBClusterParameterGroupInput{
				DBClusterParameterGroupName: aws.String(targetName),
				Parameters:                  chunk,
			})
		} else {
			_, err = r.c.ModifyDBParameterGroup(ctx, &rds.ModifyDBParameterGroupInput{
				DBParameterGroupName: aws.String(targetName),
				Parameters:           chunk,
			})
		}
		if err != nil {
			return fmt.Errorf("modify %s parameter group %s: %w", kind, targetName, err)
		}
	}

	r.log.Infof("applied %d parameters to %s (skipped %d)", len(applicable), targetName, len(skipped))
	return nil
}

func (r *rdsAPI) paramGroupExists(ctx context.Context, name string, isCluster bool) (bool, error) {
	var err error
	if isCluster {
		_, err = r.c.DescribeDBClusterParameterGroups(ctx, &rds.DescribeDBClusterParameterGroupsInput{
			DBClusterParameterGroupName: aws.String(name),
		})
	} else {
		_, err = r.c.DescribeDBParameterGroups(ctx, &rds.DescribeDBParameterGroupsInput{
			DBParameterGroupName: aws.String(name),
		})
	}
	if err == nil {
		return true, nil
	}
	var ae smithy.APIError
	if errors.As(err, &ae) && strings.Contains(ae.ErrorCode(), "NotFound") {
		return false, nil
	}
	return false, fmt.Errorf("describe parameter group %s: %w", name, err)
}

func (r *rdsAPI) listParams(ctx context.Context, name, source string, isCluster bool) ([]rdstypes.Parameter, error) {
	var out []rdstypes.Parameter
	if isCluster {
		in := &rds.DescribeDBClusterParametersInput{DBClusterParameterGroupName: aws.String(name)}
		if source != "" {
			in.Source = aws.String(source)
		}
		p := rds.NewDescribeDBClusterParametersPaginator(r.c, in)
		for p.HasMorePages() {
			page, err := p.NextPage(ctx)
			if err != nil {
				return nil, fmt.Errorf("describe_db_cluster_parameters(%s): %w", name, err)
			}
			out = append(out, page.Parameters...)
		}
		return out, nil
	}
	in := &rds.DescribeDBParametersInput{DBParameterGroupName: aws.String(name)}
	if source != "" {
		in.Source = aws.String(source)
	}
	p := rds.NewDescribeDBParametersPaginator(r.c, in)
	for p.HasMorePages() {
		page, err := p.NextPage(ctx)
		if err != nil {
			return nil, fmt.Errorf("describe_db_parameters(%s): %w", name, err)
		}
		out = append(out, page.Parameters...)
	}
	return out, nil
}

// ---------- Initiate upgrade ----------

func (r *rdsAPI) initiateInstanceUpgrade(ctx context.Context, instanceID, targetVersion, newParamGroup string) error {
	r.log.Infof("modifying instance %s: EngineVersion=%s, PG=%s, AllowMajorVersionUpgrade=true, ApplyImmediately=true",
		instanceID, targetVersion, newParamGroup)
	_, err := r.c.ModifyDBInstance(ctx, &rds.ModifyDBInstanceInput{
		DBInstanceIdentifier:     aws.String(instanceID),
		EngineVersion:            aws.String(targetVersion),
		AllowMajorVersionUpgrade: aws.Bool(true),
		DBParameterGroupName:     aws.String(newParamGroup),
		ApplyImmediately:         aws.Bool(true),
	})
	if err != nil {
		return fmt.Errorf("modify_db_instance(%s): %w", instanceID, err)
	}
	return nil
}

func (r *rdsAPI) initiateClusterUpgrade(ctx context.Context, clusterID, targetVersion, newClusterParamGroup string) error {
	r.log.Infof("modifying cluster %s: EngineVersion=%s, ClusterPG=%s, AllowMajorVersionUpgrade=true, ApplyImmediately=true",
		clusterID, targetVersion, newClusterParamGroup)
	_, err := r.c.ModifyDBCluster(ctx, &rds.ModifyDBClusterInput{
		DBClusterIdentifier:         aws.String(clusterID),
		EngineVersion:               aws.String(targetVersion),
		AllowMajorVersionUpgrade:    aws.Bool(true),
		DBClusterParameterGroupName: aws.String(newClusterParamGroup),
		ApplyImmediately:            aws.Bool(true),
	})
	if err != nil {
		return fmt.Errorf("modify_db_cluster(%s): %w", clusterID, err)
	}
	return nil
}

func (r *rdsAPI) attachInstanceParamGroup(ctx context.Context, instanceID, newParamGroup string) error {
	r.log.Infof("attaching instance parameter group %s to %s", newParamGroup, instanceID)
	_, err := r.c.ModifyDBInstance(ctx, &rds.ModifyDBInstanceInput{
		DBInstanceIdentifier: aws.String(instanceID),
		DBParameterGroupName: aws.String(newParamGroup),
		ApplyImmediately:     aws.Bool(true),
	})
	if err != nil {
		return fmt.Errorf("modify_db_instance(%s) attach PG: %w", instanceID, err)
	}
	return nil
}

// ---------- Polling ----------

// waitInstanceUpgraded waits until the instance is available AND (when
// expectedMajor != "") reports the expected engine major version. Requiring
// the version match closes the race where the instance still reports
// "available" for a short window after ModifyDBInstance is accepted.
func (r *rdsAPI) waitInstanceUpgraded(ctx context.Context, instanceID, expectedMajor string, timeout time.Duration) error {
	r.log.Infof("waiting for instance %s to become available (timeout %s)", instanceID, timeout)
	return pollStatus(ctx, timeout, 30*time.Second, func() (bool, error) {
		out, err := r.c.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
			DBInstanceIdentifier: aws.String(instanceID),
		})
		if err != nil {
			return false, fmt.Errorf("describe_db_instances(%s): %w", instanceID, err)
		}
		if len(out.DBInstances) == 0 {
			return false, fmt.Errorf("instance disappeared during wait: %s", instanceID)
		}
		inst := out.DBInstances[0]
		status := aws.ToString(inst.DBInstanceStatus)
		version := aws.ToString(inst.EngineVersion)
		r.logStatusChange("instance "+instanceID, status+" (engine "+version+")")
		if status != "available" {
			return false, nil
		}
		if expectedMajor != "" && !strings.HasPrefix(version, expectedMajor+".") && version != expectedMajor {
			// Still on old version: modification not applied yet.
			return false, nil
		}
		return true, nil
	})
}

func (r *rdsAPI) waitClusterUpgraded(ctx context.Context, clusterID, expectedMajor string, timeout time.Duration) error {
	r.log.Infof("waiting for cluster %s to become available (timeout %s)", clusterID, timeout)
	return pollStatus(ctx, timeout, 30*time.Second, func() (bool, error) {
		out, err := r.c.DescribeDBClusters(ctx, &rds.DescribeDBClustersInput{
			DBClusterIdentifier: aws.String(clusterID),
		})
		if err != nil {
			return false, fmt.Errorf("describe_db_clusters(%s): %w", clusterID, err)
		}
		if len(out.DBClusters) == 0 {
			return false, fmt.Errorf("cluster disappeared during wait: %s", clusterID)
		}
		c := out.DBClusters[0]
		status := aws.ToString(c.Status)
		version := aws.ToString(c.EngineVersion)
		r.logStatusChange("cluster "+clusterID, status+" (engine "+version+")")
		if status != "available" {
			return false, nil
		}
		if expectedMajor != "" && !strings.HasPrefix(version, expectedMajor+".") && version != expectedMajor {
			return false, nil
		}
		return true, nil
	})
}

// pollStatus runs check every interval until it returns done, errors, the
// timeout elapses, or the context is canceled.
func pollStatus(ctx context.Context, timeout, interval time.Duration, check func() (bool, error)) error {
	deadline := time.Now().Add(timeout)
	for {
		done, err := check()
		if err != nil {
			return err
		}
		if done {
			return nil
		}
		if time.Now().After(deadline) {
			return fmt.Errorf("timed out after %s", timeout)
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(interval):
		}
	}
}

// logStatusChange logs a status only when it changes, keeping poll loops quiet.
func (r *rdsAPI) logStatusChange(subject, status string) {
	if r.lastStatuses[subject] == status {
		return
	}
	r.lastStatuses[subject] = status
	r.log.Infof("%s status: %s", subject, status)
}

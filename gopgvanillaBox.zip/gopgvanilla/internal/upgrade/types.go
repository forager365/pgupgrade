package upgrade

import (
	"fmt"
	"regexp"
	"strings"
)

// Mode selects which workflow the run executes.
type Mode string

const (
	ModeDryRun   Mode = "dry-run"  // inspect state and validate plan without mutating anything
	ModeUpgrade  Mode = "upgrade"  // snapshot, copy parameter groups, in-place upgrade, validate
	ModeValidate Mode = "validate" // post-upgrade validation only
)

// Step identifiers. Each step is an auditable unit of work; in interactive
// runs the operator approves each one before it executes.
const (
	StepDiscover     = "DISCOVER"
	StepValidatePath = "VALIDATE_UPGRADE_PATH"
	StepInspectExt   = "INSPECT_EXTENSIONS"
	StepPlan         = "PLAN_REVIEW"
	StepSnapshot     = "SNAPSHOT"
	StepParamGroups  = "PARAMETER_GROUPS"
	StepUpgrade      = "IN_PLACE_UPGRADE"
	StepPostValidate = "POST_VALIDATION"
	StepUpdateExt    = "UPDATE_EXTENSIONS"
)

// StepStatus values published to the UI and audit log.
const (
	StatusPending          = "pending"
	StatusAwaitingApproval = "awaiting_approval"
	StatusRunning          = "running"
	StatusCompleted        = "completed"
	StatusFailed           = "failed"
	StatusSkipped          = "skipped"
	StatusAborted          = "aborted"
)

// Request is what the HTTP layer passes in.
type Request struct {
	Mode Mode `json:"mode" toml:"mode"`

	// AWS
	SSOProfile string `json:"sso_profile" toml:"sso_profile"`
	Region     string `json:"region" toml:"region"`

	// Target selection: identifier wins if set, otherwise the endpoint host
	// is resolved against instance/cluster endpoints.
	Identifier string `json:"identifier" toml:"identifier"`

	// Postgres connection (also used as the discovery host when Identifier is empty)
	Host        string `json:"host" toml:"host"`
	Port        int    `json:"port" toml:"port"`
	DBName      string `json:"dbname" toml:"dbname"`
	User        string `json:"user" toml:"user"`
	Password    string `json:"password" toml:"password"`
	SSLMode     string `json:"sslmode" toml:"sslmode"`
	SSLRootCert string `json:"sslrootcert" toml:"sslrootcert"`

	// Upgrade plan
	TargetVersion  string `json:"target_version" toml:"target_version"`
	SnapshotPrefix string `json:"snapshot_prefix" toml:"snapshot_prefix"`
	InstancePGSfx  string `json:"instance_pg_suffix" toml:"instance_pg_suffix"`
	ClusterPGSfx   string `json:"cluster_pg_suffix" toml:"cluster_pg_suffix"`

	// Extensions safe to ALTER EXTENSION ... UPDATE after the upgrade
	// (comma/whitespace separated in the form).
	AutoUpdateExtensions string `json:"auto_update_extensions" toml:"auto_update_extensions"`

	// Interactive: pause before every step and wait for operator approval.
	Interactive bool `json:"interactive" toml:"interactive"`

	SnapshotTimeoutSeconds int `json:"snapshot_timeout_seconds" toml:"snapshot_timeout_seconds"`
	UpgradeTimeoutSeconds  int `json:"upgrade_timeout_seconds" toml:"upgrade_timeout_seconds"`
}

var versionRe = regexp.MustCompile(`^\d+(\.\d+)*$`)

var validSSLModes = map[string]bool{
	"disable": true, "allow": true, "prefer": true,
	"require": true, "verify-ca": true, "verify-full": true,
}

// ApplyDefaults fills optional fields, mirroring the Python config defaults.
func (r *Request) ApplyDefaults() {
	if r.Mode == "" {
		r.Mode = ModeDryRun
	}
	if r.Port == 0 {
		r.Port = 5432
	}
	if r.SSLMode == "" {
		r.SSLMode = "require"
	}
	if r.SnapshotPrefix == "" {
		r.SnapshotPrefix = "preupgrade"
	}
	if r.InstancePGSfx == "" {
		r.InstancePGSfx = "inst"
	}
	if r.ClusterPGSfx == "" {
		r.ClusterPGSfx = "clstr"
	}
	if r.SnapshotTimeoutSeconds <= 0 {
		r.SnapshotTimeoutSeconds = 3600
	}
	if r.UpgradeTimeoutSeconds <= 0 {
		r.UpgradeTimeoutSeconds = 7200
	}
}

// Validate rejects malformed requests before anything touches AWS or Postgres.
func (r *Request) Validate() error {
	var problems []string
	add := func(f string, args ...any) { problems = append(problems, fmt.Sprintf(f, args...)) }

	switch r.Mode {
	case ModeDryRun, ModeUpgrade, ModeValidate:
	default:
		add("mode must be one of %s|%s|%s (got %q)", ModeDryRun, ModeUpgrade, ModeValidate, r.Mode)
	}
	if r.Region == "" {
		add("region is required")
	}
	if r.Host == "" && r.Identifier == "" {
		add("either host or identifier is required")
	}
	if r.Host == "" {
		add("host is required (used for the Postgres connection)")
	}
	if r.DBName == "" {
		add("dbname is required")
	}
	if r.User == "" {
		add("user is required")
	}
	if r.Password == "" {
		add("password is required")
	}
	if r.Port < 1 || r.Port > 65535 {
		add("port must be in 1..65535 (got %d)", r.Port)
	}
	if !validSSLModes[r.SSLMode] {
		add("sslmode %q is not a valid libpq sslmode", r.SSLMode)
	}
	if r.TargetVersion == "" {
		add("target_version is required")
	} else if !versionRe.MatchString(r.TargetVersion) {
		add("target_version %q must look like 16 or 16.4", r.TargetVersion)
	}
	if len(problems) > 0 {
		return fmt.Errorf("invalid request: %s", strings.Join(problems, "; "))
	}
	return nil
}

// AutoUpdateSet parses the allowlist into a set.
func (r *Request) AutoUpdateSet() map[string]bool {
	out := map[string]bool{}
	for _, tok := range strings.FieldsFunc(r.AutoUpdateExtensions, func(c rune) bool {
		return c == ',' || c == ' ' || c == '\n' || c == '\t'
	}) {
		if tok != "" {
			out[tok] = true
		}
	}
	return out
}

// StepsForMode returns the ordered step IDs the run will execute.
func StepsForMode(m Mode) []string {
	switch m {
	case ModeUpgrade:
		return []string{
			StepDiscover, StepValidatePath, StepInspectExt, StepSnapshot,
			StepParamGroups, StepUpgrade, StepPostValidate, StepUpdateExt,
		}
	case ModeValidate:
		return []string{StepDiscover, StepPostValidate, StepUpdateExt}
	default: // dry-run
		return []string{StepDiscover, StepValidatePath, StepInspectExt, StepPlan}
	}
}

// StepTitles maps step IDs to operator-facing descriptions.
var StepTitles = map[string]string{
	StepDiscover:     "Discover target & classify topology",
	StepValidatePath: "Validate major-version upgrade path",
	StepInspectExt:   "Inspect databases & extensions",
	StepPlan:         "Review upgrade plan (dry-run)",
	StepSnapshot:     "Create pre-upgrade snapshot & wait",
	StepParamGroups:  "Build target parameter groups",
	StepUpgrade:      "Execute in-place engine upgrade",
	StepPostValidate: "Post-upgrade validation",
	StepUpdateExt:    "ALTER EXTENSION UPDATE (allowlist)",
}

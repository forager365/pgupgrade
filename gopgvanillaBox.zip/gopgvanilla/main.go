// gopgvanilla is an in-place RDS Postgres major-version upgrade orchestrator
// with a web UI. It is the Go port of the Python `pgupgrade` package, driven
// through the bggo-style web workflow: every action is streamed to the browser
// and mirrored to a per-run JSONL audit log, and in interactive mode each step
// waits for operator approval before executing.
package main

import (
	"flag"
	"log"
	"net/http"
	"os"
	"path/filepath"

	"github.com/pelletier/go-toml/v2"

	"github.com/anandbabu/gopgvanilla/internal/runlog"
	"github.com/anandbabu/gopgvanilla/internal/server"
	"github.com/anandbabu/gopgvanilla/internal/upgrade"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8090", "HTTP listen address")
	logDir := flag.String("log-dir", "", "directory for per-run JSONL audit logs (default: <binary dir>/logs)")
	credsFile := flag.String("creds", "", "path to credentials.toml file")
	flag.Parse()

	if *logDir == "" {
		exe, err := os.Executable()
		if err != nil {
			log.Fatalf("locate executable: %v", err)
		}
		*logDir = filepath.Join(filepath.Dir(exe), "logs")
	}

	bus := runlog.NewBus()
	var baseConfig upgrade.Request
	if *credsFile != "" {
		b, err := os.ReadFile(*credsFile)
		if err != nil {
			log.Fatalf("read creds file: %v", err)
		}
		if err := toml.Unmarshal(b, &baseConfig); err != nil {
			log.Fatalf("parse creds file: %v", err)
		}
	}
	srv := server.New(bus, *logDir, baseConfig)

	log.Printf("gopgvanilla listening on http://%s (audit logs in %s)", *addr, *logDir)
	if err := http.ListenAndServe(*addr, srv.Routes()); err != nil {
		log.Fatal(err)
	}
}

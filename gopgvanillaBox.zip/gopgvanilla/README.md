# gopgvanilla — RDS Postgres In-Place Upgrade Orchestrator

Go port of the Python `pgupgrade` package (in-place RDS/Aurora major-version
upgrades) driven through the bggo-style web workflow: a local web UI, live log
streaming over Server-Sent Events, and — new in this implementation — an
**interactive step engine** where every step is validated, audit-logged, and
waits for operator approval before executing.

## What it does

For an RDS Postgres instance or Aurora cluster, gopgvanilla:

1. **DISCOVER** — resolves the endpoint host (or explicit DB identifier) to an
   RDS instance or Aurora cluster and classifies the topology
   (single / Multi-AZ / read replicas / Aurora provisioned / serverless v2).
2. **VALIDATE_UPGRADE_PATH** — confirms the target version is a valid major
   upgrade per RDS `ValidUpgradeTarget`.
3. **INSPECT_EXTENSIONS** — connects to Postgres, lists every database and its
   extensions, and classifies each one (`drop_recreate` / `alter_update` /
   `review` / `unknown`). An upgrade run **refuses to proceed** while
   `drop_recreate` extensions (pg_repack, pglogical, …) are installed.
4. **SNAPSHOT** — takes a pre-upgrade snapshot and waits for it to be available.
5. **PARAMETER_GROUPS** — creates parameter groups in the target family and
   copies across every user-modified parameter that is still valid there.
6. **IN_PLACE_UPGRADE** — `ModifyDBInstance` / `ModifyDBCluster` with
   `AllowMajorVersionUpgrade`, then waits until the target is *available and
   reporting the new engine major version* (replicas / cluster members
   included).
7. **POST_VALIDATION** — re-discovers the target, checks the RDS-reported and
   SQL-reported (`SHOW server_version`) versions, and confirms databases are
   reachable.
8. **UPDATE_EXTENSIONS** — runs `ALTER EXTENSION … UPDATE` for the operator's
   allowlist and reports updated / at-version / failed counts.

Three run modes (same as the Python CLI subcommands):

| Mode       | Steps                                                     |
|------------|-----------------------------------------------------------|
| `dry-run`  | discover → validate path → inspect extensions → plan review (no mutations) |
| `upgrade`  | the full sequence above                                    |
| `validate` | discover → post-validation → update extensions             |

## Enterprise-grade guarantees

- **Interactive progression** — with *Interactive* enabled (the default), the
  run pauses before **every** step; the UI shows an approval prompt and the
  step only executes after the operator clicks **Approve & run step**.
  **Abort run** stops cleanly at the gate.
- **Full audit trail** — every log line, step transition, and run lifecycle
  event is streamed to the browser *and* appended to a per-run JSONL file
  under `--log-dir` (default `<binary dir>/logs`), e.g.
  `upgrade-20260703T134147Z.jsonl`.
- **Rigorous validation** — requests are validated before anything touches AWS
  or Postgres; the upgrade path is verified against RDS; risky extensions
  block the run; parameters absent from the target family are skipped with a
  warning; post-upgrade checks compare both the RDS API and live SQL versions.
- **SSO-aware** — expired sessions trigger `aws sso login --profile <name>`
  automatically, with its output streamed into the run log. Leave the profile
  blank to use the default credential chain.

## Build & run

```sh
cd gopgvanilla
go build -o gopgvanilla .
./gopgvanilla                  # listens on http://127.0.0.1:8090
./gopgvanilla -addr 127.0.0.1:9000 -log-dir /var/log/gopgvanilla
```

Open the URL, fill in the form (AWS profile/region, endpoint host, DB
credentials, target version), pick a mode, and press **Start run**. Steps
appear in the middle panel; approve each one as it comes up. Start with
**Dry run** — it is read-only and shows the exact snapshot and parameter-group
names an upgrade would create.

## HTTP API

| Endpoint   | Method | Purpose                                            |
|------------|--------|----------------------------------------------------|
| `/`        | GET    | Web UI                                             |
| `/run`     | POST   | Start a run (JSON request; 409 if one is running)  |
| `/approve` | POST   | `{"approve": true|false}` — resolve the pending gate |
| `/cancel`  | POST   | Cancel the in-flight run                           |
| `/state`   | GET    | Run + step states (used by the UI on reload)       |
| `/logs`    | GET    | SSE stream of all events                           |

## Layout

```
main.go                       flags, wiring, HTTP listener
internal/runlog/              event bus: SSE fan-out + JSONL audit sink
internal/awsx/                AWS config loading with `aws sso login` fallback
internal/server/              HTTP handlers + embedded web UI
internal/upgrade/
  types.go                    request, validation, modes, step definitions
  orchestrator.go             step engine with interactive approval gates
  rds.go                      discovery, snapshots, parameter groups, upgrade, waiters
  pg.go                       Postgres queries (databases, extensions, ALTER EXTENSION)
  extensions.go               extension risk classification table
```

Ported from `../pgupgrade` (Python, boto3/psycopg2); UI and serving model from
`../bggo`.

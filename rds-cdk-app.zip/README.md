# AWS RDS PostgreSQL CDK Application

A comprehensive, modular AWS CDK TypeScript application for deploying various RDS PostgreSQL configurations with extension management and upgrade capabilities.

## Features

- **Multiple Deployment Types**:
  - Single Instance PostgreSQL (dev/test)
  - Multi-AZ Instance (production HA)
  - Multi-AZ DB Cluster (highest availability)
  - Aurora PostgreSQL (cloud-native, serverless option)

- **Extension Management**:
  - Required extensions auto-installed
  - Optional extensions configurable
  - Shared preload libraries auto-configured
  - Version compatibility validation

- **Database Upgrades**:
  - Minor and major version upgrades
  - Pre-upgrade snapshot creation
  - Upgrade path validation
  - Progress monitoring

- **Best Practices**:
  - Modular, object-oriented design
  - Factory pattern for deployment types
  - Strong TypeScript typing
  - Comprehensive error handling

## Prerequisites

- Node.js 18+
- AWS CDK CLI
- AWS credentials configured
- TypeScript 5.0+

## Installation

```bash
# Clone or create the project
cd rds-cdk-app

# Install dependencies
npm install

# Bootstrap CDK (first time only)
npx cdk bootstrap
```

## Project Structure

```
rds-cdk-app/
├── bin/
│   └── app.ts                    # CDK app entry point
├── lib/
│   ├── index.ts                  # Main exports
│   ├── rds-postgres-stack.ts     # Main stack
│   ├── types/
│   │   └── index.ts              # TypeScript interfaces
│   ├── config/
│   │   ├── extensions.ts         # Extension definitions
│   │   └── defaults.ts           # Default configurations
│   ├── constructs/
│   │   ├── base-rds-construct.ts      # Abstract base class
│   │   ├── single-instance-postgres.ts
│   │   ├── multi-az-instance-postgres.ts
│   │   ├── multi-az-cluster-postgres.ts
│   │   ├── aurora-postgres.ts
│   │   └── rds-factory.ts        # Factory pattern
│   └── utils/
│       └── helpers.ts            # Utility functions
├── scripts/
│   └── upgrade-database.ts       # Database upgrade script
├── package.json
├── tsconfig.json
└── cdk.json
```

## Usage

### Deploy Single Instance (Development)

```bash
# Using environment variables
export DEPLOYMENT_TYPE=SINGLE_INSTANCE
export ENVIRONMENT=dev
export DATABASE_NAME=mydb
npx cdk deploy

# Using CDK context
npx cdk deploy -c deploymentType=SINGLE_INSTANCE -c environment=dev
```

### Deploy Multi-AZ Instance (Production)

```bash
npx cdk deploy \
  -c deploymentType=MULTI_AZ_INSTANCE \
  -c environment=prod
```

### Deploy Multi-AZ Cluster

```bash
npx cdk deploy \
  -c deploymentType=MULTI_AZ_CLUSTER \
  -c environment=prod
```

### Deploy Aurora PostgreSQL

```bash
# Provisioned Aurora
npx cdk deploy \
  -c deploymentType=AURORA_POSTGRES \
  -c environment=prod

# Serverless v2 Aurora
export AURORA_SERVERLESS=true
export AURORA_MIN_CAPACITY=0.5
export AURORA_MAX_CAPACITY=16
npx cdk deploy -c deploymentType=AURORA_POSTGRES
```

### Deploy with Extensions

```bash
# Via environment variable
export OPTIONAL_EXTENSIONS=postgis,pgvector,pg_cron
npx cdk deploy

# Via CDK context
npx cdk deploy -c extensions='["postgis","pgvector","pg_cron"]'
```

### Use Existing VPC

```bash
export VPC_ID=vpc-12345678
npx cdk deploy
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DEPLOYMENT_TYPE` | Deployment type | `SINGLE_INSTANCE` |
| `ENVIRONMENT` | Environment name | `dev` |
| `DATABASE_NAME` | Database name | `appdb` |
| `POSTGRES_VERSION` | PostgreSQL version | `16.4` |
| `VPC_ID` | Existing VPC ID | (creates new) |
| `OPTIONAL_EXTENSIONS` | Comma-separated extensions | (none) |
| `AURORA_SERVERLESS` | Enable serverless v2 | `false` |
| `AURORA_MIN_CAPACITY` | Min ACU for serverless | `0.5` |
| `AURORA_MAX_CAPACITY` | Max ACU for serverless | `16` |
| `AURORA_READER_INSTANCES` | Number of readers | `1` |

### Deployment Types

| Type | Description | Use Case |
|------|-------------|----------|
| `SINGLE_INSTANCE` | Single AZ instance | Development, testing |
| `MULTI_AZ_INSTANCE` | Multi-AZ with standby | Production, standard HA |
| `MULTI_AZ_CLUSTER` | Multi-AZ with readable standbys | Highest availability |
| `AURORA_POSTGRES` | Aurora cluster | Cloud-native, auto-scaling |

### Required Extensions (Always Installed)

- `pg_stat_statements` - Query statistics
- `pgcrypto` - Cryptographic functions
- `uuid-ossp` - UUID generation
- `plpgsql` - PL/pgSQL procedural language

### Available Optional Extensions

#### Performance & Monitoring
- `pg_hint_plan` - Query plan hints
- `auto_explain` - Auto-log slow queries
- `pg_prewarm` - Buffer cache prewarming
- `pg_buffercache` - Buffer cache inspection

#### Data Types
- `hstore` - Key-value pairs
- `ltree` - Hierarchical trees
- `citext` - Case-insensitive text
- `intarray` - Integer array functions

#### Text Search
- `pg_trgm` - Trigram matching
- `unaccent` - Remove accents
- `fuzzystrmatch` - String similarity

#### Geographic
- `postgis` - Spatial objects
- `postgis_topology` - Topology types

#### AI/ML
- `pgvector` - Vector similarity search

#### AWS Integration
- `aws_commons` - AWS common functions
- `aws_s3` - S3 import/export
- `aws_lambda` - Lambda invocation

#### Audit & Security
- `pgaudit` - Audit logging
- `pg_cron` - Job scheduler

## Database Upgrades

### Upgrade Script Usage

```bash
# Minor version upgrade
npx ts-node scripts/upgrade-database.ts \
  --identifier my-database \
  --target-version 16.4

# Major version upgrade with snapshot
npx ts-node scripts/upgrade-database.ts \
  --identifier my-database \
  --target-version 16.4 \
  --allow-major-upgrade \
  --create-snapshot \
  --apply-immediately

# Dry run (validate only)
npx ts-node scripts/upgrade-database.ts \
  --identifier my-database \
  --target-version 16.4 \
  --dry-run
```

### Upgrade Options

| Option | Description |
|--------|-------------|
| `--identifier, -i` | Database identifier (required) |
| `--target-version, -v` | Target version (required) |
| `--region, -r` | AWS region |
| `--apply-immediately` | Apply now vs maintenance window |
| `--create-snapshot` | Create pre-upgrade snapshot |
| `--snapshot-id` | Custom snapshot identifier |
| `--allow-major-upgrade` | Enable major version upgrades |
| `--dry-run` | Validate without changes |

### Supported Upgrade Paths

- PostgreSQL 12 → 13, 14, 15, 16
- PostgreSQL 13 → 14, 15, 16
- PostgreSQL 14 → 15, 16
- PostgreSQL 15 → 16

## Programmatic Usage

```typescript
import { 
  RdsPostgresStack,
  RdsDeploymentType,
  createDefaultExtensionConfig,
} from 'rds-cdk-app';

const app = new cdk.App();

// Create extension configuration
const extensions = createDefaultExtensionConfig([
  'postgis',
  'pgvector',
  'pg_cron',
]);

// Create stack
new RdsPostgresStack(app, 'MyDatabase', {
  config: {
    stackName: 'my-postgres-db',
    deploymentType: RdsDeploymentType.AURORA_POSTGRES,
    rdsProps: {
      environment: 'prod',
      databaseName: 'myapp',
      postgresVersion: '16.4',
      vpc: myVpc,
      extensions,
      serverlessV2: true,
      minCapacity: 0.5,
      maxCapacity: 32,
    },
  },
});
```

## CDK Commands

```bash
# Synthesize CloudFormation template
npx cdk synth

# Compare deployed stack with local
npx cdk diff

# Deploy stack
npx cdk deploy

# Destroy stack
npx cdk destroy

# List stacks
npx cdk list
```

## Security Considerations

- All databases are deployed in private subnets
- Storage encryption enabled by default
- Deletion protection enabled for production
- IAM authentication supported
- Security groups restrict access
- Enhanced monitoring enabled
- Performance Insights enabled
- CloudWatch logs exported

## Cost Optimization

### Development
- Use `SINGLE_INSTANCE` deployment
- T3 instance family
- Minimal storage (50GB)
- Short backup retention (7 days)

### Production
- Use Multi-AZ or Aurora
- Reserved instances for predictable workloads
- Aurora Serverless for variable workloads
- Enable storage autoscaling

## Troubleshooting

### Common Issues

1. **VPC not found**
   - Ensure VPC_ID is correct
   - Check AWS region matches

2. **Extension not available**
   - Verify PostgreSQL version compatibility
   - Check AWS RDS extension support

3. **Upgrade failed**
   - Check upgrade path validity
   - Review RDS event logs
   - Ensure sufficient storage for upgrade

4. **Permission denied**
   - Verify AWS credentials
   - Check IAM permissions for RDS operations

## License

MIT

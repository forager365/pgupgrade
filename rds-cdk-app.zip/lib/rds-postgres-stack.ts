/**
 * RDS PostgreSQL Stack
 * Main CDK stack for deploying RDS PostgreSQL databases
 */

import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { 
  RdsDeploymentType, 
  RdsStackConfig, 
  BaseRdsProps, 
  AuroraPostgresProps, 
  MultiAzClusterProps,
  RdsConstructOutput 
} from './types';
import { 
  RdsFactory, 
  BaseRdsConstruct,
  SingleInstancePostgres,
  MultiAzInstancePostgres,
  MultiAzClusterPostgres,
  AuroraPostgres 
} from './constructs';
import { applyTags, generateTags } from './utils/helpers';

/**
 * Stack properties
 */
export interface RdsPostgresStackProps extends cdk.StackProps {
  /** Stack configuration */
  config: RdsStackConfig;
  /** Existing VPC to use (optional - will create new if not provided) */
  existingVpc?: ec2.IVpc;
  /** VPC ID to look up (optional) */
  vpcId?: string;
}

/**
 * RDS PostgreSQL Stack
 * Creates VPC (if needed) and deploys the configured RDS database
 */
export class RdsPostgresStack extends cdk.Stack {
  /** The VPC containing the database */
  public readonly vpc: ec2.IVpc;
  
  /** The RDS construct */
  public readonly database: BaseRdsConstruct;
  
  /** Output information */
  public readonly output: RdsConstructOutput;

  constructor(scope: Construct, id: string, props: RdsPostgresStackProps) {
    super(scope, id, props);
    
    const { config, existingVpc, vpcId } = props;
    
    // Get or create VPC
    this.vpc = this.getOrCreateVpc(existingVpc, vpcId);
    
    // Update props with VPC
    const rdsProps = {
      ...config.rdsProps,
      vpc: this.vpc,
    };
    
    // Validate configuration
    const validation = RdsFactory.validateConfig({
      deploymentType: config.deploymentType,
      props: rdsProps,
    });
    
    if (!validation.valid) {
      throw new Error(`Invalid configuration: ${validation.errors.join(', ')}`);
    }
    
    // Create the database using factory
    this.database = RdsFactory.create(this, 'Database', {
      deploymentType: config.deploymentType,
      props: rdsProps,
    });
    
    // Get output
    this.output = this.database.getOutput();
    
    // Apply stack-level tags
    const tags = generateTags(
      config.rdsProps.environment, 
      config.deploymentType,
      config.rdsProps.tags
    );
    applyTags(this, tags);
    
    // Create stack outputs
    this.createStackOutputs(config);
  }

  /**
   * Get existing VPC or create a new one
   */
  private getOrCreateVpc(existingVpc?: ec2.IVpc, vpcId?: string): ec2.IVpc {
    if (existingVpc) {
      return existingVpc;
    }
    
    if (vpcId) {
      return ec2.Vpc.fromLookup(this, 'Vpc', { vpcId });
    }
    
    // Create a new VPC suitable for RDS
    return new ec2.Vpc(this, 'Vpc', {
      maxAzs: 3,
      natGateways: 1,
      subnetConfiguration: [
        {
          name: 'Public',
          subnetType: ec2.SubnetType.PUBLIC,
          cidrMask: 24,
        },
        {
          name: 'Private',
          subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
          cidrMask: 24,
        },
        {
          name: 'Database',
          subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
          cidrMask: 24,
        },
      ],
    });
  }

  /**
   * Create CloudFormation stack outputs
   */
  private createStackOutputs(config: RdsStackConfig): void {
    new cdk.CfnOutput(this, 'DeploymentType', {
      value: config.deploymentType,
      description: 'RDS deployment type',
    });
    
    new cdk.CfnOutput(this, 'PostgresVersion', {
      value: config.rdsProps.postgresVersion,
      description: 'PostgreSQL version',
    });
    
    new cdk.CfnOutput(this, 'Environment', {
      value: config.rdsProps.environment,
      description: 'Deployment environment',
    });
    
    new cdk.CfnOutput(this, 'VpcId', {
      value: this.vpc.vpcId,
      description: 'VPC ID',
    });
    
    // Add reader endpoint for cluster deployments
    if (config.deploymentType === RdsDeploymentType.AURORA_POSTGRES) {
      const aurora = this.database as AuroraPostgres;
      new cdk.CfnOutput(this, 'ReaderEndpoint', {
        value: aurora.readerEndpoint,
        description: 'Aurora reader endpoint',
      });
    } else if (config.deploymentType === RdsDeploymentType.MULTI_AZ_CLUSTER) {
      const cluster = this.database as MultiAzClusterPostgres;
      new cdk.CfnOutput(this, 'ReaderEndpoint', {
        value: cluster.readerEndpoint,
        description: 'Cluster reader endpoint',
      });
    }
  }

  /**
   * Allow access from a CIDR range
   */
  public allowFromCidr(cidr: string, description?: string): void {
    this.database.allowFrom(ec2.Peer.ipv4(cidr), description);
  }

  /**
   * Allow access from another security group
   */
  public allowFromSecurityGroup(sg: ec2.ISecurityGroup, description?: string): void {
    this.database.allowFromSecurityGroup(sg, description);
  }

  /**
   * Get the database as specific type
   */
  public getAsSingleInstance(): SingleInstancePostgres {
    if (!(this.database instanceof SingleInstancePostgres)) {
      throw new Error('Database is not a SingleInstancePostgres');
    }
    return this.database;
  }

  public getAsMultiAzInstance(): MultiAzInstancePostgres {
    if (!(this.database instanceof MultiAzInstancePostgres)) {
      throw new Error('Database is not a MultiAzInstancePostgres');
    }
    return this.database;
  }

  public getAsMultiAzCluster(): MultiAzClusterPostgres {
    if (!(this.database instanceof MultiAzClusterPostgres)) {
      throw new Error('Database is not a MultiAzClusterPostgres');
    }
    return this.database;
  }

  public getAsAurora(): AuroraPostgres {
    if (!(this.database instanceof AuroraPostgres)) {
      throw new Error('Database is not an AuroraPostgres');
    }
    return this.database;
  }
}

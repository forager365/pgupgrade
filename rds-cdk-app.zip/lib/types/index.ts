/**
 * RDS CDK Application Types
 * Defines all interfaces, enums, and type definitions for the RDS deployment
 */

import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';

/**
 * Supported RDS deployment types
 */
export enum RdsDeploymentType {
  /** Single instance RDS PostgreSQL */
  SINGLE_INSTANCE = 'SINGLE_INSTANCE',
  /** Multi-AZ instance deployment (standby replica) */
  MULTI_AZ_INSTANCE = 'MULTI_AZ_INSTANCE',
  /** Multi-AZ cluster deployment (readable standbys) */
  MULTI_AZ_CLUSTER = 'MULTI_AZ_CLUSTER',
  /** Aurora PostgreSQL cluster */
  AURORA_POSTGRES = 'AURORA_POSTGRES',
}

/**
 * PostgreSQL extension categories
 */
export enum ExtensionCategory {
  REQUIRED = 'REQUIRED',
  OPTIONAL = 'OPTIONAL',
}

/**
 * PostgreSQL extension definition
 */
export interface PostgresExtension {
  name: string;
  category: ExtensionCategory;
  description: string;
  /** Minimum PostgreSQL version required */
  minVersion?: string;
  /** Whether extension requires shared_preload_libraries */
  requiresPreload?: boolean;
  /** Library name for shared_preload_libraries if different from extension name */
  preloadLibrary?: string;
}

/**
 * Extension configuration for the database
 */
export interface ExtensionConfig {
  /** List of required extensions (always installed) */
  requiredExtensions: string[];
  /** List of optional extensions to install */
  optionalExtensions: string[];
}

/**
 * Base properties for all RDS constructs
 */
export interface BaseRdsProps {
  /** Environment name (e.g., dev, staging, prod) */
  environment: string;
  /** VPC for the database */
  vpc: ec2.IVpc;
  /** Database name */
  databaseName: string;
  /** Master username */
  masterUsername?: string;
  /** PostgreSQL engine version */
  postgresVersion: string;
  /** Instance class for the database */
  instanceClass?: ec2.InstanceClass;
  /** Instance size for the database */
  instanceSize?: ec2.InstanceSize;
  /** Allocated storage in GB */
  allocatedStorage?: number;
  /** Maximum allocated storage in GB for autoscaling */
  maxAllocatedStorage?: number;
  /** Enable deletion protection */
  deletionProtection?: boolean;
  /** Backup retention period in days */
  backupRetentionDays?: number;
  /** Preferred backup window */
  preferredBackupWindow?: string;
  /** Preferred maintenance window */
  preferredMaintenanceWindow?: string;
  /** Enable storage encryption */
  storageEncrypted?: boolean;
  /** Enable enhanced monitoring */
  enableEnhancedMonitoring?: boolean;
  /** Enhanced monitoring interval in seconds */
  monitoringInterval?: number;
  /** Enable Performance Insights */
  enablePerformanceInsights?: boolean;
  /** Performance Insights retention period in days */
  performanceInsightsRetention?: number;
  /** Extension configuration */
  extensions?: ExtensionConfig;
  /** Additional parameter group settings */
  parameterOverrides?: Record<string, string>;
  /** Security groups to attach */
  securityGroups?: ec2.ISecurityGroup[];
  /** Subnet selection for database placement */
  vpcSubnets?: ec2.SubnetSelection;
  /** Enable auto minor version upgrade */
  autoMinorVersionUpgrade?: boolean;
  /** Enable multi-AZ for single instance */
  multiAz?: boolean;
  /** Storage type */
  storageType?: rds.StorageType;
  /** IOPS for io1/io2 storage */
  iops?: number;
  /** Storage throughput for gp3 storage */
  storageThroughput?: number;
  /** Tags to apply to resources */
  tags?: Record<string, string>;
}

/**
 * Props specific to Aurora PostgreSQL
 */
export interface AuroraPostgresProps extends BaseRdsProps {
  /** Number of reader instances */
  readerInstances?: number;
  /** Enable serverless v2 */
  serverlessV2?: boolean;
  /** Minimum ACU for serverless */
  minCapacity?: number;
  /** Maximum ACU for serverless */
  maxCapacity?: number;
  /** Enable global database */
  enableGlobalDatabase?: boolean;
}

/**
 * Props specific to Multi-AZ Cluster
 */
export interface MultiAzClusterProps extends BaseRdsProps {
  /** Instance class for cluster (must be db.m5d or db.r5d family) */
  clusterInstanceClass?: string;
  /** IOPS for the cluster (required for Multi-AZ cluster) */
  clusterIops?: number;
  /** Storage type for cluster (must be io1 or io2) */
  clusterStorageType?: 'io1' | 'io2';
}

/**
 * Main stack configuration
 */
export interface RdsStackConfig {
  /** Stack name */
  stackName: string;
  /** Deployment type */
  deploymentType: RdsDeploymentType;
  /** Base RDS properties */
  rdsProps: BaseRdsProps | AuroraPostgresProps | MultiAzClusterProps;
  /** AWS account */
  account?: string;
  /** AWS region */
  region?: string;
}

/**
 * Database upgrade configuration
 */
export interface DatabaseUpgradeConfig {
  /** Database identifier */
  dbIdentifier: string;
  /** Target PostgreSQL version */
  targetVersion: string;
  /** Whether to apply immediately or during maintenance window */
  applyImmediately?: boolean;
  /** Allow major version upgrade */
  allowMajorVersionUpgrade?: boolean;
  /** Pre-upgrade snapshot identifier */
  snapshotIdentifier?: string;
  /** Deployment type of the database */
  deploymentType: RdsDeploymentType;
  /** AWS region */
  region?: string;
}

/**
 * Output from RDS construct
 */
export interface RdsConstructOutput {
  /** Database endpoint */
  endpoint: string;
  /** Database port */
  port: number;
  /** Secret ARN for credentials */
  secretArn: string;
  /** Security group ID */
  securityGroupId: string;
  /** Database identifier */
  dbIdentifier: string;
}

/**
 * Parameter group configuration
 */
export interface ParameterGroupConfig {
  /** Parameter group family */
  family: string;
  /** Parameters to set */
  parameters: Record<string, string>;
  /** Description */
  description?: string;
}

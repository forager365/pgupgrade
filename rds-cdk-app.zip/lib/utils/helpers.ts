/**
 * Utility Helper Functions
 */

import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { RdsDeploymentType, BaseRdsProps } from '../types';
import { RDS_DEFAULTS } from '../config/defaults';

/**
 * Generate a consistent resource name
 */
export function generateResourceName(
  environment: string,
  component: string,
  suffix?: string
): string {
  const parts = [environment, component];
  if (suffix) {
    parts.push(suffix);
  }
  return parts.join('-').toLowerCase();
}

/**
 * Generate tags for resources
 */
export function generateTags(
  environment: string,
  deploymentType: RdsDeploymentType,
  additionalTags?: Record<string, string>
): Record<string, string> {
  return {
    Environment: environment,
    DeploymentType: deploymentType,
    ManagedBy: 'CDK',
    Application: 'RDS-PostgreSQL',
    ...additionalTags,
  };
}

/**
 * Apply tags to a construct
 */
export function applyTags(construct: Construct, tags: Record<string, string>): void {
  for (const [key, value] of Object.entries(tags)) {
    cdk.Tags.of(construct).add(key, value);
  }
}

/**
 * Create subnet selection for database
 */
export function createDatabaseSubnetSelection(
  vpc: ec2.IVpc,
  useIsolatedSubnets: boolean = true
): ec2.SubnetSelection {
  if (useIsolatedSubnets) {
    // Prefer isolated subnets for databases
    try {
      const isolated = vpc.selectSubnets({ subnetType: ec2.SubnetType.PRIVATE_ISOLATED });
      if (isolated.subnets.length > 0) {
        return { subnetType: ec2.SubnetType.PRIVATE_ISOLATED };
      }
    } catch {
      // Isolated subnets not available
    }
  }
  
  // Fall back to private subnets with egress
  try {
    const privateWithEgress = vpc.selectSubnets({ subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS });
    if (privateWithEgress.subnets.length > 0) {
      return { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS };
    }
  } catch {
    // Private with egress not available
  }
  
  // Last resort: private subnets (legacy type)
  return { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS };
}

/**
 * Validate RDS props
 */
export function validateRdsProps(props: BaseRdsProps): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!props.vpc) {
    errors.push('VPC is required');
  }

  if (!props.databaseName) {
    errors.push('Database name is required');
  }

  if (!props.postgresVersion) {
    errors.push('PostgreSQL version is required');
  }

  if (props.allocatedStorage && props.allocatedStorage < 20) {
    errors.push('Allocated storage must be at least 20 GB');
  }

  if (props.maxAllocatedStorage && props.allocatedStorage) {
    if (props.maxAllocatedStorage < props.allocatedStorage) {
      errors.push('Max allocated storage must be greater than or equal to allocated storage');
    }
  }

  if (props.backupRetentionDays !== undefined) {
    if (props.backupRetentionDays < 0 || props.backupRetentionDays > 35) {
      errors.push('Backup retention days must be between 0 and 35');
    }
  }

  if (props.monitoringInterval !== undefined) {
    const validIntervals = [0, 1, 5, 10, 15, 30, 60];
    if (!validIntervals.includes(props.monitoringInterval)) {
      errors.push(`Monitoring interval must be one of: ${validIntervals.join(', ')}`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Merge props with defaults
 */
export function mergeWithDefaults<T extends BaseRdsProps>(props: Partial<T>): T {
  return {
    ...props,
    masterUsername: props.masterUsername ?? RDS_DEFAULTS.masterUsername,
    allocatedStorage: props.allocatedStorage ?? RDS_DEFAULTS.allocatedStorage,
    maxAllocatedStorage: props.maxAllocatedStorage ?? RDS_DEFAULTS.maxAllocatedStorage,
    backupRetentionDays: props.backupRetentionDays ?? RDS_DEFAULTS.backupRetentionDays,
    preferredBackupWindow: props.preferredBackupWindow ?? RDS_DEFAULTS.preferredBackupWindow,
    preferredMaintenanceWindow: props.preferredMaintenanceWindow ?? RDS_DEFAULTS.preferredMaintenanceWindow,
    storageEncrypted: props.storageEncrypted ?? true,
    enableEnhancedMonitoring: props.enableEnhancedMonitoring ?? true,
    monitoringInterval: props.monitoringInterval ?? RDS_DEFAULTS.monitoringInterval,
    enablePerformanceInsights: props.enablePerformanceInsights ?? true,
    performanceInsightsRetention: props.performanceInsightsRetention ?? RDS_DEFAULTS.performanceInsightsRetention,
    deletionProtection: props.deletionProtection ?? (props.environment === 'prod'),
    autoMinorVersionUpgrade: props.autoMinorVersionUpgrade ?? true,
    instanceClass: props.instanceClass ?? RDS_DEFAULTS.instanceClass,
    instanceSize: props.instanceSize ?? RDS_DEFAULTS.instanceSize,
    storageType: props.storageType ?? RDS_DEFAULTS.storageType,
  } as T;
}

/**
 * Format duration for display
 */
export function formatDuration(seconds: number): string {
  if (seconds < 60) {
    return `${seconds}s`;
  }
  if (seconds < 3600) {
    return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
  }
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}h ${minutes}m`;
}

/**
 * Parse time window string (HH:MM-HH:MM format)
 */
export function parseTimeWindow(window: string): { start: string; end: string } {
  const parts = window.split('-');
  if (parts.length !== 2) {
    throw new Error(`Invalid time window format: ${window}. Expected HH:MM-HH:MM`);
  }
  return {
    start: parts[0],
    end: parts[1],
  };
}

/**
 * Validate maintenance window format
 */
export function validateMaintenanceWindow(window: string): boolean {
  // Format: ddd:HH:MM-ddd:HH:MM (e.g., sun:04:00-sun:05:00)
  const pattern = /^(mon|tue|wed|thu|fri|sat|sun):\d{2}:\d{2}-(mon|tue|wed|thu|fri|sat|sun):\d{2}:\d{2}$/i;
  return pattern.test(window);
}

/**
 * Validate backup window format
 */
export function validateBackupWindow(window: string): boolean {
  // Format: HH:MM-HH:MM (e.g., 03:00-04:00)
  const pattern = /^\d{2}:\d{2}-\d{2}:\d{2}$/;
  return pattern.test(window);
}

/**
 * Convert camelCase to kebab-case
 */
export function toKebabCase(str: string): string {
  return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
}

/**
 * Sleep utility for async operations
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retry utility for operations that may fail
 */
export async function retry<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 1000,
  backoffMultiplier: number = 2
): Promise<T> {
  let lastError: Error | undefined;
  let currentDelay = delayMs;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxRetries) {
        console.log(`Attempt ${attempt} failed, retrying in ${currentDelay}ms...`);
        await sleep(currentDelay);
        currentDelay *= backoffMultiplier;
      }
    }
  }

  throw lastError;
}

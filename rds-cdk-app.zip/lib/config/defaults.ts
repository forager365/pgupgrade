/**
 * Default Configuration Values
 * Provides sensible defaults for RDS deployments
 */

import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import { RdsDeploymentType } from '../types';

/**
 * Default values for RDS configuration
 */
export const RDS_DEFAULTS = {
  /** Default PostgreSQL version */
  postgresVersion: '16.4',
  
  /** Default master username */
  masterUsername: 'dbadmin',
  
  /** Default database name */
  databaseName: 'appdb',
  
  /** Default instance class */
  instanceClass: ec2.InstanceClass.T3,
  
  /** Default instance size */
  instanceSize: ec2.InstanceSize.MEDIUM,
  
  /** Default allocated storage in GB */
  allocatedStorage: 100,
  
  /** Default max allocated storage in GB */
  maxAllocatedStorage: 500,
  
  /** Default backup retention days */
  backupRetentionDays: 7,
  
  /** Default backup window (UTC) */
  preferredBackupWindow: '03:00-04:00',
  
  /** Default maintenance window (UTC) */
  preferredMaintenanceWindow: 'sun:04:00-sun:05:00',
  
  /** Default monitoring interval in seconds */
  monitoringInterval: 60,
  
  /** Default Performance Insights retention in days */
  performanceInsightsRetention: 7,
  
  /** Default storage type */
  storageType: rds.StorageType.GP3,
  
  /** Default storage throughput for GP3 */
  storageThroughput: 125,
  
  /** Default port */
  port: 5432,
};

/**
 * Aurora-specific defaults
 */
export const AURORA_DEFAULTS = {
  /** Default number of reader instances */
  readerInstances: 1,
  
  /** Default minimum ACU for serverless v2 */
  minCapacity: 0.5,
  
  /** Default maximum ACU for serverless v2 */
  maxCapacity: 16,
  
  /** Default instance class for provisioned Aurora */
  instanceClass: ec2.InstanceClass.R6G,
  
  /** Default instance size for provisioned Aurora */
  instanceSize: ec2.InstanceSize.LARGE,
};

/**
 * Multi-AZ Cluster specific defaults
 */
export const MULTI_AZ_CLUSTER_DEFAULTS = {
  /** Default instance class for Multi-AZ cluster */
  clusterInstanceClass: 'db.m5d.large',
  
  /** Default IOPS for cluster */
  clusterIops: 3000,
  
  /** Default storage type (io1/io2 required) */
  clusterStorageType: 'io1' as const,
};

/**
 * PostgreSQL version mapping to RDS engine versions
 */
export const POSTGRES_VERSION_MAP: Record<string, rds.PostgresEngineVersion> = {
  '11': rds.PostgresEngineVersion.VER_11,
  '11.22': rds.PostgresEngineVersion.VER_11_22,
  '12': rds.PostgresEngineVersion.VER_12,
  '12.20': rds.PostgresEngineVersion.VER_12_20,
  '13': rds.PostgresEngineVersion.VER_13,
  '13.16': rds.PostgresEngineVersion.VER_13_16,
  '14': rds.PostgresEngineVersion.VER_14,
  '14.13': rds.PostgresEngineVersion.VER_14_13,
  '15': rds.PostgresEngineVersion.VER_15,
  '15.8': rds.PostgresEngineVersion.VER_15_8,
  '16': rds.PostgresEngineVersion.VER_16,
  '16.4': rds.PostgresEngineVersion.VER_16_4,
};

/**
 * Aurora PostgreSQL version mapping
 */
export const AURORA_POSTGRES_VERSION_MAP: Record<string, rds.AuroraPostgresEngineVersion> = {
  '11': rds.AuroraPostgresEngineVersion.VER_11_21,
  '11.21': rds.AuroraPostgresEngineVersion.VER_11_21,
  '12': rds.AuroraPostgresEngineVersion.VER_12_20,
  '12.20': rds.AuroraPostgresEngineVersion.VER_12_20,
  '13': rds.AuroraPostgresEngineVersion.VER_13_16,
  '13.16': rds.AuroraPostgresEngineVersion.VER_13_16,
  '14': rds.AuroraPostgresEngineVersion.VER_14_13,
  '14.13': rds.AuroraPostgresEngineVersion.VER_14_13,
  '15': rds.AuroraPostgresEngineVersion.VER_15_8,
  '15.8': rds.AuroraPostgresEngineVersion.VER_15_8,
  '16': rds.AuroraPostgresEngineVersion.VER_16_4,
  '16.4': rds.AuroraPostgresEngineVersion.VER_16_4,
};

/**
 * Get PostgreSQL engine version from string
 */
export function getPostgresEngineVersion(version: string): rds.PostgresEngineVersion {
  const mapped = POSTGRES_VERSION_MAP[version];
  if (mapped) {
    return mapped;
  }
  
  // Try to find major version match
  const majorVersion = version.split('.')[0];
  const majorMapped = POSTGRES_VERSION_MAP[majorVersion];
  if (majorMapped) {
    return majorMapped;
  }
  
  throw new Error(`Unsupported PostgreSQL version: ${version}. Supported versions: ${Object.keys(POSTGRES_VERSION_MAP).join(', ')}`);
}

/**
 * Get Aurora PostgreSQL engine version from string
 */
export function getAuroraPostgresEngineVersion(version: string): rds.AuroraPostgresEngineVersion {
  const mapped = AURORA_POSTGRES_VERSION_MAP[version];
  if (mapped) {
    return mapped;
  }
  
  // Try to find major version match
  const majorVersion = version.split('.')[0];
  const majorMapped = AURORA_POSTGRES_VERSION_MAP[majorVersion];
  if (majorMapped) {
    return majorMapped;
  }
  
  throw new Error(`Unsupported Aurora PostgreSQL version: ${version}. Supported versions: ${Object.keys(AURORA_POSTGRES_VERSION_MAP).join(', ')}`);
}

/**
 * Get parameter group family for PostgreSQL version
 */
export function getParameterGroupFamily(version: string, isAurora: boolean = false): string {
  const majorVersion = version.split('.')[0];
  if (isAurora) {
    return `aurora-postgresql${majorVersion}`;
  }
  return `postgres${majorVersion}`;
}

/**
 * Recommended instance sizes by deployment type and workload
 */
export const RECOMMENDED_INSTANCES: Record<RdsDeploymentType, Record<string, { class: ec2.InstanceClass; size: ec2.InstanceSize }>> = {
  [RdsDeploymentType.SINGLE_INSTANCE]: {
    development: { class: ec2.InstanceClass.T3, size: ec2.InstanceSize.MICRO },
    staging: { class: ec2.InstanceClass.T3, size: ec2.InstanceSize.SMALL },
    production: { class: ec2.InstanceClass.M6I, size: ec2.InstanceSize.LARGE },
    highPerformance: { class: ec2.InstanceClass.R6I, size: ec2.InstanceSize.XLARGE },
  },
  [RdsDeploymentType.MULTI_AZ_INSTANCE]: {
    development: { class: ec2.InstanceClass.T3, size: ec2.InstanceSize.SMALL },
    staging: { class: ec2.InstanceClass.T3, size: ec2.InstanceSize.MEDIUM },
    production: { class: ec2.InstanceClass.M6I, size: ec2.InstanceSize.LARGE },
    highPerformance: { class: ec2.InstanceClass.R6I, size: ec2.InstanceSize.XLARGE2 },
  },
  [RdsDeploymentType.MULTI_AZ_CLUSTER]: {
    development: { class: ec2.InstanceClass.M5D, size: ec2.InstanceSize.LARGE },
    staging: { class: ec2.InstanceClass.M5D, size: ec2.InstanceSize.LARGE },
    production: { class: ec2.InstanceClass.M5D, size: ec2.InstanceSize.XLARGE },
    highPerformance: { class: ec2.InstanceClass.R5D, size: ec2.InstanceSize.XLARGE2 },
  },
  [RdsDeploymentType.AURORA_POSTGRES]: {
    development: { class: ec2.InstanceClass.T3, size: ec2.InstanceSize.MEDIUM },
    staging: { class: ec2.InstanceClass.R6G, size: ec2.InstanceSize.LARGE },
    production: { class: ec2.InstanceClass.R6G, size: ec2.InstanceSize.XLARGE },
    highPerformance: { class: ec2.InstanceClass.R6G, size: ec2.InstanceSize.XLARGE2 },
  },
};

/**
 * Get recommended instance type for deployment
 */
export function getRecommendedInstance(
  deploymentType: RdsDeploymentType,
  workload: 'development' | 'staging' | 'production' | 'highPerformance' = 'production'
): { class: ec2.InstanceClass; size: ec2.InstanceSize } {
  return RECOMMENDED_INSTANCES[deploymentType][workload];
}

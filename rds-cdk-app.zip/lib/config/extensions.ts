/**
 * PostgreSQL Extensions Configuration
 * Defines all available PostgreSQL extensions with their metadata
 */

import { PostgresExtension, ExtensionCategory, ExtensionConfig } from '../types';

/**
 * Catalog of available PostgreSQL extensions
 */
export const POSTGRES_EXTENSIONS: PostgresExtension[] = [
  // Required Extensions
  {
    name: 'pg_stat_statements',
    category: ExtensionCategory.REQUIRED,
    description: 'Track execution statistics of all SQL statements',
    requiresPreload: true,
  },
  {
    name: 'pgcrypto',
    category: ExtensionCategory.REQUIRED,
    description: 'Cryptographic functions',
  },
  {
    name: 'uuid-ossp',
    category: ExtensionCategory.REQUIRED,
    description: 'Generate universally unique identifiers (UUIDs)',
  },

  // Optional Extensions - Performance & Monitoring
  {
    name: 'pg_hint_plan',
    category: ExtensionCategory.OPTIONAL,
    description: 'Control query execution plans with hints',
    requiresPreload: true,
  },
  {
    name: 'auto_explain',
    category: ExtensionCategory.OPTIONAL,
    description: 'Automatically log slow query execution plans',
    requiresPreload: true,
  },
  {
    name: 'pg_prewarm',
    category: ExtensionCategory.OPTIONAL,
    description: 'Preload relation data into buffer cache',
    requiresPreload: true,
  },
  {
    name: 'pg_buffercache',
    category: ExtensionCategory.OPTIONAL,
    description: 'Examine the shared buffer cache',
  },

  // Optional Extensions - Data Types
  {
    name: 'hstore',
    category: ExtensionCategory.OPTIONAL,
    description: 'Key-value pair data type',
  },
  {
    name: 'ltree',
    category: ExtensionCategory.OPTIONAL,
    description: 'Hierarchical tree-like data type',
  },
  {
    name: 'citext',
    category: ExtensionCategory.OPTIONAL,
    description: 'Case-insensitive character string type',
  },
  {
    name: 'cube',
    category: ExtensionCategory.OPTIONAL,
    description: 'Multi-dimensional cube data type',
  },
  {
    name: 'earthdistance',
    category: ExtensionCategory.OPTIONAL,
    description: 'Calculate great-circle distances on Earth',
  },
  {
    name: 'intarray',
    category: ExtensionCategory.OPTIONAL,
    description: 'Functions and operators for integer arrays',
  },
  {
    name: 'isn',
    category: ExtensionCategory.OPTIONAL,
    description: 'International Standard Numbers (ISBN, EAN, etc.)',
  },

  // Optional Extensions - Text Search & Processing
  {
    name: 'pg_trgm',
    category: ExtensionCategory.OPTIONAL,
    description: 'Trigram matching for similarity searching',
  },
  {
    name: 'unaccent',
    category: ExtensionCategory.OPTIONAL,
    description: 'Remove accents from text',
  },
  {
    name: 'fuzzystrmatch',
    category: ExtensionCategory.OPTIONAL,
    description: 'Determine similarities and distance between strings',
  },
  {
    name: 'dict_int',
    category: ExtensionCategory.OPTIONAL,
    description: 'Integer dictionary template for full text search',
  },
  {
    name: 'dict_xsyn',
    category: ExtensionCategory.OPTIONAL,
    description: 'Extended synonym dictionary for full text search',
  },

  // Optional Extensions - Indexing
  {
    name: 'btree_gin',
    category: ExtensionCategory.OPTIONAL,
    description: 'GIN operator classes for B-tree emulation',
  },
  {
    name: 'btree_gist',
    category: ExtensionCategory.OPTIONAL,
    description: 'GiST operator classes for B-tree emulation',
  },
  {
    name: 'bloom',
    category: ExtensionCategory.OPTIONAL,
    description: 'Bloom filter index access method',
  },

  // Optional Extensions - Foreign Data Wrappers
  {
    name: 'postgres_fdw',
    category: ExtensionCategory.OPTIONAL,
    description: 'Foreign data wrapper for PostgreSQL servers',
  },
  {
    name: 'file_fdw',
    category: ExtensionCategory.OPTIONAL,
    description: 'Foreign data wrapper for flat files',
  },
  {
    name: 'dblink',
    category: ExtensionCategory.OPTIONAL,
    description: 'Connect to other PostgreSQL databases',
  },

  // Optional Extensions - JSON
  {
    name: 'jsonb_plperl',
    category: ExtensionCategory.OPTIONAL,
    description: 'Transform between jsonb and plperl',
  },

  // Optional Extensions - Geographic
  {
    name: 'postgis',
    category: ExtensionCategory.OPTIONAL,
    description: 'Geographic objects and spatial queries',
    minVersion: '11',
  },
  {
    name: 'postgis_topology',
    category: ExtensionCategory.OPTIONAL,
    description: 'PostGIS topology spatial types and functions',
  },
  {
    name: 'postgis_tiger_geocoder',
    category: ExtensionCategory.OPTIONAL,
    description: 'PostGIS TIGER geocoder and reverse geocoder',
  },
  {
    name: 'address_standardizer',
    category: ExtensionCategory.OPTIONAL,
    description: 'Address parsing and normalization',
  },

  // Optional Extensions - Time Series
  {
    name: 'timescaledb',
    category: ExtensionCategory.OPTIONAL,
    description: 'Time-series database extension',
    requiresPreload: true,
    minVersion: '12',
  },

  // Optional Extensions - Audit & Security
  {
    name: 'pgaudit',
    category: ExtensionCategory.OPTIONAL,
    description: 'Audit logging for PostgreSQL',
    requiresPreload: true,
  },
  {
    name: 'pg_cron',
    category: ExtensionCategory.OPTIONAL,
    description: 'Job scheduler for PostgreSQL',
    requiresPreload: true,
    minVersion: '12',
  },

  // Optional Extensions - Replication & Logical Decoding
  {
    name: 'pglogical',
    category: ExtensionCategory.OPTIONAL,
    description: 'Logical replication for PostgreSQL',
    requiresPreload: true,
  },
  {
    name: 'wal2json',
    category: ExtensionCategory.OPTIONAL,
    description: 'JSON output for logical decoding',
  },

  // Optional Extensions - Utilities
  {
    name: 'tablefunc',
    category: ExtensionCategory.OPTIONAL,
    description: 'Functions for crosstab and pivot tables',
  },
  {
    name: 'pg_freespacemap',
    category: ExtensionCategory.OPTIONAL,
    description: 'Examine the free space map',
  },
  {
    name: 'pg_visibility',
    category: ExtensionCategory.OPTIONAL,
    description: 'Examine the visibility map',
  },
  {
    name: 'pageinspect',
    category: ExtensionCategory.OPTIONAL,
    description: 'Low-level inspection of database pages',
  },
  {
    name: 'amcheck',
    category: ExtensionCategory.OPTIONAL,
    description: 'Verify integrity of index structures',
  },

  // Optional Extensions - Partitioning
  {
    name: 'pg_partman',
    category: ExtensionCategory.OPTIONAL,
    description: 'Partition management extension',
    requiresPreload: true,
    preloadLibrary: 'pg_partman_bgw',
  },

  // Optional Extensions - AWS Specific
  {
    name: 'aws_commons',
    category: ExtensionCategory.OPTIONAL,
    description: 'AWS common library functions',
  },
  {
    name: 'aws_s3',
    category: ExtensionCategory.OPTIONAL,
    description: 'AWS S3 import/export functions',
  },
  {
    name: 'aws_lambda',
    category: ExtensionCategory.OPTIONAL,
    description: 'Invoke AWS Lambda functions',
  },

  // Optional Extensions - Vector Search (for AI/ML)
  {
    name: 'pgvector',
    category: ExtensionCategory.OPTIONAL,
    description: 'Vector similarity search',
    minVersion: '11',
  },

  // Optional Extensions - Procedural Languages
  {
    name: 'plpgsql',
    category: ExtensionCategory.REQUIRED,
    description: 'PL/pgSQL procedural language (default)',
  },
  {
    name: 'plperl',
    category: ExtensionCategory.OPTIONAL,
    description: 'PL/Perl procedural language',
  },
  {
    name: 'plperlu',
    category: ExtensionCategory.OPTIONAL,
    description: 'PL/Perl untrusted procedural language',
  },
  {
    name: 'pltcl',
    category: ExtensionCategory.OPTIONAL,
    description: 'PL/Tcl procedural language',
  },
];

/**
 * Get all required extensions
 */
export function getRequiredExtensions(): PostgresExtension[] {
  return POSTGRES_EXTENSIONS.filter(ext => ext.category === ExtensionCategory.REQUIRED);
}

/**
 * Get all optional extensions
 */
export function getOptionalExtensions(): PostgresExtension[] {
  return POSTGRES_EXTENSIONS.filter(ext => ext.category === ExtensionCategory.OPTIONAL);
}

/**
 * Get extension by name
 */
export function getExtension(name: string): PostgresExtension | undefined {
  return POSTGRES_EXTENSIONS.find(ext => ext.name === name);
}

/**
 * Get extensions that require shared_preload_libraries
 */
export function getPreloadExtensions(extensionNames: string[]): string[] {
  const preloadLibs: string[] = [];
  
  for (const name of extensionNames) {
    const ext = getExtension(name);
    if (ext?.requiresPreload) {
      preloadLibs.push(ext.preloadLibrary || ext.name);
    }
  }
  
  return [...new Set(preloadLibs)]; // Remove duplicates
}

/**
 * Validate extension configuration
 */
export function validateExtensions(
  config: ExtensionConfig,
  postgresVersion: string
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const allExtensions = [...config.requiredExtensions, ...config.optionalExtensions];
  const versionNumber = parseFloat(postgresVersion);

  for (const extName of allExtensions) {
    const ext = getExtension(extName);
    if (!ext) {
      errors.push(`Unknown extension: ${extName}`);
      continue;
    }
    
    if (ext.minVersion) {
      const minVer = parseFloat(ext.minVersion);
      if (versionNumber < minVer) {
        errors.push(
          `Extension '${extName}' requires PostgreSQL ${ext.minVersion}+, but version ${postgresVersion} specified`
        );
      }
    }
  }

  // Check for required extensions
  const requiredExtNames = getRequiredExtensions().map(e => e.name);
  for (const required of requiredExtNames) {
    if (!config.requiredExtensions.includes(required)) {
      errors.push(`Required extension '${required}' is missing from configuration`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Create default extension configuration with all required extensions
 */
export function createDefaultExtensionConfig(
  optionalExtensions: string[] = []
): ExtensionConfig {
  return {
    requiredExtensions: getRequiredExtensions().map(e => e.name),
    optionalExtensions,
  };
}

/**
 * Generate SQL statements to create extensions
 */
export function generateExtensionSql(config: ExtensionConfig): string {
  const allExtensions = [...config.requiredExtensions, ...config.optionalExtensions];
  const statements = allExtensions.map(ext => `CREATE EXTENSION IF NOT EXISTS "${ext}";`);
  return statements.join('\n');
}

/**
 * Get extension categories as readable strings for display
 */
export function getExtensionsByCategory(): Record<string, PostgresExtension[]> {
  const categories: Record<string, PostgresExtension[]> = {
    'Required': [],
    'Performance & Monitoring': [],
    'Data Types': [],
    'Text Search': [],
    'Indexing': [],
    'Foreign Data Wrappers': [],
    'Geographic': [],
    'Time Series': [],
    'Audit & Security': [],
    'Replication': [],
    'AWS Specific': [],
    'AI/ML': [],
    'Procedural Languages': [],
    'Utilities': [],
  };

  for (const ext of POSTGRES_EXTENSIONS) {
    if (ext.category === ExtensionCategory.REQUIRED) {
      categories['Required'].push(ext);
    } else if (['pg_stat_statements', 'pg_hint_plan', 'auto_explain', 'pg_prewarm', 'pg_buffercache'].includes(ext.name)) {
      categories['Performance & Monitoring'].push(ext);
    } else if (['hstore', 'ltree', 'citext', 'cube', 'earthdistance', 'intarray', 'isn'].includes(ext.name)) {
      categories['Data Types'].push(ext);
    } else if (['pg_trgm', 'unaccent', 'fuzzystrmatch', 'dict_int', 'dict_xsyn'].includes(ext.name)) {
      categories['Text Search'].push(ext);
    } else if (['btree_gin', 'btree_gist', 'bloom'].includes(ext.name)) {
      categories['Indexing'].push(ext);
    } else if (['postgres_fdw', 'file_fdw', 'dblink'].includes(ext.name)) {
      categories['Foreign Data Wrappers'].push(ext);
    } else if (['postgis', 'postgis_topology', 'postgis_tiger_geocoder', 'address_standardizer'].includes(ext.name)) {
      categories['Geographic'].push(ext);
    } else if (['timescaledb'].includes(ext.name)) {
      categories['Time Series'].push(ext);
    } else if (['pgaudit', 'pg_cron'].includes(ext.name)) {
      categories['Audit & Security'].push(ext);
    } else if (['pglogical', 'wal2json'].includes(ext.name)) {
      categories['Replication'].push(ext);
    } else if (['aws_commons', 'aws_s3', 'aws_lambda'].includes(ext.name)) {
      categories['AWS Specific'].push(ext);
    } else if (['pgvector'].includes(ext.name)) {
      categories['AI/ML'].push(ext);
    } else if (['plpgsql', 'plperl', 'plperlu', 'pltcl'].includes(ext.name)) {
      categories['Procedural Languages'].push(ext);
    } else {
      categories['Utilities'].push(ext);
    }
  }

  return categories;
}

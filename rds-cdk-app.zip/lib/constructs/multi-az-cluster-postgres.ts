/**
 * Multi-AZ Cluster PostgreSQL Construct
 * Deploys a Multi-AZ DB Cluster with readable standby instances using CfnDBCluster
 */

import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';
import { BaseRdsConstruct } from './base-rds-construct';
import { MultiAzClusterProps, RdsDeploymentType } from '../types';
import { 
  getPostgresEngineVersion, 
  RDS_DEFAULTS, 
  MULTI_AZ_CLUSTER_DEFAULTS 
} from '../config/defaults';
import { generateResourceName } from '../utils/helpers';

/**
 * Multi-AZ DB Cluster PostgreSQL Construct
 * Creates a highly available PostgreSQL cluster with:
 * - One writer instance
 * - Two readable standby instances across different AZs
 * - Synchronous replication for high durability
 * - Fast failover (typically under 35 seconds)
 * 
 * Note: Uses CfnDBCluster as CDK L2 doesn't fully support Multi-AZ DB Clusters
 */
export class MultiAzClusterPostgres extends BaseRdsConstruct {
  /** The RDS database cluster (L1 construct) */
  public readonly cfnCluster: rds.CfnDBCluster;
  
  /** Database secret */
  public readonly secret: rds.DatabaseSecret;
  
  /** Writer endpoint */
  public readonly endpoint: string;
  
  /** Reader endpoint */
  public readonly readerEndpoint: string;
  
  /** Database port */
  public readonly port: number;
  
  /** Database identifier */
  public readonly dbIdentifier: string;

  constructor(scope: Construct, id: string, props: MultiAzClusterProps) {
    super(scope, id, props);
    
    this.dbIdentifier = generateResourceName(props.environment, 'postgres', 'maz-cluster');
    
    // Create database secret
    this.secret = new rds.DatabaseSecret(this, 'Secret', {
      username: props.masterUsername ?? RDS_DEFAULTS.masterUsername,
      secretName: `${this.resourcePrefix}/credentials`,
    });
    
    // Multi-AZ DB Cluster requires specific instance classes (db.m5d or db.r5d family)
    const instanceClass = props.clusterInstanceClass ?? MULTI_AZ_CLUSTER_DEFAULTS.clusterInstanceClass;
    
    // Validate instance class for Multi-AZ cluster
    if (!instanceClass.match(/^db\.(m5d|r5d|m6gd|r6gd)/)) {
      throw new Error(
        `Multi-AZ DB Cluster requires db.m5d, db.r5d, db.m6gd, or db.r6gd instance families. Got: ${instanceClass}`
      );
    }
    
    // Multi-AZ cluster requires io1 or io2 storage
    const storageType = props.clusterStorageType ?? MULTI_AZ_CLUSTER_DEFAULTS.clusterStorageType;
    if (storageType !== 'io1' && storageType !== 'io2') {
      throw new Error(`Multi-AZ DB Cluster requires io1 or io2 storage type. Got: ${storageType}`);
    }
    
    // Get subnet IDs for the cluster
    const subnetIds = this.subnetGroup.node.defaultChild as rds.CfnDBSubnetGroup;
    
    // Create the Multi-AZ DB Cluster using L1 construct
    this.cfnCluster = new rds.CfnDBCluster(this, 'Cluster', {
      // Engine configuration
      engine: 'postgres',
      engineVersion: props.postgresVersion,
      
      // Cluster configuration
      dbClusterIdentifier: this.dbIdentifier,
      databaseName: props.databaseName,
      
      // Multi-AZ DB Cluster specific settings
      dbClusterInstanceClass: instanceClass,
      allocatedStorage: props.allocatedStorage ?? RDS_DEFAULTS.allocatedStorage,
      storageType: storageType,
      iops: props.clusterIops ?? MULTI_AZ_CLUSTER_DEFAULTS.clusterIops,
      
      // Credentials
      masterUsername: this.secret.secretValueFromJson('username').unsafeUnwrap(),
      masterUserPassword: this.secret.secretValueFromJson('password').unsafeUnwrap(),
      
      // Network
      dbSubnetGroupName: this.subnetGroup.subnetGroupName,
      vpcSecurityGroupIds: [this.securityGroup.securityGroupId],
      port: RDS_DEFAULTS.port,
      
      // Encryption
      storageEncrypted: props.storageEncrypted ?? true,
      
      // Backup
      backupRetentionPeriod: props.backupRetentionDays ?? 14,
      preferredBackupWindow: props.preferredBackupWindow ?? RDS_DEFAULTS.preferredBackupWindow,
      
      // Maintenance
      preferredMaintenanceWindow: props.preferredMaintenanceWindow ?? RDS_DEFAULTS.preferredMaintenanceWindow,
      autoMinorVersionUpgrade: props.autoMinorVersionUpgrade ?? true,
      
      // Parameter group - use ref since parameterGroupName is not exposed
      // Note: For cluster parameter group, we need a cluster parameter group, not instance
      // dbClusterParameterGroupName: this.parameterGroup.parameterGroupName,
      
      // Protection
      deletionProtection: props.deletionProtection ?? true,
      
      // Logs
      enableCloudwatchLogsExports: ['postgresql'],
      
      // Copy tags to snapshots
      copyTagsToSnapshot: true,
    });
    
    // Add dependency on subnet group
    this.cfnCluster.addDependency(subnetIds);
    
    // Attach secret to cluster
    new secretsmanager.CfnSecretTargetAttachment(this, 'SecretAttachment', {
      secretId: this.secret.secretArn,
      targetId: this.cfnCluster.ref,
      targetType: 'AWS::RDS::DBCluster',
    });
    
    // Set endpoints
    this.endpoint = this.cfnCluster.attrEndpointAddress;
    this.readerEndpoint = this.cfnCluster.attrReadEndpointAddress;
    this.port = RDS_DEFAULTS.port;
    
    // Apply removal policy
    this.cfnCluster.applyRemovalPolicy(cdk.RemovalPolicy.RETAIN);
    
    // Create outputs
    this.createOutputs();
    this.createClusterSpecificOutputs();
  }

  /**
   * Get deployment type
   */
  protected getDeploymentType(): RdsDeploymentType {
    return RdsDeploymentType.MULTI_AZ_CLUSTER;
  }

  /**
   * Get database engine
   */
  protected getEngine(): rds.IEngine {
    return rds.DatabaseInstanceEngine.postgres({
      version: getPostgresEngineVersion(this.props.postgresVersion),
    });
  }

  /**
   * Create cluster-specific CloudFormation outputs
   */
  private createClusterSpecificOutputs(): void {
    const stack = cdk.Stack.of(this);
    
    new cdk.CfnOutput(stack, `${this.node.id}ReaderEndpoint`, {
      value: this.readerEndpoint,
      description: 'Database reader endpoint',
      exportName: `${this.resourcePrefix}-reader-endpoint`,
    });
    
    new cdk.CfnOutput(stack, `${this.node.id}ClusterArn`, {
      value: `arn:aws:rds:${stack.region}:${stack.account}:cluster:${this.dbIdentifier}`,
      description: 'Cluster ARN',
      exportName: `${this.resourcePrefix}-cluster-arn`,
    });
  }

  /**
   * Get cluster ARN
   */
  public get clusterArn(): string {
    const stack = cdk.Stack.of(this);
    return `arn:aws:rds:${stack.region}:${stack.account}:cluster:${this.dbIdentifier}`;
  }
}

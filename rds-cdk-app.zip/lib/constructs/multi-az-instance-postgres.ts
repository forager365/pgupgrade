/**
 * Multi-AZ Instance PostgreSQL Construct
 * Deploys a Multi-AZ RDS PostgreSQL instance with synchronous standby replica
 */

import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { BaseRdsConstruct } from './base-rds-construct';
import { BaseRdsProps, RdsDeploymentType } from '../types';
import { getPostgresEngineVersion, RDS_DEFAULTS } from '../config/defaults';
import { generateResourceName } from '../utils/helpers';

/**
 * Multi-AZ Instance PostgreSQL Construct
 * Creates a highly available PostgreSQL database with automatic failover
 * Uses a synchronous standby replica (not readable)
 */
export class MultiAzInstancePostgres extends BaseRdsConstruct {
  /** The RDS database instance */
  public readonly instance: rds.DatabaseInstance;
  
  /** Database secret */
  public readonly secret: rds.DatabaseSecret;
  
  /** Database endpoint */
  public readonly endpoint: string;
  
  /** Database port */
  public readonly port: number;
  
  /** Database identifier */
  public readonly dbIdentifier: string;

  constructor(scope: Construct, id: string, props: BaseRdsProps) {
    super(scope, id, props);
    
    this.dbIdentifier = generateResourceName(props.environment, 'postgres', 'multiaz');
    
    // Create database secret
    this.secret = new rds.DatabaseSecret(this, 'Secret', {
      username: props.masterUsername ?? RDS_DEFAULTS.masterUsername,
      secretName: `${this.resourcePrefix}/credentials`,
    });
    
    // Get engine version
    const engineVersion = getPostgresEngineVersion(props.postgresVersion);
    
    // Create instance type - recommend larger instances for production multi-AZ
    const instanceType = ec2.InstanceType.of(
      props.instanceClass ?? ec2.InstanceClass.M6I,
      props.instanceSize ?? ec2.InstanceSize.LARGE
    );
    
    // Create the database instance with Multi-AZ enabled
    this.instance = new rds.DatabaseInstance(this, 'Instance', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: engineVersion,
      }),
      instanceType,
      vpc: props.vpc,
      vpcSubnets: props.vpcSubnets,
      subnetGroup: this.subnetGroup,
      securityGroups: [this.securityGroup, ...(props.securityGroups ?? [])],
      
      // Credentials
      credentials: rds.Credentials.fromSecret(this.secret),
      databaseName: props.databaseName,
      instanceIdentifier: this.dbIdentifier,
      
      // Storage
      allocatedStorage: props.allocatedStorage ?? RDS_DEFAULTS.allocatedStorage,
      maxAllocatedStorage: props.maxAllocatedStorage ?? RDS_DEFAULTS.maxAllocatedStorage,
      storageType: props.storageType ?? RDS_DEFAULTS.storageType,
      storageEncrypted: props.storageEncrypted ?? true,
      storageThroughput: props.storageType === rds.StorageType.GP3 
        ? (props.storageThroughput ?? RDS_DEFAULTS.storageThroughput) 
        : undefined,
      iops: props.iops,
      
      // High Availability - Multi-AZ Instance (synchronous standby)
      multiAz: true,
      
      // Backup - production-grade retention
      backupRetention: cdk.Duration.days(props.backupRetentionDays ?? 14),
      preferredBackupWindow: props.preferredBackupWindow ?? RDS_DEFAULTS.preferredBackupWindow,
      deleteAutomatedBackups: false,
      
      // Maintenance
      preferredMaintenanceWindow: props.preferredMaintenanceWindow ?? RDS_DEFAULTS.preferredMaintenanceWindow,
      autoMinorVersionUpgrade: props.autoMinorVersionUpgrade ?? true,
      allowMajorVersionUpgrade: false,
      
      // Monitoring
      monitoringInterval: props.enableEnhancedMonitoring 
        ? cdk.Duration.seconds(props.monitoringInterval ?? RDS_DEFAULTS.monitoringInterval) 
        : undefined,
      monitoringRole: this.monitoringRole,
      enablePerformanceInsights: props.enablePerformanceInsights ?? true,
      performanceInsightRetention: props.enablePerformanceInsights 
        ? rds.PerformanceInsightRetention.MONTHS_1
        : undefined,
      cloudwatchLogsExports: ['postgresql', 'upgrade'],
      cloudwatchLogsRetention: cdk.aws_logs.RetentionDays.ONE_MONTH,
      
      // Parameter group
      parameterGroup: this.parameterGroup,
      
      // Protection - always enabled for multi-AZ production
      deletionProtection: props.deletionProtection ?? true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
      
      // Network
      publiclyAccessible: false,
      port: RDS_DEFAULTS.port,
    });
    
    // Set endpoint and port
    this.endpoint = this.instance.dbInstanceEndpointAddress;
    this.port = parseInt(this.instance.dbInstanceEndpointPort, 10);
    
    // Create outputs
    this.createOutputs();
  }

  /**
   * Get deployment type
   */
  protected getDeploymentType(): RdsDeploymentType {
    return RdsDeploymentType.MULTI_AZ_INSTANCE;
  }

  /**
   * Get database engine
   */
  protected getEngine(): rds.IEngine {
    return rds.DatabaseInstanceEngine.postgres({
      version: getPostgresEngineVersion(this.props.postgresVersion),
    });
  }

  /**
   * Grant connect permission to a role
   */
  public grantConnect(grantee: cdk.aws_iam.IGrantable): cdk.aws_iam.Grant {
    return this.instance.grantConnect(grantee);
  }

  /**
   * Get instance ARN
   */
  public get instanceArn(): string {
    return this.instance.instanceArn;
  }

  /**
   * Create a read replica
   */
  public createReadReplica(
    id: string,
    options?: {
      instanceType?: ec2.InstanceType;
      availabilityZone?: string;
    }
  ): rds.DatabaseInstanceReadReplica {
    return new rds.DatabaseInstanceReadReplica(this, id, {
      sourceDatabaseInstance: this.instance,
      instanceType: options?.instanceType ?? ec2.InstanceType.of(
        ec2.InstanceClass.M6I,
        ec2.InstanceSize.LARGE
      ),
      vpc: this.props.vpc,
      subnetGroup: this.subnetGroup,
      securityGroups: [this.securityGroup],
      availabilityZone: options?.availabilityZone,
      publiclyAccessible: false,
      storageEncrypted: true,
      autoMinorVersionUpgrade: true,
    });
  }
}

/**
 * Single Instance PostgreSQL Construct
 * Deploys a single-AZ RDS PostgreSQL instance
 */

import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { BaseRdsConstruct } from './base-rds-construct';
import { BaseRdsProps, RdsDeploymentType } from '../types';
import { getPostgresEngineVersion, RDS_DEFAULTS } from '../config/defaults';
import { generateResourceName } from '../utils/helpers';

/**
 * Single Instance PostgreSQL Construct
 * Creates a non-HA PostgreSQL database suitable for development/testing
 */
export class SingleInstancePostgres extends BaseRdsConstruct {
  /** The RDS database instance */
  public readonly instance: rds.DatabaseInstance;
  
  /** Database secret */
  public readonly secret: rds.DatabaseSecret;
  
  /** Database endpoint */
  public readonly endpoint: string;
  
  /** Database port */
  public readonly port: number;
  
  /** Database identifier */
  public readonly dbIdentifier: string;

  constructor(scope: Construct, id: string, props: BaseRdsProps) {
    super(scope, id, props);
    
    this.dbIdentifier = generateResourceName(props.environment, 'postgres', 'single');
    
    // Create database secret
    this.secret = new rds.DatabaseSecret(this, 'Secret', {
      username: props.masterUsername ?? RDS_DEFAULTS.masterUsername,
      secretName: `${this.resourcePrefix}/credentials`,
    });
    
    // Get engine version
    const engineVersion = getPostgresEngineVersion(props.postgresVersion);
    
    // Create instance type
    const instanceType = ec2.InstanceType.of(
      props.instanceClass ?? RDS_DEFAULTS.instanceClass,
      props.instanceSize ?? RDS_DEFAULTS.instanceSize
    );
    
    // Create the database instance
    this.instance = new rds.DatabaseInstance(this, 'Instance', {
      engine: rds.DatabaseInstanceEngine.postgres({
        version: engineVersion,
      }),
      instanceType,
      vpc: props.vpc,
      vpcSubnets: props.vpcSubnets,
      subnetGroup: this.subnetGroup,
      securityGroups: [this.securityGroup, ...(props.securityGroups ?? [])],
      
      // Credentials
      credentials: rds.Credentials.fromSecret(this.secret),
      databaseName: props.databaseName,
      instanceIdentifier: this.dbIdentifier,
      
      // Storage
      allocatedStorage: props.allocatedStorage ?? RDS_DEFAULTS.allocatedStorage,
      maxAllocatedStorage: props.maxAllocatedStorage ?? RDS_DEFAULTS.maxAllocatedStorage,
      storageType: props.storageType ?? RDS_DEFAULTS.storageType,
      storageEncrypted: props.storageEncrypted ?? true,
      storageThroughput: props.storageType === rds.StorageType.GP3 
        ? (props.storageThroughput ?? RDS_DEFAULTS.storageThroughput) 
        : undefined,
      iops: props.iops,
      
      // High Availability - Single AZ
      multiAz: false,
      
      // Backup
      backupRetention: cdk.Duration.days(props.backupRetentionDays ?? RDS_DEFAULTS.backupRetentionDays),
      preferredBackupWindow: props.preferredBackupWindow ?? RDS_DEFAULTS.preferredBackupWindow,
      deleteAutomatedBackups: props.environment !== 'prod',
      
      // Maintenance
      preferredMaintenanceWindow: props.preferredMaintenanceWindow ?? RDS_DEFAULTS.preferredMaintenanceWindow,
      autoMinorVersionUpgrade: props.autoMinorVersionUpgrade ?? true,
      allowMajorVersionUpgrade: false,
      
      // Monitoring
      monitoringInterval: props.enableEnhancedMonitoring 
        ? cdk.Duration.seconds(props.monitoringInterval ?? RDS_DEFAULTS.monitoringInterval) 
        : undefined,
      monitoringRole: this.monitoringRole,
      enablePerformanceInsights: props.enablePerformanceInsights ?? true,
      performanceInsightRetention: props.enablePerformanceInsights 
        ? (props.performanceInsightsRetention ?? RDS_DEFAULTS.performanceInsightsRetention) as rds.PerformanceInsightRetention
        : undefined,
      cloudwatchLogsExports: ['postgresql', 'upgrade'],
      cloudwatchLogsRetention: cdk.aws_logs.RetentionDays.ONE_MONTH,
      
      // Parameter group
      parameterGroup: this.parameterGroup,
      
      // Protection
      deletionProtection: props.deletionProtection ?? (props.environment === 'prod'),
      removalPolicy: props.environment === 'prod' 
        ? cdk.RemovalPolicy.RETAIN 
        : cdk.RemovalPolicy.DESTROY,
      
      // Network
      publiclyAccessible: false,
      port: RDS_DEFAULTS.port,
    });
    
    // Set endpoint and port
    this.endpoint = this.instance.dbInstanceEndpointAddress;
    this.port = parseInt(this.instance.dbInstanceEndpointPort, 10);
    
    // Create outputs
    this.createOutputs();
  }

  /**
   * Get deployment type
   */
  protected getDeploymentType(): RdsDeploymentType {
    return RdsDeploymentType.SINGLE_INSTANCE;
  }

  /**
   * Get database engine
   */
  protected getEngine(): rds.IEngine {
    return rds.DatabaseInstanceEngine.postgres({
      version: getPostgresEngineVersion(this.props.postgresVersion),
    });
  }

  /**
   * Grant connect permission to a role
   */
  public grantConnect(grantee: cdk.aws_iam.IGrantable): cdk.aws_iam.Grant {
    return this.instance.grantConnect(grantee);
  }

  /**
   * Get instance ARN
   */
  public get instanceArn(): string {
    return this.instance.instanceArn;
  }
}

/**
 * Base RDS Construct
 * Abstract base class providing common functionality for all RDS deployment types
 */

import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import { BaseRdsProps, ExtensionConfig, RdsConstructOutput, RdsDeploymentType } from '../types';
import { 
  getPreloadExtensions, 
  createDefaultExtensionConfig,
  validateExtensions 
} from '../config/extensions';
import { getParameterGroupFamily, RDS_DEFAULTS } from '../config/defaults';
import { 
  generateResourceName, 
  generateTags, 
  applyTags,
  createDatabaseSubnetSelection,
  validateRdsProps 
} from '../utils/helpers';

/**
 * Abstract base class for RDS constructs
 */
export abstract class BaseRdsConstruct extends Construct {
  /** Security group for database access */
  public readonly securityGroup: ec2.SecurityGroup;
  
  /** Subnet group for database placement */
  public readonly subnetGroup: rds.SubnetGroup;
  
  /** Parameter group for database configuration */
  public readonly parameterGroup: rds.ParameterGroup;
  
  /** IAM role for enhanced monitoring */
  public readonly monitoringRole?: iam.Role;
  
  /** CloudWatch log group for database logs */
  public readonly logGroup?: logs.LogGroup;
  
  /** Secret containing database credentials */
  public abstract readonly secret: rds.DatabaseSecret;
  
  /** Database endpoint */
  public abstract readonly endpoint: string;
  
  /** Database port */
  public abstract readonly port: number;
  
  /** Database identifier */
  public abstract readonly dbIdentifier: string;

  protected readonly props: BaseRdsProps;
  protected readonly resourcePrefix: string;
  protected readonly extensionConfig: ExtensionConfig;

  constructor(scope: Construct, id: string, props: BaseRdsProps) {
    super(scope, id);
    
    this.props = props;
    this.resourcePrefix = generateResourceName(props.environment, 'rds');
    
    // Validate props
    const validation = validateRdsProps(props);
    if (!validation.valid) {
      throw new Error(`Invalid RDS configuration: ${validation.errors.join(', ')}`);
    }
    
    // Setup extension configuration
    this.extensionConfig = props.extensions ?? createDefaultExtensionConfig();
    
    // Validate extensions
    const extValidation = validateExtensions(this.extensionConfig, props.postgresVersion);
    if (!extValidation.valid) {
      throw new Error(`Invalid extension configuration: ${extValidation.errors.join(', ')}`);
    }
    
    // Create security group
    this.securityGroup = this.createSecurityGroup();
    
    // Create subnet group
    this.subnetGroup = this.createSubnetGroup();
    
    // Create parameter group
    this.parameterGroup = this.createParameterGroup();
    
    // Create monitoring role if enhanced monitoring is enabled
    if (props.enableEnhancedMonitoring) {
      this.monitoringRole = this.createMonitoringRole();
    }
    
    // Create log group for database logs
    this.logGroup = this.createLogGroup();
    
    // Apply tags
    const tags = generateTags(props.environment, this.getDeploymentType(), props.tags);
    applyTags(this, tags);
  }

  /**
   * Get the deployment type - must be implemented by subclasses
   */
  protected abstract getDeploymentType(): RdsDeploymentType;

  /**
   * Create security group for database access
   */
  protected createSecurityGroup(): ec2.SecurityGroup {
    const sg = new ec2.SecurityGroup(this, 'SecurityGroup', {
      vpc: this.props.vpc,
      description: `Security group for ${this.resourcePrefix} PostgreSQL database`,
      securityGroupName: `${this.resourcePrefix}-sg`,
      allowAllOutbound: false,
    });

    // Add default egress rule for HTTPS (for AWS service endpoints)
    sg.addEgressRule(
      ec2.Peer.anyIpv4(),
      ec2.Port.tcp(443),
      'Allow HTTPS outbound for AWS services'
    );

    return sg;
  }

  /**
   * Create subnet group for database placement
   */
  protected createSubnetGroup(): rds.SubnetGroup {
    const subnetSelection = this.props.vpcSubnets ?? 
      createDatabaseSubnetSelection(this.props.vpc);
    
    return new rds.SubnetGroup(this, 'SubnetGroup', {
      vpc: this.props.vpc,
      description: `Subnet group for ${this.resourcePrefix} PostgreSQL database`,
      subnetGroupName: `${this.resourcePrefix}-subnet-group`,
      vpcSubnets: subnetSelection,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });
  }

  /**
   * Create parameter group with extension configuration
   */
  protected createParameterGroup(): rds.ParameterGroup {
    const family = this.getParameterGroupFamily();
    const parameters = this.buildParameters();
    
    return new rds.ParameterGroup(this, 'ParameterGroup', {
      engine: this.getEngine(),
      description: `Parameter group for ${this.resourcePrefix} PostgreSQL with extensions`,
      parameters,
    });
  }

  /**
   * Get parameter group family - can be overridden by subclasses
   */
  protected getParameterGroupFamily(): string {
    return getParameterGroupFamily(this.props.postgresVersion, this.isAurora());
  }

  /**
   * Check if this is an Aurora deployment - override in Aurora construct
   */
  protected isAurora(): boolean {
    return false;
  }

  /**
   * Get the database engine - must be implemented by subclasses
   */
  protected abstract getEngine(): rds.IEngine;

  /**
   * Build parameter group parameters
   */
  protected buildParameters(): Record<string, string> {
    const allExtensions = [
      ...this.extensionConfig.requiredExtensions,
      ...this.extensionConfig.optionalExtensions,
    ];
    
    const preloadLibs = getPreloadExtensions(allExtensions);
    
    const parameters: Record<string, string> = {
      // Logging
      'log_statement': 'ddl',
      'log_min_duration_statement': '1000',
      'log_connections': '1',
      'log_disconnections': '1',
      'log_lock_waits': '1',
      'log_temp_files': '0',
      
      // Memory settings (reasonable defaults)
      'work_mem': '65536', // 64MB
      'maintenance_work_mem': '524288', // 512MB
      
      // Checkpointing
      'checkpoint_timeout': '900', // 15 minutes
      'max_wal_size': '2048', // 2GB
      
      // Connection management
      'idle_in_transaction_session_timeout': '3600000', // 1 hour
      
      // Random page cost for SSDs
      'random_page_cost': '1.1',
      
      // Parallel query
      'max_parallel_workers_per_gather': '2',
      
      // Statistics
      'track_activities': '1',
      'track_counts': '1',
      'track_io_timing': '1',
      'track_functions': 'all',
    };
    
    // Add shared_preload_libraries if there are extensions requiring preload
    if (preloadLibs.length > 0) {
      parameters['shared_preload_libraries'] = preloadLibs.join(',');
    }
    
    // pg_stat_statements configuration
    if (allExtensions.includes('pg_stat_statements')) {
      parameters['pg_stat_statements.track'] = 'all';
      parameters['pg_stat_statements.max'] = '10000';
    }
    
    // pgaudit configuration
    if (allExtensions.includes('pgaudit')) {
      parameters['pgaudit.log'] = 'ddl,role';
      parameters['pgaudit.log_catalog'] = '1';
    }
    
    // auto_explain configuration
    if (allExtensions.includes('auto_explain')) {
      parameters['auto_explain.log_min_duration'] = '1000';
      parameters['auto_explain.log_analyze'] = '1';
      parameters['auto_explain.log_buffers'] = '1';
    }
    
    // pg_cron configuration
    if (allExtensions.includes('pg_cron')) {
      parameters['cron.database_name'] = this.props.databaseName;
    }
    
    // Merge with any parameter overrides
    if (this.props.parameterOverrides) {
      Object.assign(parameters, this.props.parameterOverrides);
    }
    
    return parameters;
  }

  /**
   * Create IAM role for enhanced monitoring
   */
  protected createMonitoringRole(): iam.Role {
    return new iam.Role(this, 'MonitoringRole', {
      roleName: `${this.resourcePrefix}-monitoring-role`,
      assumedBy: new iam.ServicePrincipal('monitoring.rds.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AmazonRDSEnhancedMonitoringRole'),
      ],
    });
  }

  /**
   * Create CloudWatch log group for database logs
   */
  protected createLogGroup(): logs.LogGroup {
    return new logs.LogGroup(this, 'LogGroup', {
      logGroupName: `/aws/rds/${this.resourcePrefix}`,
      retention: logs.RetentionDays.ONE_MONTH,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });
  }

  /**
   * Add ingress rule to security group
   */
  public allowFrom(
    peer: ec2.IPeer,
    description: string = 'Allow database access'
  ): void {
    this.securityGroup.addIngressRule(
      peer,
      ec2.Port.tcp(RDS_DEFAULTS.port),
      description
    );
  }

  /**
   * Allow access from another security group
   */
  public allowFromSecurityGroup(
    securityGroup: ec2.ISecurityGroup,
    description: string = 'Allow database access from security group'
  ): void {
    this.securityGroup.addIngressRule(
      securityGroup,
      ec2.Port.tcp(RDS_DEFAULTS.port),
      description
    );
  }

  /**
   * Get construct output
   */
  public getOutput(): RdsConstructOutput {
    return {
      endpoint: this.endpoint,
      port: this.port,
      secretArn: this.secret.secretArn,
      securityGroupId: this.securityGroup.securityGroupId,
      dbIdentifier: this.dbIdentifier,
    };
  }

  /**
   * Create CloudFormation outputs
   */
  protected createOutputs(): void {
    const stack = cdk.Stack.of(this);
    
    new cdk.CfnOutput(stack, `${this.node.id}Endpoint`, {
      value: this.endpoint,
      description: 'Database endpoint',
      exportName: `${this.resourcePrefix}-endpoint`,
    });
    
    new cdk.CfnOutput(stack, `${this.node.id}Port`, {
      value: this.port.toString(),
      description: 'Database port',
      exportName: `${this.resourcePrefix}-port`,
    });
    
    new cdk.CfnOutput(stack, `${this.node.id}SecretArn`, {
      value: this.secret.secretArn,
      description: 'Database credentials secret ARN',
      exportName: `${this.resourcePrefix}-secret-arn`,
    });
    
    new cdk.CfnOutput(stack, `${this.node.id}SecurityGroupId`, {
      value: this.securityGroup.securityGroupId,
      description: 'Database security group ID',
      exportName: `${this.resourcePrefix}-sg-id`,
    });
    
    new cdk.CfnOutput(stack, `${this.node.id}DbIdentifier`, {
      value: this.dbIdentifier,
      description: 'Database identifier',
      exportName: `${this.resourcePrefix}-db-identifier`,
    });
  }
}

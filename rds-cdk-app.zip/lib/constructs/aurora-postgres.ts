/**
 * Aurora PostgreSQL Construct
 * Deploys an Aurora PostgreSQL cluster with optional serverless v2 support
 */

import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { BaseRdsConstruct } from './base-rds-construct';
import { AuroraPostgresProps, RdsDeploymentType } from '../types';
import { 
  getAuroraPostgresEngineVersion, 
  RDS_DEFAULTS, 
  AURORA_DEFAULTS,
  getParameterGroupFamily 
} from '../config/defaults';
import { generateResourceName } from '../utils/helpers';

/**
 * Aurora PostgreSQL Construct
 * Creates a highly available Aurora PostgreSQL cluster with:
 * - One writer instance
 * - Configurable number of reader instances
 * - Optional serverless v2 scaling
 * - Storage auto-scaling up to 128 TB
 * - Fast failover (typically under 30 seconds)
 */
export class AuroraPostgres extends BaseRdsConstruct {
  /** The Aurora database cluster */
  public readonly cluster: rds.DatabaseCluster;
  
  /** Database secret */
  public readonly secret: rds.DatabaseSecret;
  
  /** Writer endpoint */
  public readonly endpoint: string;
  
  /** Reader endpoint */
  public readonly readerEndpoint: string;
  
  /** Database port */
  public readonly port: number;
  
  /** Database identifier */
  public readonly dbIdentifier: string;

  private readonly auroraProps: AuroraPostgresProps;

  constructor(scope: Construct, id: string, props: AuroraPostgresProps) {
    super(scope, id, props);
    
    this.auroraProps = props;
    this.dbIdentifier = generateResourceName(props.environment, 'aurora', 'postgres');
    
    // Create database secret
    this.secret = new rds.DatabaseSecret(this, 'Secret', {
      username: props.masterUsername ?? RDS_DEFAULTS.masterUsername,
      secretName: `${this.resourcePrefix}/credentials`,
    });
    
    // Get Aurora engine version
    const engineVersion = getAuroraPostgresEngineVersion(props.postgresVersion);
    
    // Determine if using serverless v2
    const useServerless = props.serverlessV2 ?? false;
    
    // Create the Aurora cluster
    if (useServerless) {
      this.cluster = this.createServerlessCluster(engineVersion);
    } else {
      this.cluster = this.createProvisionedCluster(engineVersion);
    }
    
    // Set endpoints
    this.endpoint = this.cluster.clusterEndpoint.hostname;
    this.readerEndpoint = this.cluster.clusterReadEndpoint.hostname;
    this.port = this.cluster.clusterEndpoint.port;
    
    // Create outputs
    this.createOutputs();
    this.createAuroraSpecificOutputs();
  }

  /**
   * Create a serverless v2 Aurora cluster
   */
  private createServerlessCluster(engineVersion: rds.AuroraPostgresEngineVersion): rds.DatabaseCluster {
    const minCapacity = this.auroraProps.minCapacity ?? AURORA_DEFAULTS.minCapacity;
    const maxCapacity = this.auroraProps.maxCapacity ?? AURORA_DEFAULTS.maxCapacity;
    const readerInstances = this.auroraProps.readerInstances ?? AURORA_DEFAULTS.readerInstances;
    
    // Build reader instances
    const readers: rds.IClusterInstance[] = [];
    for (let i = 1; i <= readerInstances; i++) {
      readers.push(
        rds.ClusterInstance.serverlessV2(`reader${i}`, {
          scaleWithWriter: true,
          enablePerformanceInsights: this.auroraProps.enablePerformanceInsights ?? true,
          performanceInsightRetention: this.auroraProps.enablePerformanceInsights 
            ? rds.PerformanceInsightRetention.MONTHS_1
            : undefined,
        })
      );
    }
    
    return new rds.DatabaseCluster(this, 'Cluster', {
      engine: rds.DatabaseClusterEngine.auroraPostgres({
        version: engineVersion,
      }),
      
      // Credentials
      credentials: rds.Credentials.fromSecret(this.secret),
      defaultDatabaseName: this.auroraProps.databaseName,
      clusterIdentifier: this.dbIdentifier,
      
      // Serverless v2 configuration
      serverlessV2MinCapacity: minCapacity,
      serverlessV2MaxCapacity: maxCapacity,
      
      // Instance configuration
      writer: rds.ClusterInstance.serverlessV2('writer', {
        enablePerformanceInsights: this.auroraProps.enablePerformanceInsights ?? true,
        performanceInsightRetention: this.auroraProps.enablePerformanceInsights 
          ? rds.PerformanceInsightRetention.MONTHS_1
          : undefined,
      }),
      readers,
      
      // Network
      vpc: this.auroraProps.vpc,
      vpcSubnets: this.auroraProps.vpcSubnets,
      subnetGroup: this.subnetGroup,
      securityGroups: [this.securityGroup, ...(this.auroraProps.securityGroups ?? [])],
      
      // Storage
      storageEncrypted: this.auroraProps.storageEncrypted ?? true,
      storageType: rds.DBClusterStorageType.AURORA,
      
      // Backup
      backup: {
        retention: cdk.Duration.days(this.auroraProps.backupRetentionDays ?? 14),
        preferredWindow: this.auroraProps.preferredBackupWindow ?? RDS_DEFAULTS.preferredBackupWindow,
      },
      
      // Maintenance
      preferredMaintenanceWindow: this.auroraProps.preferredMaintenanceWindow ?? RDS_DEFAULTS.preferredMaintenanceWindow,
      
      // Monitoring
      monitoringInterval: this.auroraProps.enableEnhancedMonitoring 
        ? cdk.Duration.seconds(this.auroraProps.monitoringInterval ?? RDS_DEFAULTS.monitoringInterval) 
        : undefined,
      monitoringRole: this.monitoringRole,
      cloudwatchLogsExports: ['postgresql'],
      cloudwatchLogsRetention: cdk.aws_logs.RetentionDays.ONE_MONTH,
      
      // Parameter group
      parameterGroup: this.parameterGroup,
      
      // Protection
      deletionProtection: this.auroraProps.deletionProtection ?? true,
      removalPolicy: this.auroraProps.environment === 'prod' 
        ? cdk.RemovalPolicy.RETAIN 
        : cdk.RemovalPolicy.DESTROY,
      
      // Network
      port: RDS_DEFAULTS.port,
      
      // Copy tags to snapshots
      copyTagsToSnapshot: true,
    });
  }

  /**
   * Create a provisioned Aurora cluster
   */
  private createProvisionedCluster(engineVersion: rds.AuroraPostgresEngineVersion): rds.DatabaseCluster {
    const readerInstances = this.auroraProps.readerInstances ?? AURORA_DEFAULTS.readerInstances;
    
    // Create instance type
    const instanceType = ec2.InstanceType.of(
      this.auroraProps.instanceClass ?? AURORA_DEFAULTS.instanceClass,
      this.auroraProps.instanceSize ?? AURORA_DEFAULTS.instanceSize
    );
    
    // Build reader instances
    const readers: rds.IClusterInstance[] = [];
    for (let i = 1; i <= readerInstances; i++) {
      readers.push(
        rds.ClusterInstance.provisioned(`reader${i}`, {
          instanceType,
          enablePerformanceInsights: this.auroraProps.enablePerformanceInsights ?? true,
          performanceInsightRetention: this.auroraProps.enablePerformanceInsights 
            ? rds.PerformanceInsightRetention.MONTHS_1
            : undefined,
        })
      );
    }
    
    return new rds.DatabaseCluster(this, 'Cluster', {
      engine: rds.DatabaseClusterEngine.auroraPostgres({
        version: engineVersion,
      }),
      
      // Credentials
      credentials: rds.Credentials.fromSecret(this.secret),
      defaultDatabaseName: this.auroraProps.databaseName,
      clusterIdentifier: this.dbIdentifier,
      
      // Instance configuration
      writer: rds.ClusterInstance.provisioned('writer', {
        instanceType,
        enablePerformanceInsights: this.auroraProps.enablePerformanceInsights ?? true,
        performanceInsightRetention: this.auroraProps.enablePerformanceInsights 
          ? rds.PerformanceInsightRetention.MONTHS_1
          : undefined,
      }),
      readers,
      
      // Network
      vpc: this.auroraProps.vpc,
      vpcSubnets: this.auroraProps.vpcSubnets,
      subnetGroup: this.subnetGroup,
      securityGroups: [this.securityGroup, ...(this.auroraProps.securityGroups ?? [])],
      
      // Storage
      storageEncrypted: this.auroraProps.storageEncrypted ?? true,
      storageType: rds.DBClusterStorageType.AURORA,
      
      // Backup
      backup: {
        retention: cdk.Duration.days(this.auroraProps.backupRetentionDays ?? 14),
        preferredWindow: this.auroraProps.preferredBackupWindow ?? RDS_DEFAULTS.preferredBackupWindow,
      },
      
      // Maintenance
      preferredMaintenanceWindow: this.auroraProps.preferredMaintenanceWindow ?? RDS_DEFAULTS.preferredMaintenanceWindow,
      
      // Monitoring
      monitoringInterval: this.auroraProps.enableEnhancedMonitoring 
        ? cdk.Duration.seconds(this.auroraProps.monitoringInterval ?? RDS_DEFAULTS.monitoringInterval) 
        : undefined,
      monitoringRole: this.monitoringRole,
      cloudwatchLogsExports: ['postgresql'],
      cloudwatchLogsRetention: cdk.aws_logs.RetentionDays.ONE_MONTH,
      
      // Parameter group
      parameterGroup: this.parameterGroup,
      
      // Protection
      deletionProtection: this.auroraProps.deletionProtection ?? true,
      removalPolicy: this.auroraProps.environment === 'prod' 
        ? cdk.RemovalPolicy.RETAIN 
        : cdk.RemovalPolicy.DESTROY,
      
      // Network
      port: RDS_DEFAULTS.port,
      
      // Copy tags to snapshots
      copyTagsToSnapshot: true,
    });
  }

  /**
   * Get deployment type
   */
  protected getDeploymentType(): RdsDeploymentType {
    return RdsDeploymentType.AURORA_POSTGRES;
  }

  /**
   * Get database engine
   */
  protected getEngine(): rds.IEngine {
    return rds.DatabaseClusterEngine.auroraPostgres({
      version: getAuroraPostgresEngineVersion(this.props.postgresVersion),
    });
  }

  /**
   * Override to indicate this is Aurora
   */
  protected isAurora(): boolean {
    return true;
  }

  /**
   * Get parameter group family for Aurora
   */
  protected getParameterGroupFamily(): string {
    return getParameterGroupFamily(this.props.postgresVersion, true);
  }

  /**
   * Create Aurora-specific CloudFormation outputs
   */
  private createAuroraSpecificOutputs(): void {
    const stack = cdk.Stack.of(this);
    
    new cdk.CfnOutput(stack, `${this.node.id}ReaderEndpoint`, {
      value: this.readerEndpoint,
      description: 'Aurora reader endpoint',
      exportName: `${this.resourcePrefix}-reader-endpoint`,
    });
    
    new cdk.CfnOutput(stack, `${this.node.id}ClusterArn`, {
      value: this.cluster.clusterArn,
      description: 'Aurora cluster ARN',
      exportName: `${this.resourcePrefix}-cluster-arn`,
    });
    
    if (this.auroraProps.serverlessV2) {
      new cdk.CfnOutput(stack, `${this.node.id}ServerlessCapacity`, {
        value: `${this.auroraProps.minCapacity ?? AURORA_DEFAULTS.minCapacity} - ${this.auroraProps.maxCapacity ?? AURORA_DEFAULTS.maxCapacity} ACU`,
        description: 'Aurora Serverless v2 capacity range',
        exportName: `${this.resourcePrefix}-serverless-capacity`,
      });
    }
  }

  /**
   * Grant connect permission to a role
   */
  public grantConnect(grantee: cdk.aws_iam.IGrantable, dbUser: string = 'dbadmin'): cdk.aws_iam.Grant {
    return this.cluster.grantConnect(grantee, dbUser);
  }

  /**
   * Grant data API access
   */
  public grantDataApiAccess(grantee: cdk.aws_iam.IGrantable): void {
    this.cluster.grantDataApiAccess(grantee);
  }

  /**
   * Get cluster ARN
   */
  public get clusterArn(): string {
    return this.cluster.clusterArn;
  }

  /**
   * Get cluster resource identifier
   */
  public get clusterResourceIdentifier(): string {
    return this.cluster.clusterResourceIdentifier;
  }

  /**
   * Add capacity (add additional reader for autoscaling)
   * Note: For runtime changes, update CDK and redeploy
   */
  public addReader(
    id: string,
    options?: {
      instanceType?: ec2.InstanceType;
      serverless?: boolean;
    }
  ): void {
    if (options?.serverless || this.auroraProps.serverlessV2) {
      // For serverless, capacity is managed automatically
      console.log(`Note: Serverless v2 auto-scales based on demand. Manual reader addition skipped for ${id}`);
    } else {
      // For provisioned, we would need to modify the cluster configuration
      // This is typically done through a CDK update rather than runtime
      console.log(`To add reader ${id}, update the readerInstances prop and redeploy`);
    }
  }
}

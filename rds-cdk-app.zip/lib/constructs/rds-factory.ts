/**
 * RDS Factory
 * Factory pattern implementation for creating different RDS deployment types
 */

import { Construct } from 'constructs';
import { 
  RdsDeploymentType, 
  BaseRdsProps, 
  AuroraPostgresProps, 
  MultiAzClusterProps,
  RdsConstructOutput 
} from '../types';
import { BaseRdsConstruct } from './base-rds-construct';
import { SingleInstancePostgres } from './single-instance-postgres';
import { MultiAzInstancePostgres } from './multi-az-instance-postgres';
import { MultiAzClusterPostgres } from './multi-az-cluster-postgres';
import { AuroraPostgres } from './aurora-postgres';

/**
 * Factory configuration for creating RDS deployments
 */
export interface RdsFactoryConfig {
  /** Deployment type */
  deploymentType: RdsDeploymentType;
  /** RDS properties */
  props: BaseRdsProps | AuroraPostgresProps | MultiAzClusterProps;
}

/**
 * RDS Factory class
 * Creates the appropriate RDS construct based on deployment type
 */
export class RdsFactory {
  /**
   * Create an RDS deployment based on configuration
   */
  public static create(
    scope: Construct,
    id: string,
    config: RdsFactoryConfig
  ): BaseRdsConstruct {
    switch (config.deploymentType) {
      case RdsDeploymentType.SINGLE_INSTANCE:
        return new SingleInstancePostgres(scope, id, config.props as BaseRdsProps);
        
      case RdsDeploymentType.MULTI_AZ_INSTANCE:
        return new MultiAzInstancePostgres(scope, id, config.props as BaseRdsProps);
        
      case RdsDeploymentType.MULTI_AZ_CLUSTER:
        return new MultiAzClusterPostgres(scope, id, config.props as MultiAzClusterProps);
        
      case RdsDeploymentType.AURORA_POSTGRES:
        return new AuroraPostgres(scope, id, config.props as AuroraPostgresProps);
        
      default:
        throw new Error(`Unsupported deployment type: ${config.deploymentType}`);
    }
  }

  /**
   * Get deployment type description
   */
  public static getDeploymentDescription(type: RdsDeploymentType): string {
    const descriptions: Record<RdsDeploymentType, string> = {
      [RdsDeploymentType.SINGLE_INSTANCE]: 
        'Single PostgreSQL instance. Best for development/testing or non-critical workloads.',
      [RdsDeploymentType.MULTI_AZ_INSTANCE]: 
        'Multi-AZ instance with synchronous standby. Provides automatic failover for production workloads.',
      [RdsDeploymentType.MULTI_AZ_CLUSTER]: 
        'Multi-AZ DB cluster with readable standbys. Highest availability with fast failover and read scaling.',
      [RdsDeploymentType.AURORA_POSTGRES]: 
        'Aurora PostgreSQL cluster. Cloud-native with auto-scaling storage, fast failover, and optional serverless.',
    };
    return descriptions[type];
  }

  /**
   * Get recommended deployment type based on requirements
   */
  public static getRecommendedDeployment(requirements: {
    environment: 'dev' | 'staging' | 'prod';
    readScaling?: boolean;
    serverless?: boolean;
    costOptimized?: boolean;
    highAvailability?: boolean;
  }): RdsDeploymentType {
    const { environment, readScaling, serverless, costOptimized, highAvailability } = requirements;
    
    // Development environment
    if (environment === 'dev') {
      if (serverless) {
        return RdsDeploymentType.AURORA_POSTGRES; // Serverless v2 for cost optimization
      }
      return RdsDeploymentType.SINGLE_INSTANCE;
    }
    
    // Staging environment
    if (environment === 'staging') {
      if (readScaling) {
        return RdsDeploymentType.AURORA_POSTGRES;
      }
      return RdsDeploymentType.MULTI_AZ_INSTANCE;
    }
    
    // Production environment
    if (environment === 'prod') {
      if (serverless) {
        return RdsDeploymentType.AURORA_POSTGRES;
      }
      if (readScaling) {
        return RdsDeploymentType.AURORA_POSTGRES;
      }
      if (highAvailability && !costOptimized) {
        return RdsDeploymentType.MULTI_AZ_CLUSTER;
      }
      return RdsDeploymentType.MULTI_AZ_INSTANCE;
    }
    
    return RdsDeploymentType.SINGLE_INSTANCE;
  }

  /**
   * Validate deployment configuration
   */
  public static validateConfig(config: RdsFactoryConfig): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    // Validate deployment-specific requirements
    switch (config.deploymentType) {
      case RdsDeploymentType.MULTI_AZ_CLUSTER:
        const clusterProps = config.props as MultiAzClusterProps;
        if (clusterProps.clusterInstanceClass) {
          if (!clusterProps.clusterInstanceClass.match(/^db\.(m5d|r5d|m6gd|r6gd)/)) {
            errors.push('Multi-AZ cluster requires db.m5d, db.r5d, db.m6gd, or db.r6gd instance families');
          }
        }
        if (clusterProps.clusterStorageType && !['io1', 'io2'].includes(clusterProps.clusterStorageType)) {
          errors.push('Multi-AZ cluster requires io1 or io2 storage type');
        }
        break;
        
      case RdsDeploymentType.AURORA_POSTGRES:
        const auroraProps = config.props as AuroraPostgresProps;
        if (auroraProps.serverlessV2) {
          if (auroraProps.minCapacity !== undefined && auroraProps.minCapacity < 0.5) {
            errors.push('Aurora Serverless v2 minimum capacity must be at least 0.5 ACU');
          }
          if (auroraProps.maxCapacity !== undefined && auroraProps.maxCapacity > 128) {
            errors.push('Aurora Serverless v2 maximum capacity cannot exceed 128 ACU');
          }
          if (auroraProps.minCapacity !== undefined && auroraProps.maxCapacity !== undefined) {
            if (auroraProps.minCapacity > auroraProps.maxCapacity) {
              errors.push('Aurora Serverless v2 minimum capacity cannot exceed maximum capacity');
            }
          }
        }
        break;
    }
    
    return {
      valid: errors.length === 0,
      errors,
    };
  }

  /**
   * Get all available deployment types
   */
  public static getAvailableDeploymentTypes(): RdsDeploymentType[] {
    return Object.values(RdsDeploymentType);
  }

  /**
   * Compare deployment types
   */
  public static compareDeployments(): Record<string, Record<RdsDeploymentType, string>> {
    return {
      'Availability': {
        [RdsDeploymentType.SINGLE_INSTANCE]: 'Single AZ',
        [RdsDeploymentType.MULTI_AZ_INSTANCE]: 'Multi-AZ (standby)',
        [RdsDeploymentType.MULTI_AZ_CLUSTER]: 'Multi-AZ (2 standbys)',
        [RdsDeploymentType.AURORA_POSTGRES]: 'Multi-AZ (auto)',
      },
      'Failover Time': {
        [RdsDeploymentType.SINGLE_INSTANCE]: 'Manual',
        [RdsDeploymentType.MULTI_AZ_INSTANCE]: '60-120 seconds',
        [RdsDeploymentType.MULTI_AZ_CLUSTER]: '< 35 seconds',
        [RdsDeploymentType.AURORA_POSTGRES]: '< 30 seconds',
      },
      'Read Scaling': {
        [RdsDeploymentType.SINGLE_INSTANCE]: 'Read replicas',
        [RdsDeploymentType.MULTI_AZ_INSTANCE]: 'Read replicas',
        [RdsDeploymentType.MULTI_AZ_CLUSTER]: 'Readable standbys',
        [RdsDeploymentType.AURORA_POSTGRES]: 'Up to 15 replicas',
      },
      'Storage': {
        [RdsDeploymentType.SINGLE_INSTANCE]: 'Up to 64 TB',
        [RdsDeploymentType.MULTI_AZ_INSTANCE]: 'Up to 64 TB',
        [RdsDeploymentType.MULTI_AZ_CLUSTER]: 'Up to 64 TB',
        [RdsDeploymentType.AURORA_POSTGRES]: 'Auto-scales to 128 TB',
      },
      'Cost': {
        [RdsDeploymentType.SINGLE_INSTANCE]: 'Lowest',
        [RdsDeploymentType.MULTI_AZ_INSTANCE]: 'Moderate',
        [RdsDeploymentType.MULTI_AZ_CLUSTER]: 'High',
        [RdsDeploymentType.AURORA_POSTGRES]: 'Variable (serverless)',
      },
    };
  }
}

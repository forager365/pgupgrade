// Package upgrade orchestrates the end-to-end blue/green major-version upgrade,
// wiring together AWS detection, preconditions, the blue/green deployment, SQL
// operations, smoke validation and switchover. It supports a dry-run mode that
// enumerates every step without mutating anything.
package upgrade

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"bggowails/internal/awsx"
	"bggowails/internal/bluegreen"
	"bggowails/internal/config"
	"bggowails/internal/logging"
	"bggowails/internal/pg"
	"bggowails/internal/preconditions"
	"bggowails/internal/smoketest"
	"bggowails/internal/topology"
)

// Step is a planned action, used to render the dry-run plan.
type Step struct {
	Number  int    `json:"number"`
	Title   string `json:"title"`
	Detail  string `json:"detail"`
	Mutates bool   `json:"mutates"` // whether the step changes AWS/DB state
}

// Event is a structured progress update emitted during a real run.
type Event struct {
	Phase   string `json:"phase"`
	Status  string `json:"status"` // start | ok | warn | error | skip
	Message string `json:"message"`
}

// EventFunc receives progress events (wired to the UI).
type EventFunc func(Event)

// Report is the final outcome of a run.
type Report struct {
	Topology      string               `json:"topology"`
	DeploymentID  string               `json:"deploymentId"`
	Preconditions preconditions.Result `json:"preconditions"`
	Smoke         smoketest.Result     `json:"smoke"`
	SwitchedOver  bool                 `json:"switchedOver"`
	LogPath       string               `json:"logPath"`
}

// Runner executes an upgrade for a single configuration.
type Runner struct {
	cfg               *config.Config
	log               *logging.Logger
	emit              EventFunc
	switchoverTimeout time.Duration
	pollInterval      time.Duration
}

// NewRunner builds a Runner. emit may be nil.
func NewRunner(cfg *config.Config, log *logging.Logger, emit EventFunc) *Runner {
	if emit == nil {
		emit = func(Event) {}
	}
	return &Runner{
		cfg:               cfg,
		log:               log,
		emit:              emit,
		switchoverTimeout: 5 * time.Minute,
		pollInterval:      30 * time.Second,
	}
}

func (r *Runner) event(phase, status, format string, args ...any) {
	msg := fmt.Sprintf(format, args...)
	r.emit(Event{Phase: phase, Status: status, Message: msg})
	switch status {
	case "error":
		r.log.SetPhase(phase)
		r.log.Errorf("%s", msg)
	case "warn":
		r.log.SetPhase(phase)
		r.log.Warnf("%s", msg)
	default:
		r.log.SetPhase(phase)
		r.log.Stepf("%s", msg)
	}
}

// Plan builds the ordered list of steps that a real run would perform, given
// the (already detected) topology. It is also used to render the dry run.
func (r *Runner) Plan(t *topology.Target) []Step {
	cfg := r.cfg
	aurora := t.Topology == config.TopologyAurora
	var steps []Step
	add := func(title, detail string, mutates bool) {
		steps = append(steps, Step{Number: len(steps) + 1, Title: title, Detail: detail, Mutates: mutates})
	}

	add("Verify AWS identity", "sts:GetCallerIdentity using SSO profile "+cfg.AWS.SSOProfile, false)
	add("Detect topology", t.Describe(), false)
	add("Connect to source database", fmt.Sprintf("pgx connect to %s:%d/%s", cfg.Database.Host, cfg.Database.Port, cfg.Database.Name), false)
	add("Run preconditions", "version path, engine family, parameter groups, connectivity, logical replication", false)

	for _, e := range cfg.Extensions {
		if e.DropBeforeUpgrade {
			add("Drop extension on blue", fmt.Sprintf("DROP EXTENSION IF EXISTS %s", e.Name), true)
		}
	}

	pgName := cfg.ParameterGroups.Instance
	if aurora {
		pgName = cfg.ParameterGroups.Cluster
	}
	add("Create blue/green deployment",
		fmt.Sprintf("name=%s source=%s target_version=%s parameter_group=%s",
			cfg.Upgrade.BlueGreenName, t.Identifier, cfg.Upgrade.TargetVersion, pgName), true)
	add("Wait for green to become available", "poll DescribeBlueGreenDeployments until AVAILABLE", false)
	add("Resolve green endpoint", "describe target member to find green host/port", false)

	if cfg.Options.DropLogicalReplication {
		add("Disable logical replication on green",
			"drop subscriptions/publications and inactive logical slots on green", true)
	}

	if !cfg.Options.SkipExtensionRecreate {
		for _, e := range cfg.Extensions {
			if e.Recreate {
				add("Recreate extension on green", fmt.Sprintf("CREATE EXTENSION IF NOT EXISTS %s", e.Name), true)
			}
		}
	}

	add("Run smoke tests", fmt.Sprintf("compare %d table counts and %d queries between blue and green",
		len(cfg.Smoke.CountTables), len(cfg.Smoke.Queries)), false)
	add("Switch over", "promote green to blue endpoints (only if smoke tests pass)", true)

	if cfg.Upgrade.DeleteAfterSwitch {
		add("Delete old blue environment", "delete blue/green deployment with DeleteTarget=true", true)
	} else {
		add("Retain old blue environment", "blue/green deployment left in place for manual cleanup", false)
	}

	return steps
}

// DryRun detects topology (read-only) and prints the plan without mutating.
func (r *Runner) DryRun(ctx context.Context) ([]Step, *topology.Target, error) {
	r.event("dryrun", "start", "dry run: enumerating steps (no changes will be made)")

	clients, err := awsx.New(ctx, r.cfg.AWS.SSOProfile, r.cfg.AWS.Region)
	if err != nil {
		r.event("dryrun", "error", "%v", err)
		return nil, nil, err
	}
	if acct, arn, err := clients.CallerIdentity(ctx); err != nil {
		r.event("dryrun", "warn", "could not verify identity (steps still listed): %v", err)
	} else {
		r.event("dryrun", "ok", "authenticated as %s (account %s)", arn, acct)
	}

	t, err := topology.Detect(ctx, clients.RDS, r.cfg)
	if err != nil {
		r.event("dryrun", "warn", "topology detection failed, using declared topology %q: %v", r.cfg.Upgrade.Topology, err)
		t = &topology.Target{Topology: r.cfg.Upgrade.Topology, Identifier: r.identifier(), Engine: "postgres"}
	} else {
		r.event("dryrun", "ok", "%s", t.Describe())
	}

	steps := r.Plan(t)
	for _, s := range steps {
		marker := " "
		if s.Mutates {
			marker = "*"
		}
		r.log.Dryf("[%2d]%s %s — %s", s.Number, marker, s.Title, s.Detail)
	}
	r.event("dryrun", "ok", "%d steps planned (* = mutating). No changes were made.", len(steps))
	return steps, t, nil
}

func (r *Runner) identifier() string {
	if r.cfg.Target.DBClusterIdentifier != "" {
		return r.cfg.Target.DBClusterIdentifier
	}
	return r.cfg.Target.DBInstanceIdentifier
}

// Run executes the full upgrade. It stops before switchover if preconditions or
// smoke tests fail.
func (r *Runner) Run(ctx context.Context) (*Report, error) {
	report := &Report{LogPath: r.log.Path()}

	// 1. AWS auth.
	r.event("auth", "start", "verifying AWS identity via SSO profile %q", r.cfg.AWS.SSOProfile)
	clients, err := awsx.New(ctx, r.cfg.AWS.SSOProfile, r.cfg.AWS.Region)
	if err != nil {
		r.event("auth", "error", "%v", err)
		return report, err
	}
	acct, arn, err := clients.CallerIdentity(ctx)
	if err != nil {
		r.event("auth", "error", "%v", err)
		return report, err
	}
	r.event("auth", "ok", "authenticated as %s (account %s)", arn, acct)

	// 2. Topology.
	r.event("detect", "start", "detecting topology")
	t, err := topology.Detect(ctx, clients.RDS, r.cfg)
	if err != nil {
		r.event("detect", "error", "%v", err)
		return report, err
	}
	report.Topology = string(t.Topology)
	r.event("detect", "ok", "%s", t.Describe())

	// 3. Connect to blue.
	r.event("connect", "start", "connecting to source database")
	blueConn, err := pg.Connect(ctx, pg.FromConfig(r.cfg.Database, "", 0))
	if err != nil {
		r.event("connect", "error", "%v", err)
		// Connectivity is a fatal precondition; record and stop.
		report.Preconditions = preconditions.Run(ctx, r.cfg, t, nil)
		return report, err
	}
	defer blueConn.Close(ctx)
	r.event("connect", "ok", "connected to %s", r.cfg.Database.Host)

	// 4. Preconditions.
	r.event("preconditions", "start", "evaluating preconditions")
	report.Preconditions = preconditions.Run(ctx, r.cfg, t, blueConn)
	for _, c := range report.Preconditions.Checks {
		status := "ok"
		if !c.Passed {
			status = "warn"
			if c.Fatal {
				status = "error"
			}
		}
		r.event("preconditions", status, "%s: %s", c.Name, c.Detail)
	}
	if !report.Preconditions.OK() {
		err := fmt.Errorf("fatal precondition(s) failed; aborting")
		r.event("preconditions", "error", "%v", err)
		return report, err
	}

	// 5. Drop extensions on blue (pre-upgrade) if requested.
	for _, e := range r.cfg.Extensions {
		if !e.DropBeforeUpgrade {
			continue
		}
		r.event("extensions", "start", "dropping extension %q on blue", e.Name)
		if err := pg.DropExtension(ctx, blueConn, e.Name, false); err != nil {
			r.event("extensions", "error", "%v", err)
			return report, err
		}
		r.event("extensions", "ok", "dropped %q on blue", e.Name)
	}

	// 6. Create blue/green deployment.
	params := bluegreen.ParamsFor(r.cfg, t)
	r.event("bluegreen", "start", "creating blue/green deployment %q", params.Name)
	depID, err := bluegreen.Create(ctx, clients.RDS, params)
	if err != nil {
		r.event("bluegreen", "error", "%v", err)
		return report, err
	}
	report.DeploymentID = depID
	r.event("bluegreen", "ok", "created deployment %s", depID)

	// 7. Wait for AVAILABLE.
	r.event("bluegreen", "start", "waiting for green environment to become available")
	dep, err := bluegreen.WaitAvailable(ctx, clients.RDS, depID, r.pollInterval, func(status string) {
		r.event("bluegreen", "ok", "deployment status: %s", status)
	})
	if err != nil {
		r.event("bluegreen", "error", "%v", err)
		return report, err
	}
	r.event("bluegreen", "ok", "green environment is available")

	// 8. Resolve green endpoint.
	greenHost, greenPort := r.cfg.Smoke.GreenHost, r.cfg.Smoke.GreenPort
	if greenHost == "" {
		h, p, gerr := bluegreen.GreenEndpoint(ctx, clients.RDS, dep, params.Aurora)
		if gerr != nil {
			r.event("greenendpoint", "warn", "could not auto-resolve green endpoint: %v", gerr)
		} else {
			greenHost, greenPort = h, int(p)
			r.event("greenendpoint", "ok", "green endpoint %s:%d", greenHost, greenPort)
		}
	}

	var greenConn *pgx.Conn
	if greenHost != "" {
		greenConn, err = pg.Connect(ctx, pg.FromConfig(r.cfg.Database, greenHost, greenPort))
		if err != nil {
			r.event("greenendpoint", "warn", "could not connect to green: %v", err)
		} else {
			defer greenConn.Close(ctx)
		}
	}

	// 9. Disable logical replication on green.
	if r.cfg.Options.DropLogicalReplication {
		if greenConn == nil {
			r.event("logical-repl", "warn", "skipping: no green connection")
		} else {
			r.event("logical-repl", "start", "disabling logical replication on green")
			actions, lerr := pg.DisableLogicalReplication(ctx, greenConn)
			if lerr != nil {
				r.event("logical-repl", "error", "%v", lerr)
				return report, lerr
			}
			for _, a := range actions {
				r.event("logical-repl", "ok", "%s", a)
			}
		}
	}

	// 10. Recreate extensions on green.
	if !r.cfg.Options.SkipExtensionRecreate && greenConn != nil {
		for _, e := range r.cfg.Extensions {
			if !e.Recreate {
				continue
			}
			r.event("extensions", "start", "recreating extension %q on green", e.Name)
			if err := pg.CreateExtension(ctx, greenConn, e.Name); err != nil {
				r.event("extensions", "error", "%v", err)
				return report, err
			}
			r.event("extensions", "ok", "ensured extension %q on green", e.Name)
		}
	}

	// 11. Smoke tests.
	r.event("smoke", "start", "running smoke tests (blue vs green)")
	report.Smoke = smoketest.Run(ctx, r.cfg, blueConn, greenConn)
	for _, c := range report.Smoke.Comparisons {
		if c.Error != "" {
			r.event("smoke", "error", "%s: %s", c.Label, c.Error)
		} else if c.Match {
			r.event("smoke", "ok", "%s: blue=%d green=%d (match)", c.Label, c.Blue, c.Green)
		} else {
			r.event("smoke", "error", "%s: blue=%d green=%d (MISMATCH)", c.Label, c.Blue, c.Green)
		}
	}
	if !report.Smoke.Passed() {
		err := fmt.Errorf("smoke tests failed (%s); NOT switching over", report.Smoke.Summary())
		r.event("smoke", "error", "%v", err)
		return report, err
	}
	r.event("smoke", "ok", "smoke tests passed (%s)", report.Smoke.Summary())

	// 12. Switchover.
	r.event("switchover", "start", "switching over to green")
	if err := bluegreen.Switchover(ctx, clients.RDS, depID, r.switchoverTimeout); err != nil {
		r.event("switchover", "error", "%v", err)
		return report, err
	}
	report.SwitchedOver = true
	r.event("switchover", "ok", "switchover initiated")

	// 13. Optional cleanup.
	if r.cfg.Upgrade.DeleteAfterSwitch {
		r.event("cleanup", "start", "deleting old blue environment")
		if err := bluegreen.Delete(ctx, clients.RDS, depID, true); err != nil {
			r.event("cleanup", "warn", "could not delete blue: %v", err)
		} else {
			r.event("cleanup", "ok", "old blue environment deletion requested")
		}
	} else {
		r.event("cleanup", "skip", "retaining blue/green deployment for manual cleanup")
	}

	r.event("done", "ok", "upgrade complete")
	return report, nil
}

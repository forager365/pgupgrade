// Package smoketest validates the green environment against blue before
// switchover by comparing row counts and arbitrary scalar queries.
package smoketest

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"

	"bggowails/internal/config"
	"bggowails/internal/pg"
)

// Comparison is the result of comparing one metric across blue and green.
type Comparison struct {
	Label string `json:"label"`
	Blue  int64  `json:"blue"`
	Green int64  `json:"green"`
	Match bool   `json:"match"`
	Error string `json:"error,omitempty"`
}

// Result aggregates all comparisons.
type Result struct {
	Comparisons []Comparison `json:"comparisons"`
}

// Passed reports whether every comparison matched with no errors.
func (r Result) Passed() bool {
	for _, c := range r.Comparisons {
		if !c.Match || c.Error != "" {
			return false
		}
	}
	return len(r.Comparisons) > 0
}

// Run compares configured tables and queries between the blue and green
// connections. Either connection being nil yields errored comparisons.
func Run(ctx context.Context, cfg *config.Config, blue, green *pgx.Conn) Result {
	var r Result

	for _, table := range cfg.Smoke.CountTables {
		r.Comparisons = append(r.Comparisons, compare(
			"count("+table+")",
			func(c *pgx.Conn) (int64, error) { return pg.RowCount(ctx, c, table) },
			blue, green,
		))
	}

	for _, q := range cfg.Smoke.Queries {
		query := q
		r.Comparisons = append(r.Comparisons, compare(
			"query: "+truncate(query, 60),
			func(c *pgx.Conn) (int64, error) { return pg.ScalarInt(ctx, c, query) },
			blue, green,
		))
	}

	return r
}

func compare(label string, fn func(*pgx.Conn) (int64, error), blue, green *pgx.Conn) Comparison {
	c := Comparison{Label: label}
	if blue == nil || green == nil {
		c.Error = "blue or green connection unavailable"
		return c
	}
	b, err := fn(blue)
	if err != nil {
		c.Error = "blue: " + err.Error()
		return c
	}
	g, err := fn(green)
	if err != nil {
		c.Error = "green: " + err.Error()
		return c
	}
	c.Blue, c.Green = b, g
	c.Match = b == g
	return c
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

// Summary returns a one-line pass/fail summary.
func (r Result) Summary() string {
	matched := 0
	for _, c := range r.Comparisons {
		if c.Match && c.Error == "" {
			matched++
		}
	}
	return fmt.Sprintf("%d/%d comparisons matched", matched, len(r.Comparisons))
}

// Package preconditions validates that an upgrade is safe to attempt before any
// mutating AWS or SQL operation runs.
package preconditions

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"

	"bggowails/internal/config"
	"bggowails/internal/pg"
	"bggowails/internal/topology"
)

// Check is the outcome of a single precondition.
type Check struct {
	Name   string `json:"name"`
	Passed bool   `json:"passed"`
	Fatal  bool   `json:"fatal"` // a failed fatal check blocks the upgrade
	Detail string `json:"detail"`
}

// Result aggregates all checks.
type Result struct {
	Checks []Check `json:"checks"`
}

// OK reports whether no fatal check failed.
func (r Result) OK() bool {
	for _, c := range r.Checks {
		if c.Fatal && !c.Passed {
			return false
		}
	}
	return true
}

// Run executes all preconditions. blueConn may be nil if the database is
// unreachable; connectivity is then reported as a failed fatal check.
func Run(ctx context.Context, cfg *config.Config, target *topology.Target, blueConn *pgx.Conn) Result {
	var r Result
	add := func(name string, passed, fatal bool, detail string) {
		r.Checks = append(r.Checks, Check{Name: name, Passed: passed, Fatal: fatal, Detail: detail})
	}

	// 1. Version path must be a forward major-version upgrade.
	srcMajor, sErr := majorVersion(cfg.Upgrade.SourceVersion)
	tgtMajor, tErr := majorVersion(cfg.Upgrade.TargetVersion)
	switch {
	case sErr != nil:
		add("version-parse", false, true, sErr.Error())
	case tErr != nil:
		add("version-parse", false, true, tErr.Error())
	case tgtMajor <= srcMajor:
		add("version-path", false, true,
			fmt.Sprintf("target major %d must be greater than source major %d", tgtMajor, srcMajor))
	default:
		add("version-path", true, true,
			fmt.Sprintf("major %d -> %d", srcMajor, tgtMajor))
	}

	// 2. Engine family must match the chosen topology.
	engine := strings.ToLower(target.Engine)
	if target.Topology == config.TopologyAurora {
		add("engine-family", strings.Contains(engine, "aurora-postgresql"), true,
			fmt.Sprintf("engine=%s topology=aurora", target.Engine))
	} else {
		add("engine-family", engine == "postgres", true,
			fmt.Sprintf("engine=%s topology=%s", target.Engine, target.Topology))
	}

	// 3. Source running version should match the declared source version.
	add("source-version-match",
		strings.HasPrefix(target.EngineVersion, strconv.Itoa(srcMajor)),
		false,
		fmt.Sprintf("running %s, declared source %s", target.EngineVersion, cfg.Upgrade.SourceVersion))

	// 4. Required parameter groups present for the topology.
	if target.Topology == config.TopologyAurora {
		add("parameter-group", cfg.ParameterGroups.Cluster != "", true,
			"cluster parameter group: "+cfg.ParameterGroups.Cluster)
	} else {
		add("parameter-group", cfg.ParameterGroups.Instance != "", true,
			"instance parameter group: "+cfg.ParameterGroups.Instance)
	}

	// 5. Database connectivity.
	if blueConn == nil {
		add("db-connectivity", false, true, "could not connect to source database")
	} else {
		add("db-connectivity", true, true, "connected to "+cfg.Database.Host)

		// 6. Logical replication state on the source (informational/warning).
		if st, err := pg.LogicalReplicationState(ctx, blueConn); err == nil {
			active := st.Publications+st.Subscriptions+st.LogicalSlots > 0
			add("logical-replication", !active, false,
				fmt.Sprintf("wal_level=%s pubs=%d subs=%d logical_slots=%d",
					st.WalLevel, st.Publications, st.Subscriptions, st.LogicalSlots))
		} else {
			add("logical-replication", false, false, "could not read state: "+err.Error())
		}
	}

	return r
}

// majorVersion extracts the leading integer major version from a string like
// "14.10", "15.4" or "16".
func majorVersion(v string) (int, error) {
	v = strings.TrimSpace(v)
	if v == "" {
		return 0, fmt.Errorf("empty version")
	}
	field := strings.FieldsFunc(v, func(r rune) bool { return r == '.' })
	if len(field) == 0 {
		return 0, fmt.Errorf("cannot parse version %q", v)
	}
	n, err := strconv.Atoi(field[0])
	if err != nil {
		return 0, fmt.Errorf("cannot parse major version from %q: %w", v, err)
	}
	return n, nil
}

// Package logging provides an activity logger that writes every action to a
// timestamped log file on disk and, optionally, forwards each entry to a sink
// (used by the Wails frontend to stream live activity to the UI).
package logging

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// Level describes the severity of a log entry.
type Level string

const (
	LevelInfo Level = "INFO"
	LevelWarn Level = "WARN"
	LevelErr  Level = "ERROR"
	LevelStep Level = "STEP"
	LevelDry  Level = "DRYRUN"
)

// Entry is a single structured log record.
type Entry struct {
	Time    time.Time `json:"time"`
	Level   Level     `json:"level"`
	Phase   string    `json:"phase"`
	Message string    `json:"message"`
}

// Sink receives every entry as it is written. Safe to be nil.
type Sink func(Entry)

// Logger writes activity to a file and to an optional sink.
type Logger struct {
	mu    sync.Mutex
	file  *os.File
	sink  Sink
	path  string
	phase string
}

// New creates a Logger that appends to a timestamped file inside dir.
// If dir is empty it defaults to ./logs.
func New(dir string, sink Sink) (*Logger, error) {
	if dir == "" {
		dir = "logs"
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, fmt.Errorf("create log dir: %w", err)
	}
	name := fmt.Sprintf("bggowails-%s.log", time.Now().Format("20060102-150405"))
	path := filepath.Join(dir, name)
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return nil, fmt.Errorf("open log file: %w", err)
	}
	l := &Logger{file: f, sink: sink, path: path}
	l.write(Entry{Time: time.Now(), Level: LevelInfo, Message: "activity log started: " + path})
	return l, nil
}

// Path returns the on-disk log file path.
func (l *Logger) Path() string { return l.path }

// SetPhase tags subsequent entries with a phase name.
func (l *Logger) SetPhase(phase string) {
	l.mu.Lock()
	l.phase = phase
	l.mu.Unlock()
}

func (l *Logger) write(e Entry) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if e.Phase == "" {
		e.Phase = l.phase
	}
	line := fmt.Sprintf("%s [%s]%s %s\n",
		e.Time.Format(time.RFC3339), e.Level, phaseTag(e.Phase), e.Message)
	if l.file != nil {
		_, _ = l.file.WriteString(line)
	}
	if l.sink != nil {
		l.sink(e)
	}
}

func phaseTag(p string) string {
	if p == "" {
		return ""
	}
	return " (" + p + ")"
}

func (l *Logger) log(level Level, format string, args ...any) {
	l.write(Entry{Time: time.Now(), Level: level, Message: fmt.Sprintf(format, args...)})
}

func (l *Logger) Infof(format string, args ...any)  { l.log(LevelInfo, format, args...) }
func (l *Logger) Warnf(format string, args ...any)  { l.log(LevelWarn, format, args...) }
func (l *Logger) Errorf(format string, args ...any) { l.log(LevelErr, format, args...) }
func (l *Logger) Stepf(format string, args ...any)  { l.log(LevelStep, format, args...) }
func (l *Logger) Dryf(format string, args ...any)   { l.log(LevelDry, format, args...) }

// Close flushes and closes the underlying file.
func (l *Logger) Close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file != nil {
		return l.file.Close()
	}
	return nil
}

// Package bluegreen wraps the RDS Blue/Green Deployment API for both RDS
// instance and Aurora cluster topologies.
package bluegreen

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"

	"bggowails/internal/config"
	"bggowails/internal/topology"
)

// CreateParams describes the green environment to build.
type CreateParams struct {
	Name                   string
	SourceARN              string
	TargetEngineVersion    string
	InstanceParameterGroup string
	ClusterParameterGroup  string
	Aurora                 bool
}

// Deployment is a lightweight view of a blue/green deployment's state.
type Deployment struct {
	Identifier  string
	Status      string
	Source      string
	Target      string
	MemberPairs []MemberPair
}

// MemberPair links a blue (source) member to its green (target) counterpart.
type MemberPair struct {
	SourceARN string
	TargetARN string
	Status    string
}

// ParamsFor builds CreateParams from config + detected topology.
func ParamsFor(cfg *config.Config, t *topology.Target) CreateParams {
	return CreateParams{
		Name:                   cfg.Upgrade.BlueGreenName,
		SourceARN:              t.ARN,
		TargetEngineVersion:    cfg.Upgrade.TargetVersion,
		InstanceParameterGroup: cfg.ParameterGroups.Instance,
		ClusterParameterGroup:  cfg.ParameterGroups.Cluster,
		Aurora:                 t.Topology == config.TopologyAurora,
	}
}

// Create starts a blue/green deployment and returns its identifier.
func Create(ctx context.Context, client *rds.Client, p CreateParams) (string, error) {
	in := &rds.CreateBlueGreenDeploymentInput{
		BlueGreenDeploymentName: aws.String(p.Name),
		Source:                  aws.String(p.SourceARN),
		TargetEngineVersion:     aws.String(p.TargetEngineVersion),
	}
	if p.InstanceParameterGroup != "" {
		in.TargetDBParameterGroupName = aws.String(p.InstanceParameterGroup)
	}
	if p.Aurora && p.ClusterParameterGroup != "" {
		in.TargetDBClusterParameterGroupName = aws.String(p.ClusterParameterGroup)
	}
	out, err := client.CreateBlueGreenDeployment(ctx, in)
	if err != nil {
		return "", fmt.Errorf("create blue/green deployment: %w", err)
	}
	return aws.ToString(out.BlueGreenDeployment.BlueGreenDeploymentIdentifier), nil
}

// Describe returns the current state of a deployment.
func Describe(ctx context.Context, client *rds.Client, id string) (*Deployment, error) {
	out, err := client.DescribeBlueGreenDeployments(ctx, &rds.DescribeBlueGreenDeploymentsInput{
		BlueGreenDeploymentIdentifier: aws.String(id),
	})
	if err != nil {
		return nil, fmt.Errorf("describe blue/green deployment %q: %w", id, err)
	}
	if len(out.BlueGreenDeployments) == 0 {
		return nil, fmt.Errorf("blue/green deployment %q not found", id)
	}
	d := out.BlueGreenDeployments[0]
	dep := &Deployment{
		Identifier: aws.ToString(d.BlueGreenDeploymentIdentifier),
		Status:     aws.ToString(d.Status),
		Source:     aws.ToString(d.Source),
		Target:     aws.ToString(d.Target),
	}
	for _, sd := range d.SwitchoverDetails {
		dep.MemberPairs = append(dep.MemberPairs, MemberPair{
			SourceARN: aws.ToString(sd.SourceMember),
			TargetARN: aws.ToString(sd.TargetMember),
			Status:    aws.ToString(sd.Status),
		})
	}
	return dep, nil
}

// WaitAvailable polls until the deployment reaches AVAILABLE or the context ends.
func WaitAvailable(ctx context.Context, client *rds.Client, id string, poll time.Duration, onPoll func(status string)) (*Deployment, error) {
	if poll <= 0 {
		poll = 30 * time.Second
	}
	ticker := time.NewTicker(poll)
	defer ticker.Stop()
	for {
		dep, err := Describe(ctx, client, id)
		if err != nil {
			return nil, err
		}
		if onPoll != nil {
			onPoll(dep.Status)
		}
		switch strings.ToUpper(dep.Status) {
		case "AVAILABLE":
			return dep, nil
		case "INVALID_CONFIGURATION", "DELETING", "DELETED":
			return dep, fmt.Errorf("deployment entered terminal status %q", dep.Status)
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-ticker.C:
		}
	}
}

// Switchover promotes green to take over the blue endpoints.
func Switchover(ctx context.Context, client *rds.Client, id string, timeout time.Duration) error {
	in := &rds.SwitchoverBlueGreenDeploymentInput{
		BlueGreenDeploymentIdentifier: aws.String(id),
	}
	if timeout > 0 {
		secs := int32(timeout.Seconds())
		in.SwitchoverTimeout = &secs
	}
	if _, err := client.SwitchoverBlueGreenDeployment(ctx, in); err != nil {
		return fmt.Errorf("switchover blue/green deployment %q: %w", id, err)
	}
	return nil
}

// Delete removes the blue/green deployment. If deleteTarget is true the old
// (blue) resources are deleted as well.
func Delete(ctx context.Context, client *rds.Client, id string, deleteTarget bool) error {
	in := &rds.DeleteBlueGreenDeploymentInput{
		BlueGreenDeploymentIdentifier: aws.String(id),
		DeleteTarget:                  aws.Bool(deleteTarget),
	}
	if _, err := client.DeleteBlueGreenDeployment(ctx, in); err != nil {
		return fmt.Errorf("delete blue/green deployment %q: %w", id, err)
	}
	return nil
}

// GreenEndpoint resolves the host/port of the green environment for smoke tests
// by inspecting the first target member of the deployment.
func GreenEndpoint(ctx context.Context, client *rds.Client, dep *Deployment, aurora bool) (host string, port int32, err error) {
	if len(dep.MemberPairs) == 0 {
		return "", 0, fmt.Errorf("deployment has no member pairs yet")
	}
	id, kind := parseARN(dep.MemberPairs[0].TargetARN)
	if id == "" {
		return "", 0, fmt.Errorf("could not parse target member ARN %q", dep.MemberPairs[0].TargetARN)
	}

	if aurora || kind == "cluster" {
		out, derr := client.DescribeDBClusters(ctx, &rds.DescribeDBClustersInput{
			DBClusterIdentifier: aws.String(id),
		})
		if derr != nil || len(out.DBClusters) == 0 {
			return "", 0, fmt.Errorf("describe green cluster %q: %w", id, derr)
		}
		cl := out.DBClusters[0]
		p := int32(0)
		if cl.Port != nil {
			p = *cl.Port
		}
		return aws.ToString(cl.Endpoint), p, nil
	}

	out, derr := client.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(id),
	})
	if derr != nil || len(out.DBInstances) == 0 {
		return "", 0, fmt.Errorf("describe green instance %q: %w", id, derr)
	}
	inst := out.DBInstances[0]
	if inst.Endpoint == nil {
		return "", 0, fmt.Errorf("green instance %q has no endpoint yet", id)
	}
	p := int32(0)
	if inst.Endpoint.Port != nil {
		p = *inst.Endpoint.Port
	}
	return aws.ToString(inst.Endpoint.Address), p, nil
}

// parseARN extracts the resource id and kind (db/cluster) from an RDS ARN.
func parseARN(arn string) (id, kind string) {
	parts := strings.Split(arn, ":")
	if len(parts) < 7 {
		return "", ""
	}
	return parts[6], parts[5]
}

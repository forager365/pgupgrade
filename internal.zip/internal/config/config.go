// Package config loads and validates the TOML configuration that drives a
// blue/green major-version Postgres upgrade.
package config

import (
	"fmt"
	"os"
	"strings"

	"github.com/BurntSushi/toml"
)

// Topology enumerates the supported source database shapes.
type Topology string

const (
	// TopologyAuto asks the tool to detect the topology from the AWS API.
	TopologyAuto Topology = "auto"
	// TopologyRDSInstance is a single-AZ RDS Postgres instance.
	TopologyRDSInstance Topology = "rds-instance"
	// TopologyRDSMultiAZ is a Multi-AZ RDS Postgres instance (with or without read replicas).
	TopologyRDSMultiAZ Topology = "rds-multiaz"
	// TopologyAurora is an Aurora PostgreSQL cluster.
	TopologyAurora Topology = "aurora"
)

// Config is the root configuration object.
type Config struct {
	AWS             AWS         `toml:"aws"`
	Upgrade         Upgrade     `toml:"upgrade"`
	Target          Target      `toml:"target"`
	ParameterGroups ParamGroups `toml:"parameter_groups"`
	Database        Database    `toml:"database"`
	Extensions      []Extension `toml:"extensions"`
	Smoke           Smoke       `toml:"smoke"`
	Options         Options     `toml:"options"`
}

// AWS holds SSO / region settings used to build the SDK config.
type AWS struct {
	SSOProfile string `toml:"sso_profile"`
	Region     string `toml:"region"`
}

// Upgrade describes the version transition and blue/green deployment name.
type Upgrade struct {
	SourceVersion     string   `toml:"source_version"`
	TargetVersion     string   `toml:"target_version"`
	Topology          Topology `toml:"topology"`
	BlueGreenName     string   `toml:"blue_green_name"`
	DeleteAfterSwitch bool     `toml:"delete_blue_after_switch"`
}

// Target identifies the source RDS instance or Aurora cluster being upgraded.
type Target struct {
	DBInstanceIdentifier string `toml:"db_instance_identifier"`
	DBClusterIdentifier  string `toml:"db_cluster_identifier"`
}

// ParamGroups names the target parameter groups applied to the green environment.
type ParamGroups struct {
	Instance string `toml:"instance"`
	Cluster  string `toml:"cluster"`
}

// Database holds the connection credentials used for pgx operations.
type Database struct {
	Host        string `toml:"host"`
	Port        int    `toml:"port"`
	Name        string `toml:"name"`
	User        string `toml:"user"`
	Password    string `toml:"password"`
	PasswordEnv string `toml:"password_env"`
	SSLMode     string `toml:"sslmode"`
}

// Extension is a Postgres extension that may need dropping/recreating across the upgrade.
type Extension struct {
	Name     string `toml:"name"`
	Recreate bool   `toml:"recreate"`
	// DropBeforeUpgrade drops the extension on blue before creating the green env.
	DropBeforeUpgrade bool `toml:"drop_before_upgrade"`
}

// Smoke configures post-creation validation against the green environment.
type Smoke struct {
	// CountTables are fully-qualified tables whose row counts must match blue.
	CountTables []string `toml:"count_tables"`
	// Queries are arbitrary single-integer queries run against both environments.
	Queries []string `toml:"queries"`
	// GreenHost / GreenPort point at the green endpoint for validation.
	GreenHost string `toml:"green_host"`
	GreenPort int    `toml:"green_port"`
}

// Options toggles optional behaviours.
type Options struct {
	// DropLogicalReplication disables logical replication on the green instance.
	DropLogicalReplication bool `toml:"drop_logical_replication"`
	// SkipExtensionRecreate disables the extension recreate phase entirely.
	SkipExtensionRecreate bool `toml:"skip_extension_recreate"`
}

// Load reads and validates a TOML config file.
func Load(path string) (*Config, error) {
	var c Config
	// Sensible defaults.
	c.Upgrade.Topology = TopologyAuto
	c.Database.Port = 5432
	c.Database.SSLMode = "require"

	md, err := toml.DecodeFile(path, &c)
	if err != nil {
		return nil, fmt.Errorf("decode TOML %q: %w", path, err)
	}
	if undecoded := md.Undecoded(); len(undecoded) > 0 {
		keys := make([]string, 0, len(undecoded))
		for _, k := range undecoded {
			keys = append(keys, k.String())
		}
		return nil, fmt.Errorf("unknown config keys: %s", strings.Join(keys, ", "))
	}

	c.resolveSecrets()
	if err := c.Validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

// LoadString parses config from a TOML string (used by the UI for inline edits).
func LoadString(data string) (*Config, error) {
	var c Config
	c.Upgrade.Topology = TopologyAuto
	c.Database.Port = 5432
	c.Database.SSLMode = "require"
	if _, err := toml.Decode(data, &c); err != nil {
		return nil, fmt.Errorf("decode TOML: %w", err)
	}
	c.resolveSecrets()
	if err := c.Validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

func (c *Config) resolveSecrets() {
	if c.Database.Password == "" && c.Database.PasswordEnv != "" {
		c.Database.Password = os.Getenv(c.Database.PasswordEnv)
	}
}

// Validate enforces required fields and internal consistency.
func (c *Config) Validate() error {
	var errs []string
	req := func(cond bool, msg string) {
		if !cond {
			errs = append(errs, msg)
		}
	}

	req(c.AWS.SSOProfile != "", "aws.sso_profile is required")
	req(c.AWS.Region != "", "aws.region is required")
	req(c.Upgrade.SourceVersion != "", "upgrade.source_version is required")
	req(c.Upgrade.TargetVersion != "", "upgrade.target_version is required")
	req(c.Upgrade.BlueGreenName != "", "upgrade.blue_green_name is required")

	switch c.Upgrade.Topology {
	case TopologyAuto, TopologyRDSInstance, TopologyRDSMultiAZ, TopologyAurora:
	default:
		errs = append(errs, fmt.Sprintf("upgrade.topology %q is invalid", c.Upgrade.Topology))
	}

	if c.Upgrade.Topology == TopologyAurora {
		req(c.Target.DBClusterIdentifier != "", "target.db_cluster_identifier is required for aurora")
		req(c.ParameterGroups.Cluster != "", "parameter_groups.cluster is required for aurora")
	} else if c.Upgrade.Topology != TopologyAuto {
		req(c.Target.DBInstanceIdentifier != "", "target.db_instance_identifier is required")
		req(c.ParameterGroups.Instance != "", "parameter_groups.instance is required")
	} else {
		// auto: need at least one identifier to start detection.
		req(c.Target.DBInstanceIdentifier != "" || c.Target.DBClusterIdentifier != "",
			"target.db_instance_identifier or target.db_cluster_identifier is required for auto topology")
	}

	req(c.Database.Host != "", "database.host is required")
	req(c.Database.Name != "", "database.name is required")
	req(c.Database.User != "", "database.user is required")

	if len(errs) > 0 {
		return fmt.Errorf("invalid config:\n  - %s", strings.Join(errs, "\n  - "))
	}
	return nil
}

// Redacted returns a copy of the config safe for logging (password removed).
func (c Config) Redacted() Config {
	if c.Database.Password != "" {
		c.Database.Password = "***redacted***"
	}
	return c
}

// Package pg performs the in-database operations required during a major-version
// upgrade: row-count validation, extension drop/recreate, and disabling logical
// replication. All operations use the pgx driver with the supplied credentials.
package pg

import (
	"context"
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"

	"bggowails/internal/config"
)

// ConnInfo is the minimal set of fields needed to open a connection.
type ConnInfo struct {
	Host     string
	Port     int
	Name     string
	User     string
	Password string
	SSLMode  string
}

// FromConfig builds ConnInfo from the database section, optionally overriding
// the host/port (used to point at the green endpoint for validation).
func FromConfig(db config.Database, hostOverride string, portOverride int) ConnInfo {
	ci := ConnInfo{
		Host:     db.Host,
		Port:     db.Port,
		Name:     db.Name,
		User:     db.User,
		Password: db.Password,
		SSLMode:  db.SSLMode,
	}
	if hostOverride != "" {
		ci.Host = hostOverride
	}
	if portOverride != 0 {
		ci.Port = portOverride
	}
	if ci.Port == 0 {
		ci.Port = 5432
	}
	if ci.SSLMode == "" {
		ci.SSLMode = "require"
	}
	return ci
}

// DSN renders a libpq connection string.
func (ci ConnInfo) DSN() string {
	u := url.URL{
		Scheme: "postgres",
		User:   url.UserPassword(ci.User, ci.Password),
		Host:   fmt.Sprintf("%s:%d", ci.Host, ci.Port),
		Path:   "/" + ci.Name,
	}
	q := url.Values{}
	q.Set("sslmode", ci.SSLMode)
	u.RawQuery = q.Encode()
	return u.String()
}

// Connect opens a connection with a bounded timeout.
func Connect(ctx context.Context, ci ConnInfo) (*pgx.Conn, error) {
	ctx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	conn, err := pgx.Connect(ctx, ci.DSN())
	if err != nil {
		return nil, fmt.Errorf("connect %s:%d/%s: %w", ci.Host, ci.Port, ci.Name, err)
	}
	return conn, nil
}

// ServerVersion returns the server_version_num setting (e.g. 150004).
func ServerVersion(ctx context.Context, conn *pgx.Conn) (string, error) {
	var v string
	if err := conn.QueryRow(ctx, "show server_version").Scan(&v); err != nil {
		return "", fmt.Errorf("show server_version: %w", err)
	}
	return v, nil
}

// RowCount returns the number of rows in a fully-qualified table. The identifier
// is validated and quoted to avoid SQL injection from config values.
func RowCount(ctx context.Context, conn *pgx.Conn, table string) (int64, error) {
	ident, err := quoteQualified(table)
	if err != nil {
		return 0, err
	}
	var n int64
	q := fmt.Sprintf("select count(*) from %s", ident)
	if err := conn.QueryRow(ctx, q).Scan(&n); err != nil {
		return 0, fmt.Errorf("count %s: %w", table, err)
	}
	return n, nil
}

// ScalarInt runs an arbitrary query expected to return a single integer.
func ScalarInt(ctx context.Context, conn *pgx.Conn, query string) (int64, error) {
	var n int64
	if err := conn.QueryRow(ctx, query).Scan(&n); err != nil {
		return 0, fmt.Errorf("query %q: %w", query, err)
	}
	return n, nil
}

// ExtensionInfo describes an installed extension.
type ExtensionInfo struct {
	Name    string
	Version string
}

// ListExtensions returns extensions currently installed in the database.
func ListExtensions(ctx context.Context, conn *pgx.Conn) ([]ExtensionInfo, error) {
	rows, err := conn.Query(ctx, "select extname, extversion from pg_extension order by extname")
	if err != nil {
		return nil, fmt.Errorf("list extensions: %w", err)
	}
	defer rows.Close()
	var out []ExtensionInfo
	for rows.Next() {
		var e ExtensionInfo
		if err := rows.Scan(&e.Name, &e.Version); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// DropExtension drops an extension if it exists.
func DropExtension(ctx context.Context, conn *pgx.Conn, name string, cascade bool) error {
	ident, err := quoteIdent(name)
	if err != nil {
		return err
	}
	stmt := fmt.Sprintf("DROP EXTENSION IF EXISTS %s", ident)
	if cascade {
		stmt += " CASCADE"
	}
	if _, err := conn.Exec(ctx, stmt); err != nil {
		return fmt.Errorf("drop extension %s: %w", name, err)
	}
	return nil
}

// CreateExtension creates an extension if it does not already exist.
func CreateExtension(ctx context.Context, conn *pgx.Conn, name string) error {
	ident, err := quoteIdent(name)
	if err != nil {
		return err
	}
	stmt := fmt.Sprintf("CREATE EXTENSION IF NOT EXISTS %s", ident)
	if _, err := conn.Exec(ctx, stmt); err != nil {
		return fmt.Errorf("create extension %s: %w", name, err)
	}
	return nil
}

// LogicalReplicationStatus reports the relevant settings and counts.
type LogicalReplicationStatus struct {
	WalLevel      string
	Publications  int
	Subscriptions int
	LogicalSlots  int
}

// LogicalReplicationState inspects logical replication on the connected server.
func LogicalReplicationState(ctx context.Context, conn *pgx.Conn) (LogicalReplicationStatus, error) {
	var s LogicalReplicationStatus
	if err := conn.QueryRow(ctx, "show wal_level").Scan(&s.WalLevel); err != nil {
		return s, fmt.Errorf("show wal_level: %w", err)
	}
	_ = conn.QueryRow(ctx, "select count(*) from pg_publication").Scan(&s.Publications)
	_ = conn.QueryRow(ctx, "select count(*) from pg_subscription").Scan(&s.Subscriptions)
	_ = conn.QueryRow(ctx,
		"select count(*) from pg_replication_slots where slot_type = 'logical'").Scan(&s.LogicalSlots)
	return s, nil
}

// DisableLogicalReplication tears down logical replication objects on the
// connected (green) server: subscriptions, publications, and inactive logical
// slots. The wal_level itself is governed by the parameter group
// (rds.logical_replication), which is applied separately via the parameter group.
func DisableLogicalReplication(ctx context.Context, conn *pgx.Conn) ([]string, error) {
	var actions []string

	// Disable + drop subscriptions (must disable before drop to release the slot).
	subs, err := queryStrings(ctx, conn, "select subname from pg_subscription")
	if err != nil {
		return actions, err
	}
	for _, sub := range subs {
		id, err := quoteIdent(sub)
		if err != nil {
			return actions, err
		}
		_, _ = conn.Exec(ctx, fmt.Sprintf("ALTER SUBSCRIPTION %s DISABLE", id))
		_, _ = conn.Exec(ctx, fmt.Sprintf("ALTER SUBSCRIPTION %s SET (slot_name = NONE)", id))
		if _, err := conn.Exec(ctx, fmt.Sprintf("DROP SUBSCRIPTION IF EXISTS %s", id)); err != nil {
			return actions, fmt.Errorf("drop subscription %s: %w", sub, err)
		}
		actions = append(actions, "dropped subscription "+sub)
	}

	// Drop publications.
	pubs, err := queryStrings(ctx, conn, "select pubname from pg_publication")
	if err != nil {
		return actions, err
	}
	for _, pub := range pubs {
		id, err := quoteIdent(pub)
		if err != nil {
			return actions, err
		}
		if _, err := conn.Exec(ctx, fmt.Sprintf("DROP PUBLICATION IF EXISTS %s", id)); err != nil {
			return actions, fmt.Errorf("drop publication %s: %w", pub, err)
		}
		actions = append(actions, "dropped publication "+pub)
	}

	// Drop inactive logical replication slots.
	slots, err := queryStrings(ctx, conn,
		"select slot_name from pg_replication_slots where slot_type = 'logical' and active = false")
	if err != nil {
		return actions, err
	}
	for _, slot := range slots {
		if _, err := conn.Exec(ctx, "select pg_drop_replication_slot($1)", slot); err != nil {
			return actions, fmt.Errorf("drop replication slot %s: %w", slot, err)
		}
		actions = append(actions, "dropped logical slot "+slot)
	}

	if len(actions) == 0 {
		actions = append(actions, "no logical replication objects found")
	}
	return actions, nil
}

func queryStrings(ctx context.Context, conn *pgx.Conn, q string) ([]string, error) {
	rows, err := conn.Query(ctx, q)
	if err != nil {
		return nil, fmt.Errorf("query %q: %w", q, err)
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var s string
		if err := rows.Scan(&s); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

// quoteIdent validates and double-quotes a single SQL identifier.
func quoteIdent(name string) (string, error) {
	if name == "" {
		return "", fmt.Errorf("empty identifier")
	}
	if strings.ContainsRune(name, 0) {
		return "", fmt.Errorf("invalid identifier %q", name)
	}
	return `"` + strings.ReplaceAll(name, `"`, `""`) + `"`, nil
}

// quoteQualified validates and quotes a possibly schema-qualified table name.
func quoteQualified(table string) (string, error) {
	parts := strings.Split(table, ".")
	if len(parts) == 0 || len(parts) > 2 {
		return "", fmt.Errorf("invalid table name %q", table)
	}
	quoted := make([]string, 0, len(parts))
	for _, p := range parts {
		q, err := quoteIdent(strings.TrimSpace(p))
		if err != nil {
			return "", err
		}
		quoted = append(quoted, q)
	}
	return strings.Join(quoted, "."), nil
}

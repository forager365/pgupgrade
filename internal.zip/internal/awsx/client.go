// Package awsx builds AWS SDK v2 clients authenticated through an SSO profile.
package awsx

import (
	"context"
	"fmt"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/rds"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

// Clients bundles the AWS service clients used by the upgrader.
type Clients struct {
	Config aws.Config
	RDS    *rds.Client
	STS    *sts.Client
}

// New loads AWS configuration for the given SSO profile and region and returns
// initialised service clients. The SSO session must already be valid
// (e.g. `aws sso login --profile <profile>`); expired sessions surface as an
// authentication error on the first API call.
func New(ctx context.Context, ssoProfile, region string) (*Clients, error) {
	cfg, err := awsconfig.LoadDefaultConfig(ctx,
		awsconfig.WithSharedConfigProfile(ssoProfile),
		awsconfig.WithRegion(region),
	)
	if err != nil {
		return nil, fmt.Errorf("load AWS config for profile %q: %w", ssoProfile, err)
	}
	return &Clients{
		Config: cfg,
		RDS:    rds.NewFromConfig(cfg),
		STS:    sts.NewFromConfig(cfg),
	}, nil
}

// CallerIdentity returns the account/ARN of the active credentials. It is used
// as an early connectivity + auth check before any mutating operations.
func (c *Clients) CallerIdentity(ctx context.Context) (account, arn string, err error) {
	out, err := c.STS.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
	if err != nil {
		return "", "", fmt.Errorf("sts get-caller-identity (SSO session may be expired): %w", err)
	}
	return aws.ToString(out.Account), aws.ToString(out.Arn), nil
}

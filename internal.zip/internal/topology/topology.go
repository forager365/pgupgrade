// Package topology inspects an RDS/Aurora target and classifies its shape so the
// orchestrator can choose the right blue/green strategy and parameter groups.
package topology

import (
	"context"
	"fmt"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"

	"bggowails/internal/config"
)

// Target is the resolved description of the database being upgraded.
type Target struct {
	Topology      config.Topology
	ARN           string // used as the blue/green deployment Source
	Identifier    string // instance or cluster identifier
	Engine        string // e.g. postgres / aurora-postgresql
	EngineVersion string
	MultiAZ       bool
	Endpoint      string
	Port          int32
	// Replicas lists read-replica identifiers (RDS instance topologies).
	Replicas []string
	// ClusterMembers lists member instance identifiers (Aurora).
	ClusterMembers []string
}

// Detect resolves the concrete topology. If cfg.Upgrade.Topology is "auto" it
// probes the AWS API; otherwise it confirms the declared topology and fills in
// runtime details (ARN, endpoint, version).
func Detect(ctx context.Context, client *rds.Client, cfg *config.Config) (*Target, error) {
	declared := cfg.Upgrade.Topology

	// Aurora is identified by a cluster identifier.
	if declared == config.TopologyAurora ||
		(declared == config.TopologyAuto && cfg.Target.DBClusterIdentifier != "") {
		return detectCluster(ctx, client, cfg.Target.DBClusterIdentifier)
	}

	return detectInstance(ctx, client, cfg.Target.DBInstanceIdentifier, declared)
}

func detectInstance(ctx context.Context, client *rds.Client, id string, declared config.Topology) (*Target, error) {
	if id == "" {
		return nil, fmt.Errorf("no db_instance_identifier provided for instance topology")
	}
	out, err := client.DescribeDBInstances(ctx, &rds.DescribeDBInstancesInput{
		DBInstanceIdentifier: aws.String(id),
	})
	if err != nil {
		return nil, fmt.Errorf("describe db instance %q: %w", id, err)
	}
	if len(out.DBInstances) == 0 {
		return nil, fmt.Errorf("db instance %q not found", id)
	}
	in := out.DBInstances[0]

	// An Aurora member instance carries a cluster id; redirect to cluster path.
	if cid := aws.ToString(in.DBClusterIdentifier); cid != "" {
		return detectCluster(ctx, client, cid)
	}

	multiAZ := aws.ToBool(in.MultiAZ)
	top := config.TopologyRDSInstance
	if multiAZ {
		top = config.TopologyRDSMultiAZ
	}
	if declared != config.TopologyAuto && declared != top {
		return nil, fmt.Errorf("declared topology %q but instance %q is %q", declared, id, top)
	}

	t := &Target{
		Topology:      top,
		ARN:           aws.ToString(in.DBInstanceArn),
		Identifier:    aws.ToString(in.DBInstanceIdentifier),
		Engine:        aws.ToString(in.Engine),
		EngineVersion: aws.ToString(in.EngineVersion),
		MultiAZ:       multiAZ,
		Replicas:      in.ReadReplicaDBInstanceIdentifiers,
	}
	if ep := in.Endpoint; ep != nil {
		t.Endpoint = aws.ToString(ep.Address)
		t.Port = derefInt32(ep.Port)
	}
	return t, nil
}

func detectCluster(ctx context.Context, client *rds.Client, id string) (*Target, error) {
	if id == "" {
		return nil, fmt.Errorf("no db_cluster_identifier provided for aurora topology")
	}
	out, err := client.DescribeDBClusters(ctx, &rds.DescribeDBClustersInput{
		DBClusterIdentifier: aws.String(id),
	})
	if err != nil {
		return nil, fmt.Errorf("describe db cluster %q: %w", id, err)
	}
	if len(out.DBClusters) == 0 {
		return nil, fmt.Errorf("db cluster %q not found", id)
	}
	cl := out.DBClusters[0]

	t := &Target{
		Topology:      config.TopologyAurora,
		ARN:           aws.ToString(cl.DBClusterArn),
		Identifier:    aws.ToString(cl.DBClusterIdentifier),
		Engine:        aws.ToString(cl.Engine),
		EngineVersion: aws.ToString(cl.EngineVersion),
		Endpoint:      aws.ToString(cl.Endpoint),
		Port:          derefInt32(cl.Port),
	}
	for _, m := range cl.DBClusterMembers {
		t.ClusterMembers = append(t.ClusterMembers, aws.ToString(m.DBInstanceIdentifier))
	}
	return t, nil
}

func derefInt32(p *int32) int32 {
	if p == nil {
		return 0
	}
	return *p
}

// Describe returns a human-readable one-line summary of the topology.
func (t *Target) Describe() string {
	switch t.Topology {
	case config.TopologyAurora:
		return fmt.Sprintf("Aurora PostgreSQL cluster %q (engine %s %s, %d members)",
			t.Identifier, t.Engine, t.EngineVersion, len(t.ClusterMembers))
	case config.TopologyRDSMultiAZ:
		return fmt.Sprintf("RDS Multi-AZ instance %q (%s %s, %d read replicas)",
			t.Identifier, t.Engine, t.EngineVersion, len(t.Replicas))
	default:
		return fmt.Sprintf("RDS instance %q (%s %s, %d read replicas)",
			t.Identifier, t.Engine, t.EngineVersion, len(t.Replicas))
	}
}
